// // Export all leasing form templates
// export { default as CustomerInfoTemplate } from './CustomerInfo';
// export { default as ContractInfoTemplate } from './ContractInfo';
// export { default as FinancialSummaryTemplate } from './FinancialSummary';

// // Re-export Props interfaces
// export type { CustomerInfoTemplateProps } from './CustomerInfo';
// export type { ContractInfoTemplateProps } from './ContractInfo'; 
// export type { FinancialSummaryTemplateProps } from './FinancialSummary';
