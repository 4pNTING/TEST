// React Imports
import type { ReactNode } from 'react'

export type Layout = 'vertical' | 'collapsed'

export type Skin = 'default' | 'bordered'

export type Mode = 'light' | 'dark' | 'system'

export type SystemMode = 'light' | 'dark'

export type Direction = 'ltr' | 'rtl'

export type LayoutComponentWidth = 'wide'

export type LayoutComponentPosition = 'fixed' | 'static'

export type ChildrenType = {
  children: ReactNode
}

export type ThemeColor = 'primary' | 'secondary' | 'error' | 'warning' | 'info' | 'success'
