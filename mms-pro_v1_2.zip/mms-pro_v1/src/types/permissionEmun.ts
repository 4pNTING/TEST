export enum PermissionEnum {
    CREATE = "c",
    READ = "r",
    UPDATE = "u",
    DELETE = "d",
}