import NextAuth from 'next-auth';

declare module 'next-auth' {
  interface UserLoginData {
    // _id?: string;
    // empID?: string;
    // fNameLa?: string;
    // lNameLa?: string;
    // userName?: string;
    // fNameEn?: string;
    // lNameEn?: string;
    // nickNameLa?: string;
    // nickNameEn?: string;
    // genderID?: string;
    // phone?: string;
    // email?: string;
    // dob?: string;
    // roleId?: string;
    prefix?: string;
    username?: string;
    level?: string;
    dic?: any;
    business?: string | null;
    permission?: {
      action?: string[];
      feature?: string;
    }[];
    roleName?: string;
  }
  interface Session {
    // accessToken?: string;
    // refreshToken?: string;
    user?: UserLoginData;
    authorization?: string;
  }

  interface TokenData {
    user?: UserLoginData;
    authorization?: string;

    sub?: string;
    accessToken?: string;
    refreshToken?: string;
    iat?: number;
    exp?: number;
    jti?: string;
  }

  interface LoginData {
    // accessToken?: string;
    // refreshToken?: string;
    user?: UserLoginData;
    authorization?: string;
    dic?: any;
  }
}
