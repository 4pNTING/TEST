export enum WhoAmI {
    ADVISER = 'ADVISER',
    HR = 'HR',
    EMPLOYEE = 'EMPLOYEE',
}