export enum promotingEnumStatus {
    NOT = 'Not',
    PERCENT = 'Percent',
    LEVEL = 'Level',
    POSITION = 'Position',
}