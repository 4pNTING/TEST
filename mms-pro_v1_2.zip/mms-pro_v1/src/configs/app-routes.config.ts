// ไฟล์นี้จะถูกเอาออก - deferred/paused ตามคำขอของผู้ใช้
// TODO: ให้เอา app router config กลับมาใช้ในภายหลัง

