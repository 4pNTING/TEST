export * from './gql';
export * from './queries/waterMaster';
// Re-export only specific types from models/graphql to avoid conflicts
export type {
  CreateWaterMasterRequest,
  UpdateWaterMasterRequest,
  DeleteWaterMasterRequest,
  QueryProps,
  LoadAllWaterMasterResponse,
  CreateWaterMasterResponse,
  UpdateWaterMasterResponse,
  DeleteWaterMasterResponse,
  WaterMasterModel
} from './models/graphql';
