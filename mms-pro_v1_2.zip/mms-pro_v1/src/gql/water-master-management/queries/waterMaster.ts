import { gql } from "@apollo/client";

export const waterMasterLoadAllCommand = gql`
  query QueryWaterMasterLoadAll($query: QueryProps) {
    waterMasterLoadAll(query: $query) {
      items {
        _id
        code
        leasingContractId
        customerName
        roomCode
        prevReading
        multiplier
        pricePerUnit
        tax10
        waterMeter {
          _id
          name
          isActive
        }
        leasingContract {
          id
          contractNumber
          shopName
          customer {
            firstName
            lastName
            phone
          }
          rooms {
            roomCode
            roomName
          }
        }
      }
      total
    }
  }
`;

export const waterMasterCreateCommand = gql`
  mutation WaterMasterCreate($input: CreateWaterMasterRequest!) {
    waterMasterCreate(input: $input) {
      _id
      code
      leasingContractId
      customerName
      roomCode
      prevReading
      multiplier
      pricePerUnit
      tax10
    }
  }
`;

export const waterMasterUpdateCommand = gql`
  mutation WaterMasterUpdate($input: UpdateWaterMasterRequest!) {
    waterMasterUpdate(input: $input) {
      _id
      code
      leasingContractId
      customerName
      roomCode
      prevReading
      multiplier
      pricePerUnit
      tax10
    }
  }
`;

export const waterMasterDeleteCommand = gql`
  mutation WaterMasterDelete($input: DeleteWaterMasterRequest!) {
    waterMasterDelete(input: $input) {
      _id
    }
  }
`;
