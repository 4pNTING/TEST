// WaterMeter GraphQL queries
import { gql } from '@apollo/client';

export const waterMeterLoadAllCommand = gql`
  query QueryWaterMeterLoadAll($query: QueryProps) {
    waterMeterLoadAll(query: $query) {
      items {
        _id
        name
        isActive
        createdAt
        updatedAt
      }
      total
    }
  }
`;

export const waterMeterByIdCommand = gql`
  query QueryWaterMeterById($id: String!) {
    waterMeterById(id: $id) {
      _id
      name
      isActive
    }
  }
`;

export const waterMeterCreateCommand = gql`
  mutation WaterMeterCreate($input: CreateWaterMeterRequest!) {
    waterMeterCreate(input: $input) {
      _id
      name
      isActive
    }
  }
`;

export const waterMeterUpdateCommand = gql`
  mutation WaterMeterUpdate($input: UpdateWaterMeterRequest!) {
    waterMeterUpdate(input: $input) {
      _id
      name
      isActive
    }
  }
`;

export const waterMeterDeleteCommand = gql`
  mutation WaterMeterDelete($input: DeleteWaterMeterRequest!) {
    waterMeterDelete(input: $input) {
      _id
    }
  }
`;
