/* eslint-disable */
import * as types from './models/graphql';
import { TypedDocumentNode as DocumentNode } from '@graphql-typed-document-node/core';

/**
 * Map of all GraphQL operations in the project.
 */
const documents = {
    "\n  query QueryWaterMasterLoadAll($query: QueryProps) {\n    waterMasterLoadAll(query: $query) {\n      items {\n        _id\n        code\n        leasingContractId\n        customerName\n        roomCode\n        prevReading\n        multiplier\n        pricePerUnit\n        tax10\n        uid\n        createdAt\n        updatedAt\n      }\n      total\n    }\n  }\n": types.LoadWaterMastersDocument,
    "\n  mutation WaterMasterCreate($input: CreateWaterMasterRequest!) {\n    waterMasterCreate(input: $input) {\n      _id\n      code\n      leasingContractId\n      customerName\n      roomCode\n      prevReading\n      multiplier\n      pricePerUnit\n      tax10\n      uid\n      createdAt\n      updatedAt\n    }\n  }\n": types.WaterMasterCreateDocument,
    "\n  mutation WaterMasterUpdate($input: UpdateWaterMasterRequest!) {\n    waterMasterUpdate(input: $input) {\n      _id\n      code\n      leasingContractId\n      customerName\n      roomCode\n      prevReading\n      multiplier\n      pricePerUnit\n      tax10\n      uid\n      createdAt\n      updatedAt\n    }\n  }\n": types.WaterMasterUpdateDocument,
    "\n  mutation WaterMasterDelete($input: DeleteWaterMasterRequest!) {\n    waterMasterDelete(input: $input) {\n      _id\n    }\n  }\n": types.WaterMasterDeleteDocument,
};

/**
 * The gql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function gql(source: "\n  query QueryWaterMasterLoadAll($query: QueryProps) {\n    waterMasterLoadAll(query: $query) {\n      items {\n        _id\n        code\n        leasingContractId\n        customerName\n        roomCode\n        prevReading\n        multiplier\n        pricePerUnit\n        tax10\n        uid\n        createdAt\n        updatedAt\n      }\n      total\n    }\n  }\n"): (typeof documents)["\n  query QueryWaterMasterLoadAll($query: QueryProps) {\n    waterMasterLoadAll(query: $query) {\n      items {\n        _id\n        code\n        leasingContractId\n        customerName\n        roomCode\n        prevReading\n        multiplier\n        pricePerUnit\n        tax10\n        uid\n        createdAt\n        updatedAt\n      }\n      total\n    }\n  }\n"];

export function gql(source: "\n  mutation WaterMasterCreate($input: CreateWaterMasterRequest!) {\n    waterMasterCreate(input: $input) {\n      _id\n      code\n      leasingContractId\n      customerName\n      roomCode\n      prevReading\n      multiplier\n      pricePerUnit\n      tax10\n      uid\n      createdAt\n      updatedAt\n    }\n  }\n"): (typeof documents)["\n  mutation WaterMasterCreate($input: CreateWaterMasterRequest!) {\n    waterMasterCreate(input: $input) {\n      _id\n      code\n      leasingContractId\n      customerName\n      roomCode\n      prevReading\n      multiplier\n      pricePerUnit\n      tax10\n      uid\n      createdAt\n      updatedAt\n    }\n  }\n"];

export function gql(source: "\n  mutation WaterMasterUpdate($input: UpdateWaterMasterRequest!) {\n    waterMasterUpdate(input: $input) {\n      _id\n      code\n      leasingContractId\n      customerName\n      roomCode\n      prevReading\n      multiplier\n      pricePerUnit\n      tax10\n      uid\n      createdAt\n      updatedAt\n    }\n  }\n"): (typeof documents)["\n  mutation WaterMasterUpdate($input: UpdateWaterMasterRequest!) {\n    waterMasterUpdate(input: $input) {\n      _id\n      code\n      leasingContractId\n      customerName\n      roomCode\n      prevReading\n      multiplier\n      pricePerUnit\n      tax10\n      uid\n      createdAt\n      updatedAt\n    }\n  }\n"];

export function gql(source: "\n  mutation WaterMasterDelete($input: DeleteWaterMasterRequest!) {\n    waterMasterDelete(input: $input) {\n      _id\n    }\n  }\n"): (typeof documents)["\n  mutation WaterMasterDelete($input: DeleteWaterMasterRequest!) {\n    waterMasterDelete(input: $input) {\n      _id\n    }\n  }\n"];

export function gql(source: string) {
  return (documents as any)[source] ?? {};
}

export type DocumentType<TDocumentNode extends DocumentNode<any, any>> = TDocumentNode extends DocumentNode<  infer TType,  any>  ? TType  : never;
