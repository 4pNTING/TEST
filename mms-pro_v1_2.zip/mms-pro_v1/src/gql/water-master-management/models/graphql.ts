/* eslint-disable */
import { TypedDocumentNode as DocumentNode } from '@graphql-typed-document-node/core';

export type Maybe<T> = T | null;
export type InputMaybe<T> = Maybe<T>;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
export type MakeEmpty<T extends { [key: string]: unknown }, K extends keyof T> = { [_ in K]?: never };
export type Incremental<T> = T | { [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never };

/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: { input: string; output: string; }
  String: { input: string; output: string; }
  Boolean: { input: boolean; output: boolean; }
  Int: { input: number; output: number; }
  Float: { input: number; output: number; }
};

export type WaterMeterModel = {
  __typename?: 'WaterMeterModel';
  _id: Scalars['String']['output'];
  name: Scalars['String']['output'];
  isActive: Scalars['Boolean']['output'];
  createdAt: Scalars['String']['output'];
  updatedAt: Scalars['String']['output'];
};

export type LeasingContractModel = {
  __typename?: 'LeasingContractModel';
  id: Scalars['String']['output'];
  contractNumber: Scalars['String']['output'];
  shopName?: Maybe<Scalars['String']['output']>;
  customer?: Maybe<{
    firstName?: Scalars['String']['output'];
    lastName?: Scalars['String']['output'];
    phone?: Scalars['String']['output'];
  }>;
  rooms?: Maybe<Array<{
    roomCode?: Scalars['String']['output'];
    roomName?: Scalars['String']['output'];
  }>>;
};

export type WaterMasterModel = {
  __typename?: 'WaterMasterModel';
  _id: Scalars['String']['output'];
  code: Scalars['String']['output'];
  leasingContractId: Scalars['String']['output'];
  leasingContract?: Maybe<LeasingContractModel>; // Populated leasing contract data
  customerName?: Maybe<Scalars['String']['output']>; // From leasing contract
  roomCode?: Maybe<Scalars['String']['output']>; // From leasing contract  
  waterMeterId: Scalars['String']['output'];
  waterMeter?: Maybe<WaterMeterModel>;
  prevReading: Scalars['Int']['output'];
  multiplier: Scalars['Float']['output'];
  pricePerUnit: Scalars['Int']['output'];
  tax10?: Maybe<Scalars['Boolean']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  createdAt: Scalars['String']['output'];
  updatedAt: Scalars['String']['output'];
};

export type LoadAllWaterMeterResponse = {
  __typename?: 'LoadAllWaterMeterResponse';
  items: Array<WaterMeterModel>;
  total: Scalars['Int']['output'];
};

export type LoadAllWaterMasterResponse = {
  __typename?: 'LoadAllWaterMasterResponse';
  items: Array<WaterMasterModel>;
  total: Scalars['Int']['output'];
};

export type PaginateInput = {
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
};

export type ConditionInput = {
  field: Scalars['String']['input'];
  operator: Scalars['String']['input'];
  value?: InputMaybe<Scalars['String']['input']>;
};

export type QueryInput = {
  conditions?: InputMaybe<Array<ConditionInput>>;
  paginate?: InputMaybe<PaginateInput>;
};

export type LoadWaterMastersQueryVariables = Exact<{
  query?: InputMaybe<QueryInput>;
}>;

export type LoadWaterMastersQuery = {
  __typename?: 'Query';
  loadWaterMasters?: {
    __typename?: 'LoadAllWaterMasterResponse';
    total: number;
    items: Array<{
      __typename?: 'WaterMasterModel';
      _id: string;
      code: string;
      leasingContractId: string;
      customerName?: string | null;
      roomCode?: string | null;
      waterMeterId: string;
      prevReading: number;
      multiplier: number;
      pricePerUnit: number;
      tax10?: boolean | null;
      uid?: string | null;
      createdAt: string;
      updatedAt: string;
      waterMeter?: {
        __typename?: 'WaterMeterModel';
        _id: string;
        name: string;
        isActive: boolean;
        createdAt: string;
        updatedAt: string;
      } | null;
      leasingContract?: {
        __typename?: 'LeasingContractModel';
        id: string;
        contractNumber: string;
        shopName?: string | null;
        customer?: {
          firstName?: string;
          lastName?: string;
          phone?: string;
        } | null;
        rooms?: Array<{
          roomCode?: string;
          roomName?: string;
        }> | null;
      } | null;
    }>;
  } | null;
};

export type LoadWaterMetersQueryVariables = Exact<{
  query?: InputMaybe<QueryInput>;
}>;

export type LoadWaterMetersQuery = {
  __typename?: 'Query';
  loadWaterMeters?: {
    __typename?: 'LoadAllWaterMeterResponse';
    total: number;
    items: Array<{
      __typename?: 'WaterMeterModel';
      _id: string;
      name: string;
      isActive: boolean;
      createdAt: string;
      updatedAt: string;
    }>;
  } | null;
};

export type QueryProps = {
  conditions?: InputMaybe<Array<ConditionInput>>;
  paginate?: InputMaybe<PaginateInput>;
};

export type CreateWaterMasterRequest = {
  code: Scalars['String']['input'];
  leasingContractId: Scalars['String']['input'];
  customerName: Scalars['String']['input'];
  roomCode: Scalars['String']['input'];
  waterMeterId: Scalars['String']['input'];
  prevReading: Scalars['Int']['input'];
  multiplier: Scalars['Float']['input'];
  pricePerUnit: Scalars['Int']['input'];
  tax10?: InputMaybe<Scalars['Boolean']['input']>;
  uid?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateWaterMasterRequest = {
  _id: Scalars['String']['input'];
  code?: InputMaybe<Scalars['String']['input']>;
  leasingContractId?: InputMaybe<Scalars['String']['input']>;
  customerName?: InputMaybe<Scalars['String']['input']>;
  roomCode?: InputMaybe<Scalars['String']['input']>;
  waterMeterId?: InputMaybe<Scalars['String']['input']>;
  prevReading?: InputMaybe<Scalars['Int']['input']>;
  multiplier?: InputMaybe<Scalars['Float']['input']>;
  pricePerUnit?: InputMaybe<Scalars['Int']['input']>;
  tax10?: InputMaybe<Scalars['Boolean']['input']>;
  uid?: InputMaybe<Scalars['String']['input']>;
};

export type DeleteWaterMasterRequest = {
  _id: Scalars['String']['input'];
};

export type CreateWaterMasterResponse = WaterMasterModel;

export type UpdateWaterMasterResponse = WaterMasterModel;

export const LoadWaterMastersDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"LoadWaterMasters"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"query"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"loadWaterMasters"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"query"},"value":{"kind":"Variable","name":{"kind":"Name","value":"query"}}}]}]}}]} as unknown as DocumentNode<LoadWaterMastersQuery, LoadWaterMastersQueryVariables>;

export const LoadWaterMetersDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"LoadWaterMeters"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"query"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"loadWaterMeters"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"query"},"value":{"kind":"Variable","name":{"kind":"Name","value":"query"}}}]}]}}]} as unknown as DocumentNode<LoadWaterMetersQuery, LoadWaterMetersQueryVariables>;

/**
 * Mutation: WaterMasterCreate
 */
export type WaterMasterCreateMutationVariables = {
  input: CreateWaterMasterRequest;
};

export type WaterMasterCreateMutation = {
  __typename?: 'Mutation';
  waterMasterCreate: {
    __typename?: 'WaterMasterModel';
    _id: string;
    code: string;
    leasingContractId: string;
    customerName?: string;
    roomCode?: string;
    prevReading: number;
    multiplier: number;
    pricePerUnit: number;
    tax10?: boolean;
    uid?: string;
    createdAt: string;
    updatedAt: string;
  };
};

export const WaterMasterCreateDocument = {
  kind: 'Document',
  definitions: []
} as unknown as DocumentNode<WaterMasterCreateMutation, WaterMasterCreateMutationVariables>;

/**
 * Mutation: WaterMasterUpdate
 */
export type WaterMasterUpdateMutationVariables = {
  input: UpdateWaterMasterRequest;
};

export type WaterMasterUpdateMutation = {
  __typename?: 'Mutation';
  waterMasterUpdate: {
    __typename?: 'WaterMasterModel';
    _id: string;
    code: string;
    leasingContractId: string;
    customerName?: string;
    roomCode?: string;
    prevReading: number;
    multiplier: number;
    pricePerUnit: number;
    tax10?: boolean;
    uid?: string;
    createdAt: string;
    updatedAt: string;
  };
};

export const WaterMasterUpdateDocument = {
  kind: 'Document',
  definitions: []
} as unknown as DocumentNode<WaterMasterUpdateMutation, WaterMasterUpdateMutationVariables>;

/**
 * Mutation: WaterMasterDelete
 */
export type WaterMasterDeleteMutationVariables = {
  input: DeleteWaterMasterRequest;
};

export type WaterMasterDeleteMutation = {
  __typename?: 'Mutation';
  waterMasterDelete: {
    __typename?: 'DeleteWaterMasterResponse';
    _id: string;
  };
};

export type DeleteWaterMasterResponse = {
  __typename?: 'DeleteWaterMasterResponse';
  _id: Scalars['String']['output'];
};

export const WaterMasterDeleteDocument = {
  kind: 'Document',
  definitions: []
} as unknown as DocumentNode<WaterMasterDeleteMutation, WaterMasterDeleteMutationVariables>;
