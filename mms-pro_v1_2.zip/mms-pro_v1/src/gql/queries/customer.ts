import { gql } from "@apollo/client";



// Customer Queries
export const LOAD_CUSTOMER = gql`
  query LoadCustomer($input: LoadCustomerDto!) {
    loadCustomer(input: $input) {
      count
      customer {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        createdBy
        updatedBy
        buId
        customId
        firstName
        lastName
        phoneNumber
        gender
        nationality
        province
        district
        village
        fileUrl
        contact {
          firstName
          lastName
          phoneNumber
          province
          district
          village
        }
      }
    }
  }
`;

export const CREATE_CUSTOMER = gql`
  mutation CreateCustomer($input: CreateCustomerDto!) {
    createCustomer(input: $input) {
      customer {
        _id
        uniqueId
        uid
        customId
        firstName
        lastName
        phoneNumber
        gender
        nationality
        province
        district
        village
        fileUrl
        buId
        isActive
        createdAt
        updatedAt
        contact {
          firstName
          lastName
          phoneNumber
          province
          district
          village
        }
      }
    }
  }
`;

export const UPDATE_CUSTOMER = gql`
  mutation UpdateCustomer($input: UpdateCustomerDto!) {
    updateCustomer(input: $input) {
      customer {
        _id
        uniqueId
        uid
        customId
        firstName
        lastName
        phoneNumber
        gender
        nationality
        province
        district
        village
        fileUrl
        buId
        isActive
        createdAt
        updatedAt
        contact {
          firstName
          lastName
          phoneNumber
          province
          district
          village
        }
      }
    }
  }
`;

export const DELETE_CUSTOMER = gql`
  mutation DeleteCustomer($input: DeleteCustomerDto!) {
    deleteCustomer(input: $input) {
      customer {
        _id
        uniqueId
        uid
        customId
        firstName
        lastName
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const RESTORE_DELETE_CUSTOMER = gql`
  mutation RestoreDeleteCustomer($input: RestoreDeleteCustomerDto!) {
    restoreDeleteCustomer(input: $input) {
      customer {
        _id
        uniqueId
        uid
        customId
        firstName
        lastName
        phoneNumber
        gender
        nationality
        province
        district
        village
        fileUrl
        buId
        isActive
        createdAt
        updatedAt
        contact {
          firstName
          lastName
          phoneNumber
          province
          district
          village
        }
      }
    }
  }
`;
