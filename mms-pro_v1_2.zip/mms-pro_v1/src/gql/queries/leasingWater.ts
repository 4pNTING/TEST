import { gql } from "@apollo/client";

export const LOAD_LEASING_WATER = gql`
  query LoadLeasingWater($input: LoadLeasingWaterDto!) {
    loadLeasingWater(input: $input) {
      count
      leasingWater {
        _id
        uid
        uniqueId
        buId
        leasingIndexId
        waterId
        lastNumber
        fixedAmountId
        maintenanceFixedAmountId
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomArea {
              _id
              name
            }
          }
        }
        water {
          _id
          name
        }
        fixedAmount {
          _id
          amount
        }
        maintenanceFixedAmount {
          _id
          amount
        }
      }
    }
  }
`;

export const CREATE_LEASING_WATER = gql`
  mutation CreateLeasingWater($input: CreateLeasingWaterDto!) {
    createLeasingWater(input: $input) {
      leasingWater {
        _id
        uid
        uniqueId
        buId
        leasingIndexId
        waterId
        lastNumber
        fixedAmountId
        maintenanceFixedAmountId
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomArea {
              _id
              name
            }
          }
        }
        water {
          _id
          name
        }
        fixedAmount {
          _id
          amount
        }
        maintenanceFixedAmount {
          _id
          amount
        }
      }
    }
  }
`;

export const UPDATE_LEASING_WATER = gql`
  mutation UpdateLeasingWater($input: UpdateLeasingWaterDto!) {
    updateLeasingWater(input: $input) {
      leasingWater {
        _id
        uid
        uniqueId
        buId
        leasingIndexId
        waterId
        lastNumber
        fixedAmountId
        maintenanceFixedAmountId
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomArea {
              _id
              name
            }
          }
        }
        water {
          _id
          name
        }
        fixedAmount {
          _id
          amount
        }
        maintenanceFixedAmount {
          _id
          amount
        }
      }
    }
  }
`;

export const DELETE_LEASING_WATER = gql`
  mutation DeleteLeasingWater($input: DeleteLeasingWaterDto!) {
    deleteLeasingWater(input: $input) {
      leasingWater {
        _id
        uid
        leasingIndexId
        waterId
        isActive
        updatedAt
        updatedBy
      }
    }
  }
`;
