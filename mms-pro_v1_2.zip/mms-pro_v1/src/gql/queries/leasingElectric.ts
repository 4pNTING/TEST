import { gql } from "@apollo/client";

export const LOAD_LEASING_ELECTRIC = gql`
  query LoadLeasingElectric($input: LoadLeasingElectricDto!) {
    loadLeasingElectric(input: $input) {
      count
      leasingElectric {
        _id
        uid
        uniqueId
        buId
        leasingIndexId
        electricId
        lastNumber
        fixedAmountId
        electricityConversionFee
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomArea {
              _id
              name
            }
          }
        }
        electric {
          _id
          name
        }
        fixedAmount {
          _id
          amount
        }
      }
    }
  }
`;

export const CREATE_LEASING_ELECTRIC = gql`
  mutation CreateLeasingElectric($input: CreateLeasingElectricDto!) {
    createLeasingElectric(input: $input) {
      leasingElectric {
        _id
        uid
        uniqueId
        buId
        leasingIndexId
        electricId
        lastNumber
        fixedAmountId
        electricityConversionFee
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomArea {
              _id
              name
            }
          }
        }
        electric {
          _id
          name
        }
        fixedAmount {
          _id
          amount
        }
      }
    }
  }
`;

export const UPDATE_LEASING_ELECTRIC = gql`
  mutation UpdateLeasingElectric($input: UpdateLeasingElectricDto!) {
    updateLeasingElectric(input: $input) {
      leasingElectric {
        _id
        uid
        uniqueId
        buId
        leasingIndexId
        electricId
        lastNumber
        fixedAmountId
        electricityConversionFee
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomArea {
              _id
              name
            }
          }
        }
        electric {
          _id
          name
        }
        fixedAmount {
          _id
          amount
        }
      }
    }
  }
`;

export const DELETE_LEASING_ELECTRIC = gql`
  mutation DeleteLeasingElectric($input: DeleteLeasingElectricDto!) {
    deleteLeasingElectric(input: $input) {
      leasingElectric {
        _id
        uid
        leasingIndexId
        electricId
        isActive
        updatedAt
        updatedBy
      }
    }
  }
`;
