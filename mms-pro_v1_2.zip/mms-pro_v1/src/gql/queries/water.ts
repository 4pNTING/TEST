import { gql } from "@apollo/client";

export const LOAD_WATER = gql`
  query LoadWater($input: LoadWaterDto!) {
    loadWater(input: $input) {
      count
      water {
        _id
        uid
        buId
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const CREATE_WATER = gql`
  mutation CreateWater($input: CreateWaterDto!) {
    createWater(input: $input) {
      water {
        _id
        uid
        buId
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const UPDATE_WATER = gql`
  mutation UpdateWater($input: UpdateWaterDto!) {
    updateWater(input: $input) {
      water {
        _id
        uid
        buId
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const DELETE_WATER = gql`
  mutation DeleteWater($input: DeleteWaterDto!) {
    deleteWater(input: $input) {
      water {
        _id
        uid
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const RESTORE_DELETE_WATER = gql`
  mutation RestoreDeleteWater($input: RestoreDeleteWaterDto!) {
    restoreDeleteWater(input: $input) {
      water {
        _id
        uid
        buId
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;
