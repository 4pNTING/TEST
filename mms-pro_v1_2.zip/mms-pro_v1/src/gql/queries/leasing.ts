import { gql } from "@apollo/client";

// ==================== QUERIES ====================

export const LOAD_LEASING_INDEX = gql`
  query LoadLeasingIndex($input: LoadLeasingIndexDto!) {
    loadLeasingIndex(input: $input) {
      count
      leasingIndex {
        _id
        buId
        uid
        uniqueId
        contractNo
        contractCategory
        shopName
        shopCategoryId
        customerId
        paymentMethod
        fileUrl
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
       
        customer {
          _id
          uniqueId
          uid
          isActive
          createdAt
          updatedAt
          createdBy
          updatedBy
          buId
          customId
          firstName
          lastName
          gender
          nationality
          phoneNumber
          address
          province
          district
          village
          fileUrl
          contact {
            firstName
            lastName
            phoneNumber
            province
            district
            village
          }
        }
        leasingDateTime {
          _id
          startedAt
          endedAt
          endedPayAt
          requestUpdateLeasingActivedAt
          requestUpdateLeasingActivedBy
          requestUpdateLeasingNote
          actionApproveUpdateLeasingActivedAt
          actionApproveUpdateLeasingActivedBy
          actionRejectUpdateLeasingActivedAt
          actionRejectUpdateLeasingActivedBy
          requestCancelledAt
          requestCancelledBy
          requestCancelledFile
          requestCancelledNote
        }
        leasingSum {
          _id
          uniqueId
          uid
          isActive
          createdAt
          updatedAt
          buId
          leasingIndexId
          amount
          centralAmount
          discountAmount
          discountCentralAmount
          sumAmount
          depositAmount
          depositCurrency
          depositStatus
          currency
          returnDepositedAt
          returnDepositedBy
        }
        leasingInstallment {
          _id
          name
          amount
          currency
          paidAt
        }
        leasingOrder {
          _id
          uniqueId
          uid
          name
          isActive
          createdAt
          updatedAt
          createdBy
          updatedBy
          buId
          leasingIndexId
          leasingSumId
          roomAreaId
          long
          wide
          moreArea
          totalArea
          totalAreaAmount
          totalAreaCentralAmount
          currency
          centralAmount
          amount
          totalAmount
          roomArea {
            _id
            name
            zoneId
            zone {
              _id
              name
            }
            roomAreaCategoryId
            roomAreaCategory {
              _id
              name
            }
            currency
          }
        }
      }
    }
  }
`;

export const LOAD_LEASING_INDEX_DETAIL_BY_ID = gql`
  query LoadLeasingIndexDetailById($input: LoadLeasingIndexDetailByIdDto!) {
    loadLeasingIndexDetailById(input: $input) {
      leasingIndex {
        _id
        buId
        uid
        uniqueId
        contractNo
        contractCategory
        shopName
        shopCategoryId
        customerId
        paymentMethod
        fileUrl
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        leasingDateTime {
          _id
          startedAt
          endedAt
          endedPayAt
          requestUpdateLeasingActivedAt
          requestUpdateLeasingActivedBy
          requestUpdateLeasingNote
          actionApproveUpdateLeasingActivedAt
          actionApproveUpdateLeasingActivedBy
          actionRejectUpdateLeasingActivedAt
          actionRejectUpdateLeasingActivedBy
          requestCancelledAt
          requestCancelledBy
          requestCancelledFile
          requestCancelledNote
        }
        leasingInstallment {
          _id
          name
          amount
          currency
          paidAt
        }
      }
      leasingSum {
        _id
        buId
        uid
        uniqueId
        leasingIndexId
        amount
        centralAmount
        discountAmount
        discountCentralAmount
        sumAmount
        depositAmount
        depositCurrency
        depositStatus
        returnDepositedAt
        returnDepositedBy
        isActive
        createdAt
        updatedAt
      }
      leasingOrder {
        _id
        buId
        uid
        uniqueId
        leasingIndexId
        leasingSumId
        roomAreaId
        wide
        long
        amount
        centralAmount
        currency
        isActive
        createdAt
        updatedAt
        roomArea {
          _id
          buId
          uid
          uniqueId
          name
          zoneId
          roomAreaCategoryId
          wide
          long
          moreArea
          totalArea
          totalAreaAmount
          totalAreaCentralAmount
          amount
          centralAmount
          totalAmount
          currency
          holdStatus
          agentHoldStatus
          isActive
          createdAt
          createdBy
          updatedAt
          updatedBy
        }
      }
    }
  }
`;

// ==================== MUTATIONS ====================

export const CREATE_LEASING_INDEX = gql`
  mutation CreateLeasingIndex($input: CreateLeasingIndexDto!) {
    createLeasingIndex(input: $input) {
      leasingIndex {
        _id
        uniqueId
        uid
        buId
        customerId
        contractNo
        contractCategory
        shopName
        shopCategoryId
        paymentMethod
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        fileUrl
        customer {
          _id
          uniqueId
          customId
          firstName
          lastName
          phoneNumber
          nationality
          province
          district
          village
        }
        leasingDateTime {
          _id
          startedAt
          endedAt
          endedPayAt
        }
        leasingSum {
          _id
          amount
          centralAmount
          discountAmount
          discountCentralAmount
          depositAmount
          depositCurrency
          sumAmount
          currency
        }
        leasingInstallment {
          _id
          name
          amount
          currency
          paidAt
        }
        leasingOrder {
          _id
          uniqueId
          uid
          roomAreaId
          name
          wide
          long
          moreArea
          totalArea
          amount
          centralAmount
          currency
          totalAreaAmount
          totalAreaCentralAmount
        }
      }
    }
  }
`;

export const UPDATE_LEASING_INDEX = gql`
  mutation UpdateLeasingIndex($input: UpdateLeasingIndexDto!) {
    updateLeasingIndex(input: $input) {
      leasingIndex {
        _id
        buId
        uid
        uniqueId
        contractNo
        contractCategory
        shopName
        shopCategoryId
        customerId
        paymentMethod
        fileUrl
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        customer {
          _id
          uniqueId
          uid
          isActive
          createdAt
          updatedAt
          createdBy
          updatedBy
          buId
          customId
          firstName
          lastName
          gender
          nationality
          phoneNumber
          address
          province
          district
          village
          fileUrl
          contact {
            firstName
            lastName
            phoneNumber
            province
            district
            village
          }
        }
        leasingDateTime {
          _id
          startedAt
          endedAt
          endedPayAt
          requestUpdateLeasingActivedAt
          requestUpdateLeasingActivedBy
          requestUpdateLeasingNote
          actionApproveUpdateLeasingActivedAt
          actionApproveUpdateLeasingActivedBy
          actionRejectUpdateLeasingActivedAt
          actionRejectUpdateLeasingActivedBy
        }
        leasingSum {
          _id
          amount
          centralAmount
          discountAmount
          discountCentralAmount
          sumAmount
          depositAmount
          depositCurrency
          currency
        }
        leasingInstallment {
          _id
          name
          amount
          currency
          paidAt
        }
        leasingOrder {
          _id
          roomAreaId
          name
          long
          wide
          moreArea
          totalArea
          amount
          centralAmount
          totalAmount
        }
      }
    }
  }
`;

export const UPDATE_ACTIVED_LEASING_INDEX = gql`
  mutation UpdateActivedLeasingIndex($input: UpdateActivedLeasingIndexDto!) {
    updateActivedLeasingIndex(input: $input) {
      leasingIndex {
        _id
        status
        updatedAt
        updatedBy
        leasingDateTime {
          _id
          requestUpdateLeasingActivedAt
          requestUpdateLeasingActivedBy
          requestUpdateLeasingNote
        }
      }
    }
  }
`;

export const UPDATE_REJECT_LEASING_INDEX = gql`
  mutation UpdateRejectLeasingIndex($input: UpdateRejectLeasingIndexDto!) {
    updateRejectLeasingIndex(input: $input) {
      leasingIndex {
        _id
        status
      }
    }
  }
`;

export const UPDATE_ACCEPT_LEASING_INDEX = gql`
  mutation UpdateAcceptLeasingIndex($input: UpdateAcceptLeasingIndexDto!) {
    updateAcceptLeasingIndex(input: $input) {
      leasingIndex {
        _id
        status
      }
    }
  }
`;

export const UPDATE_ACCEPT_EDIT_ACTIVED_LEASING_INDEX = gql`
  mutation UpdateAcceptEditActivedLeasingIndex($input: UpdateAcceptEditActivedLeasingIndexDto!) {
    updateAcceptEditActivedLeasingIndex(input: $input) {
      leasingIndex {
        _id
        status
        updatedAt
        updatedBy
      }
    }
  }
`;

export const UPDATE_REJECT_EDIT_ACTIVED_LEASING_INDEX = gql`
  mutation UpdateRejectEditActivedLeasingIndex($input: UpdateRejectEditActivedLeasingIndexDto!) {
    updateRejectEditActivedLeasingIndex(input: $input) {
      leasingIndex {
        _id
        status
        updatedAt
        updatedBy
      }
    }
  }
`;

export const UPDATE_CANCEL_LEASING_INDEX = gql`
  mutation UpdateCancelLeasingIndex($input: UpdateCancelLeasingIndexDto!) {
    updateCancelLeasingIndex(input: $input) {
      leasingIndex {
        _id
        status
        updatedAt
        updatedBy
        leasingDateTime {
          _id
          requestCancelledAt
          requestCancelledBy
          requestCancelledFile
          requestCancelledNote
        }
      }
    }
  }
`;

export const UPDATE_END_LEASING_INDEX = gql`
  mutation UpdateEndLeasingIndex($input: UpdateEndLeasingIndexDto!) {
    updateEndLeasingIndex(input: $input) {
      leasingIndex {
        _id
        status
        isActive
        
      }
    }
  }
`;

export const UPDATE_REJECT_CANCEL_LEASING_INDEX = gql`
  mutation UpdateRejectCancelLeasingIndex($input: UpdateRejectCancelLeasingIndexDto!) {
    updateRejectCancelLeasingIndex(input: $input) {
      leasingIndex {
        _id
        status
      }
    }
  }
`;

export const DELETE_LEASING_INDEX = gql`
  mutation DeleteLeasingIndex($input: DeleteLeasingIndexDto!) {
    deleteLeasingIndex(input: $input) {
      leasingIndex {
        _id
        status
      }
    }
  }
`;

export const LOAD_LEASING_INDEX_REJECT_LOG_BY_ID = gql`
  query LoadLeasingIndexRejectLogById($input: LoadLeasingIndexRejectLogByIdDto!) {
    loadLeasingIndexRejectLogById(input: $input) {
      leasingIndexChangeLog {
        _id
        buId
        uid
        uniqueId
        contractCategory
        contractNo
        shopName
        shopCategoryId
        customerId
        paymentMethod
        fileUrl
        status
        isActive
        createdAt
        updatedAt
        createdBy
        updatedBy
      }
    }
  }
`;
