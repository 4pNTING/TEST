import { gql } from "@apollo/client";

// Query โหลดข้อมูล EW Invoice - ตาม graphql.ts ที่ backend กำหนด
export const LOAD_LEASING_EW_INVOICE = gql`
  query LoadLeasingEWInvoice($input: LoadLeasingEWInvoiceDto!) {
    loadLeasingEWInvoice(input: $input) {
      company {
        _id
        companyCode
        laName
        enName
        createdAt
        updatedAt
      }
      leasingEWInvoice {
        _id
        invoiceNo
        name
        leasingIndexId
        receiptReferenceId

        # ข้อมูลลูกค้าและร้านค้า
        leasingIndex {
          _id
          shopName
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomArea {
              _id
              name
            }
          }
        }

        leasingBatchElectricReference {
          _id
          amount
          status
          leasingBatchElectricDetail {
            _id
            lastNumber
            currentNumber
            unitAmount
            amount
            sumAmount
            electricityConversionFee
            currency
            electric {
              _id
              name
            }
            customer {
              _id
              firstName
              lastName
            }
            leasingIndex {
              _id
              contractNo
              shopName
            }
          }
        }
        leasingBatchElectricSumReference {
          count
          countApprovedAndInvoice
          countApprovedAndNoInvoice
          countPending
          sum
          sumApprovedAndInvoice
          sumApprovedAndNoInvoice
          sumPending
        }
        leasingBatchWaterReference {
          _id
          amount
          status
          leasingBatchWaterDetail {
            _id
            lastNumber
            currentNumber
            unitAmount
            amount
            sumAmount
            maintenanceAmount
            currency
            water {
              _id
              name
            }
            customer {
              _id
              firstName
              lastName
            }
            leasingIndex {
              _id
              contractNo
              shopName
            }
          }
        }
        leasingBatchWaterSumReference {
          count
          countApprovedAndInvoice
          countApprovedAndNoInvoice
          countPending
          sum
          sumApprovedAndInvoice
          sumApprovedAndNoInvoice
          sumPending
        }
        totalCount
        totalSum
        isActive
        buId
        uid
        uniqueId
        createdAt
        createdBy
        updatedAt
        updatedBy
      }
    }
  }
`;

// Mutation สร้าง Invoice - ตาม graphql.ts (CreateLeasingEwInvoiceDto รับแค่ name)
export const CREATE_LEASING_EW_INVOICE = gql`
  mutation CreateLeasingEWInvoice($input: CreateLeasingEWInvoiceDto!) {
    createLeasingEWInvoice(input: $input) {
      leasingEWInvoice {
        _id
        invoiceNo
        name
        leasingBatchElectricSumReference {
          sum
          count
        }
        leasingBatchWaterSumReference {
          sum
          count
        }
        totalSum
        totalCount
        createdAt
      }
    }
  }
`;
