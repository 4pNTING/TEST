import { gql } from "@apollo/client";

export const LOAD_USER_ROLE = gql`
  query LoadUserRole {
    loadUserRole {
      user {
        _id
        buId
        createdAt
        createdBy
        empId
        isActive
        permission {
          action
          feature
        }
        roleName
        uid
        uniqueId
        updatedAt
        updatedBy
      }
    }
  }
`;
