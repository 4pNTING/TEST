import { gql } from "@apollo/client";

export const LOAD_LEASING_BATCH_ELECTRIC = gql`
  query LoadLeasingBatchElectric($input: LoadLeasingBatchElectricDto!) {
    loadLeasingBatchElectric(input: $input) {
      count
      leasingBatchElectric {
        _id
        uid
        uniqueId
        name
        note
        status
        buId
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
      }
    }
  }
`;

export const CREATE_LEASING_BATCH_ELECTRIC = gql`
  mutation CreateLeasingBatchElectric($input: CreateLeasingBatchElectricDto!) {
    createLeasingBatchElectric(input: $input) {
      leasingBatchElectric {
        _id
        uid
        uniqueId
        name
        note
        status
        buId
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
      }
    }
  }
`;

export const UPDATE_LEASING_BATCH_ELECTRIC = gql`
  mutation UpdateLeasingBatchElectric($input: UpdateLeasingBatchElectricDto!) {
    updateLeasingBatchElectric(input: $input) {
      leasingBatchElectric {
        _id
        uid
        uniqueId
        name
        note
        status
        buId
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
      }
    }
  }
`;

export const DELETE_LEASING_BATCH_ELECTRIC = gql`
  mutation DeleteLeasingBatchElectric($input: DeleteLeasingBatchElectricDto!) {
    deleteLeasingBatchElectric(input: $input) {
      leasingBatchElectric {
        _id
        uid
        name
        isActive
        updatedAt
        updatedBy
      }
    }
  }
`;

export const UPDATE_SUBMIT_LEASING_BATCH_ELECTRIC = gql`
  mutation UpdateSubmitLeasingBatchElectric($input: UpdateSubmitLeasingBatchElectricDto!) {
    updateSubmitLeasingBatchElectric(input: $input) {
      leasingBatchElectric {
        _id
        uid
        uniqueId
        name
        status
        isActive
        updatedAt
        updatedBy
      }
    }
  }
`;

export const UPDATE_CONFIRM_LEASING_BATCH_ELECTRIC = gql`
  mutation UpdateConfirmLeasingBatchElectric($input: UpdateConfirmLeasingBatchElectricDto!) {
    updateConfirmLeasingBatchElectric(input: $input) {
      leasingBatchElectric {
        _id
        uid
        uniqueId
        name
        status
        isActive
        updatedAt
        updatedBy
      }
    }
  }
`;

export const UPDATE_REJECT_LEASING_BATCH_ELECTRIC = gql`
  mutation UpdateRejectLeasingBatchElectric($input: UpdateRejectLeasingBatchElectricDto!) {
    updateRejectLeasingBatchElectric(input: $input) {
      leasingBatchElectric {
        _id
        uid
        uniqueId
        name
        status
        isActive
        updatedAt
        updatedBy
      }
    }
  }
`;
