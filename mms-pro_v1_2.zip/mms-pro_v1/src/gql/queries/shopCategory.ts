import { gql } from '@apollo/client';


export const LOAD_SHOP_CATEGORY = gql`
  query LoadShopCategory($input: LoadShopCategoryDto!) {
    loadShopCategory(input: $input) {
      count
      shopCategory {
        _id
        uniqueId
        uid
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const CREATE_SHOP_CATEGORY = gql`
  mutation CreateShopCategory($input: CreateShopCategoryDto!) {
    createShopCategory(input: $input) {
      shopCategory {
        _id
        uniqueId
        uid
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const UPDATE_SHOP_CATEGORY = gql`
  mutation UpdateShopCategory($input: UpdateShopCategoryDto!) {
    updateShopCategory(input: $input) {
      shopCategory {
        _id
        uniqueId
        uid
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const DELETE_SHOP_CATEGORY = gql`
  mutation DeleteShopCategory($input: DeleteShopCategoryDto!) {
    deleteShopCategory(input: $input) {
      shopCategory {
        _id
        uniqueId
        uid
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const RESTORE_DELETE_SHOP_CATEGORY = gql`
  mutation RestoreDeleteShopCategory($input: RestoreDeleteShopCategoryDto!) {
    restoreDeleteShopCategory(input: $input) {
      shopCategory {
        _id
        uniqueId
        uid
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;
