import { gql } from "@apollo/client";

export const LOAD_ELECTRIC = gql`
  query LoadElectric($input: LoadElectricDto!) {
    loadElectric(input: $input) {
      count
      electric {
        _id
        uid
        buId
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const CREATE_ELECTRIC = gql`
  mutation CreateElectric($input: CreateElectricDto!) {
    createElectric(input: $input) {
      electric {
        _id
        uid
        buId
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const UPDATE_ELECTRIC = gql`
  mutation UpdateElectric($input: UpdateElectricDto!) {
    updateElectric(input: $input) {
      electric {
        _id
        uid
        buId
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const DELETE_ELECTRIC = gql`
  mutation DeleteElectric($input: DeleteElectricDto!) {
    deleteElectric(input: $input) {
      electric {
        _id
        uid
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const RESTORE_DELETE_ELECTRIC = gql`
  mutation RestoreDeleteElectric($input: RestoreDeleteElectricDto!) {
    restoreDeleteElectric(input: $input) {
      electric {
        _id
        uid
        buId
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;
