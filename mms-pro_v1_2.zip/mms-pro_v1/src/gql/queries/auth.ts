import { gql } from "@apollo/client";

// Login query (Updated)
export const LOGIN_QUERY = gql`
  query Login($input: LoginDto!) {
    login(input: $input) {
      _id
      token
      refreshToken
    }
  }
`;

// Login mutation (Legacy)
export const AUTH_LOGIN = gql`
  mutation Login($loginInput: LoginInput!) {
    login(loginInput: $loginInput) {
      accessToken
      refreshToken
      data {
        createdAt
        updatedAt
        empID
        fNameLa
        userName
        lNameLa
        fNameEn
        lNameEn
        nickNameLa
        nickNameEn
        genderID
        phone
        email
        dob
      }
    }
  }
`;

// Service Account Sign In (Active) - เป็น Query ไม่ใช่ Mutation
export const SERVICE_ACCOUNT_SIGNIN = gql`
  query ServiceAccountSignin($input: ServiceAccountSigninDto!) {
    serviceAccountSignin(input: $input) {
      authorization
      business
    }
  }
`;
