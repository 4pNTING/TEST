import { gql } from "@apollo/client";

export const LOAD_FIXED_AMOUNT = gql`
  query LoadFixedAmount($input: LoadFixedAmountDto!) {
    loadFixedAmount(input: $input) {
      count
      fixedAmount {
        _id
        uniqueId
        uid
        buId
        amount
        method
        isActive
        selection
        createdAt
        updatedAt
      }
    }
  }
`;

export const CREATE_FIXED_AMOUNT = gql`
  mutation CreateFixedAmount($input: CreateFixedAmountDto!) {
    createFixedAmount(input: $input) {
      fixedAmount {
        _id
        uniqueId
        uid
        buId
        amount
        method
        isActive
        selection
        createdAt
        updatedAt
      }
    }
  }
`;

export const UPDATE_FIXED_AMOUNT = gql`
  mutation UpdateFixedAmount($input: UpdateFixedAmountDto!) {
    updateFixedAmount(input: $input) {
      fixedAmount {
        _id
        uniqueId
        uid
        buId
        amount
        method
        isActive
        selection
        createdAt
        updatedAt
      }
    }
  }
`;

export const DELETE_FIXED_AMOUNT = gql`
  mutation DeleteFixedAmount($input: DeleteFixedAmountDto!) {
    deleteFixedAmount(input: $input) {
      fixedAmount {
        _id
        uniqueId
        uid
        amount
        method
        isActive
        selection
        updatedAt
      }
    }
  }
`;

export const RESTORE_DELETE_FIXED_AMOUNT = gql`
  mutation RestoreDeleteFixedAmount($input: RestoreDeleteFixedAmountDto!) {
    restoreDeleteFixedAmount(input: $input) {
      fixedAmount {
        _id
        uniqueId
        uid
        buId
        amount
        method
        isActive
        selection
        createdAt
        updatedAt
      }
    }
  }
`;

export const UPDATE_FIXED_AMOUNT_SELECTION = gql`
  mutation UpdateFixedAmountSelection($input: UpdateFixedAmountSelectionDto!) {
    updateFixedAmountSelection(input: $input) {
      fixedAmount {
        _id
        uniqueId
        uid
        buId
        amount
        method
        isActive
        selection
        createdAt
        updatedAt
      }
    }
  }
`;
