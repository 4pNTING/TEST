import { gql } from "@apollo/client";

export const LOAD_ROOM_AREA = gql`
  query LoadRoomArea($input: LoadRoomAreaDto!) {
    loadRoomArea(input: $input) {
      count
      roomArea {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        createdBy
        updatedBy
        buId
        zoneId
        roomAreaCategoryId
        name
        wide
        long
        moreArea
        totalArea
        amount
        centralAmount
        totalAmount
        totalAreaAmount
        totalAreaCentralAmount
        currency
        holdStatus
        agentHoldStatus
        status
        zone {
          _id
          uniqueId
          uid
          isActive
          createdAt
          buId
          name
        }
        roomAreaCategory {
          _id
          uniqueId
          uid
          isActive
          createdAt
          name
        }
        roomAreaOwnership {
          _id
          uniqueId
          uid
          isActive
          createdAt
          updatedAt
          buId
          roomAreaId
          firstName
          lastName
          phoneNumber
          address
          fileUrl
          status
        }
        roomAreaOwnershipAgent {
          _id
          uniqueId
          uid
          isActive
          createdAt
          updatedAt
          buId
          roomAreaId
          roomAreaOwnershipId
          status
          startedAt
          endedAt
          note
          fileUrl
        }
      }
    }
  }
`;

export const CREATE_ROOM_AREA = gql`
  mutation CreateRoomArea($input: CreateRoomAreaDto!) {
    createRoomArea(input: $input) {
      roomArea {
        _id
        uniqueId
        uid
        name
        wide
        long
        moreArea
        totalArea
        amount
        centralAmount
        totalAmount
        totalAreaAmount
        totalAreaCentralAmount
        currency
        zoneId
        roomAreaCategoryId
        status
        holdStatus
        agentHoldStatus
        buId
        isActive
        createdAt
        updatedAt
        zone {
          _id
          uniqueId
          uid
          isActive
          createdAt
          buId
          name
        }
        roomAreaCategory {
          _id
          uniqueId
          uid
          isActive
          createdAt
          name
        }
          roomAreaOwnership {
                _id
                uniqueId
                uid
                isActive
                createdAt
                updatedAt
                buId
                roomAreaId
                firstName
                lastName
                phoneNumber
                address
                fileUrl
                status
            }
            roomAreaOwnershipAgent {
                _id
                uniqueId
                uid
                isActive
                createdAt
                updatedAt
                buId
                roomAreaId
                roomAreaOwnershipId
                status
                startedAt
                endedAt
                note
                fileUrl
            }
      }
    }
  }
`;

export const UPDATE_ROOM_AREA = gql`
  mutation UpdateRoomArea($input: UpdateRoomAreaDto!) {
    updateRoomArea(input: $input) {
      roomArea {
        _id
        uniqueId
        uid
        name
        wide
        long
        moreArea
        totalArea
        amount
        centralAmount
        totalAmount
        totalAreaAmount
        totalAreaCentralAmount
        currency
        zoneId
        roomAreaCategoryId
        status
        holdStatus
        agentHoldStatus
        buId
        isActive
        createdAt
        updatedAt
        zone {
          _id
          uniqueId
          uid
          isActive
          createdAt
          buId
          name
        }
        roomAreaCategory {
          _id
          uniqueId
          uid
          isActive
          createdAt
          name
        }
          roomAreaOwnership {
                _id
                uniqueId
                uid
                isActive
                createdAt
                updatedAt
                buId
                roomAreaId
                firstName
                lastName
                phoneNumber
                address
                fileUrl
                status
            }
            roomAreaOwnershipAgent {
                _id
                uniqueId
                uid
                isActive
                createdAt
                updatedAt
                buId
                roomAreaId
                roomAreaOwnershipId
                status
                startedAt
                endedAt
                note
                fileUrl
            }

      }
    }
  }
`;

export const DELETE_ROOM_AREA = gql`
  mutation DeleteRoomArea($input: DeleteRoomAreaDto!) {
    deleteRoomArea(input: $input) {
      roomArea {
        _id
        uniqueId
        uid
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const RESTORE_DELETE_ROOM_AREA = gql`
  mutation RestoreDeleteRoomArea($input: RestoreDeleteRoomAreaDto!) {
    restoreDeleteRoomArea(input: $input) {
      roomArea {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        createdBy
        updatedBy
        buId
        zoneId
        roomAreaCategoryId
        name
        wide
        long
        moreArea
        totalArea
        amount
        centralAmount
        totalAmount
        totalAreaAmount
        totalAreaCentralAmount
        currency
        holdStatus
        agentHoldStatus
        status
        zone {
          _id
          uniqueId
          uid
          isActive
          createdAt
          buId
          name
        }
        roomAreaCategory {
          _id
          uniqueId
          uid
          isActive
          createdAt
          name
        }
          roomAreaOwnership {
                _id
                uniqueId
                uid
                isActive
                createdAt
                updatedAt
                buId
                roomAreaId
                firstName
                lastName
                phoneNumber
                address
                fileUrl
                status
            }
            roomAreaOwnershipAgent {
                _id
                uniqueId
                uid
                isActive
                createdAt
                updatedAt
                buId
                roomAreaId
                roomAreaOwnershipId
                status
                startedAt
                endedAt
                note
                fileUrl
            }
      }
    }
  }
`;
