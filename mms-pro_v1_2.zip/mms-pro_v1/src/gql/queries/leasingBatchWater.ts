import { gql } from "@apollo/client";

export const LOAD_LEASING_BATCH_WATER = gql`
  query LoadLeasingBatchWater($input: LoadLeasingBatchWaterDto!) {
    loadLeasingBatchWater(input: $input) {
      count
      leasingBatchWater {
        _id
        uid
        uniqueId
        name
        note
        status
        buId
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
      }
    }
  }
`;

export const CREATE_LEASING_BATCH_WATER = gql`
  mutation CreateLeasingBatchWater($input: CreateLeasingBatchWaterDto!) {
    createLeasingBatchWater(input: $input) {
      leasingBatchWater {
        _id
        uid
        uniqueId
        name
        note
        status
        buId
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
      }
    }
  }
`;

export const UPDATE_LEASING_BATCH_WATER = gql`
  mutation UpdateLeasingBatchWater($input: UpdateLeasingBatchWaterDto!) {
    updateLeasingBatchWater(input: $input) {
      leasingBatchWater {
        _id
        uid
        uniqueId
        name
        note
        status
        buId
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
      }
    }
  }
`;

export const DELETE_LEASING_BATCH_WATER = gql`
  mutation DeleteLeasingBatchWater($input: DeleteLeasingBatchWaterDto!) {
    deleteLeasingBatchWater(input: $input) {
      leasingBatchWater {
        _id
        uid
        name
        isActive
        updatedAt
        updatedBy
      }
    }
  }
`;

export const UPDATE_SUBMIT_LEASING_BATCH_WATER = gql`
  mutation UpdateSubmitLeasingBatchWater($input: UpdateSubmitLeasingBatchWaterDto!) {
    updateSubmitLeasingBatchWater(input: $input) {
      leasingBatchWater {
        _id
        uid
        uniqueId
        name
        note
        status
        buId
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
      }
    }
  }
`;

export const UPDATE_CONFIRM_LEASING_BATCH_WATER = gql`
  mutation UpdateConfirmLeasingBatchWater($input: UpdateConfirmLeasingBatchWaterDto!) {
    updateConfirmLeasingBatchWater(input: $input) {
      leasingBatchWater {
        _id
        uid
        uniqueId
        name
        note
        status
        buId
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
      }
    }
  }
`;

export const UPDATE_REJECT_LEASING_BATCH_WATER = gql`
  mutation UpdateRejectLeasingBatchWater($input: UpdateRejectLeasingBatchWaterDto!) {
    updateRejectLeasingBatchWater(input: $input) {
      leasingBatchWater {
        _id
        uid
        uniqueId
        name
        note
        status
        buId
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
      }
    }
  }
`;
