import { gql } from "@apollo/client";

// Query สำหรับดึงข้อมูล Draft (Leasing Water ที่พร้อมเพิ่มเข้า Batch)
export const LOAD_DRAFT_LEASING_BATCH_WATER_DETAIL = gql`
  query LoadDraftLeasingBatchWaterDetail($input: LoadDraftLeasingBatchWaterDetailDto!) {
    loadDraftLeasingBatchWaterDetail(input: $input) {
      count
      items {
        leasingWaterId
        leasingIndexId
        lastNumber
        currency
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomAreaId
          }
        }
        water {
          _id
          name
        }
        fixedAmount {
          _id
          amount
        }
        maintenanceFixedAmount {
          _id
          amount
        }
      }
    }
  }
`;

export const LOAD_LEASING_BATCH_WATER_DETAIL = gql`
  query LoadLeasingBatchWaterDetail($input: LoadLeasingBatchWaterDetailDto!) {
    loadLeasingBatchWaterDetail(input: $input) {
      count
      leasingBatchWaterDetail {
        _id
        uid
        uniqueId
        leasingBatchWaterId
        leasingIndexId
        leasingWaterId
        waterId
        lastNumber
        currentNumber
        unitAmount
        sumUnitAmount
        sumAmount
        amount
        maintenanceAmount
        fixedAmountId
        maintenanceFixedAmountId
        currency
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        buId
        customer {
          _id
          firstName
          lastName
          phoneNumber
        }
        water {
          _id
          name
        }
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomAreaId
          }
        }
        fixedAmount {
          _id
          amount
        }
        maintenanceFixedAmount {
          _id
          amount
        }
      }
    }
  }
`;

export const CREATE_LEASING_BATCH_WATER_DETAIL = gql`
  mutation CreateLeasingBatchWaterDetail($input: CreateLeasingBatchWaterDetailDto!) {
    createLeasingBatchWaterDetail(input: $input) {
      leasingBatchWaterDetail {
        _id
        uid
        uniqueId
        leasingBatchWaterId
        leasingIndexId
        leasingWaterId
        waterId
        lastNumber
        currentNumber
        unitAmount
        amount
        sumUnitAmount
        sumAmount
        maintenanceAmount
        fixedAmountId
        maintenanceFixedAmountId
        currency
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        customer {
          _id
          firstName
          lastName
          phoneNumber
        }
        water {
          _id
          name
        }
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomAreaId
          }
        }
        fixedAmount {
          _id
          amount
        }
        maintenanceFixedAmount {
          _id
          amount
        }
      }
    }
  }
`;

export const UPDATE_LEASING_BATCH_WATER_DETAIL = gql`
  mutation UpdateLeasingBatchWaterDetail($input: UpdateLeasingBatchWaterDetailDto!) {
    updateLeasingBatchWaterDetail(input: $input) {
      leasingBatchWaterDetail {
        _id
        uid
        uniqueId
        leasingBatchWaterId
        leasingIndexId
        leasingWaterId
        waterId
        lastNumber
        currentNumber
        unitAmount
        amount
        sumUnitAmount
        sumAmount
        maintenanceAmount
        fixedAmountId
        maintenanceFixedAmountId
        currency
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        customer {
          _id
          firstName
          lastName
          phoneNumber
        }
        water {
          _id
          name
        }
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomAreaId
          }
        }
        fixedAmount {
          _id
          amount
        }
        maintenanceFixedAmount {
          _id
          amount
        }
      }
    }
  }
`;

export const DELETE_LEASING_BATCH_WATER_DETAIL = gql`
  mutation DeleteLeasingBatchWaterDetail($input: DeleteLeasingBatchWaterDetailDto!) {
    deleteLeasingBatchWaterDetail(input: $input) {
      leasingBatchWaterDetail {
        _id
        uid
        isActive
        updatedAt
        updatedBy
      }
    }
  }
`;

// Mutation สำหรับสร้าง Batch Detail จาก Draft (Multiple items)
export const CREATE_BATCH_WATER_DETAILS_FROM_DRAFT = gql`
  mutation CreateLeasingBatchWaterDetail($input: CreateLeasingBatchWaterDetailDto!) {
    createLeasingBatchWaterDetail(input: $input) {
      leasingBatchWaterDetail {
        _id
        uid
        uniqueId
        leasingBatchWaterId
        leasingIndexId
        lastNumber
        currentNumber
        unitAmount
        amount
        sumUnitAmount
        sumAmount
        currency
        status
        isActive
        customer {
          _id
          firstName
          lastName
          phoneNumber
        }
        leasingIndex {
          _id
          contractNo
        }
        fixedAmount {
          _id
          amount
        }
        maintenanceFixedAmount {
          _id
          amount
        }
      }
    }
  }
`;
