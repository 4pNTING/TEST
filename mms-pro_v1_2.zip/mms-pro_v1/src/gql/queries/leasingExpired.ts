import { gql } from "@apollo/client";

export const LOAD_LEASING_INDEX_WILL_BE_EXPIRED_SOON = gql`
  query LoadLeasingIndexWillBeExpiredSoon($input: LoadLeasingIndexWillBeExpiredSoonDto!) {
    loadLeasingIndexWillBeExpiredSoon(input: $input) {
      count
      leasingIndex {
        _id
        buId
        uid
        uniqueId
        contractNo
        contractCategory
        shopName
        shopCategoryId
        customerId
        paymentMethod
        fileUrl
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        customer {
          _id
          firstName
          lastName
          phoneNumber
          nationality
          fileUrl
        }
        leasingDateTime {
          _id
          startedAt
          endedAt
          endedPayAt
        }
        leasingSum {
          _id
          amount
          centralAmount
          discountAmount
          discountCentralAmount
          sumAmount
          depositAmount
          depositCurrency
          currency
        }
         leasingOrder {
          _id
          roomAreaId
          name
          wide
          long
          amount
          totalAmount
        }
      }
    }
  }
`;
