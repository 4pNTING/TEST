import { gql } from '@apollo/client';


export const LOAD_ROOM_AREA_CATEGORY = gql`
  query LoadRoomAreaCategory($input: LoadRoomAreaCategoryDto!) {
    loadRoomAreaCategory(input: $input) {
      count
      roomAreaCategory {
        _id
        uniqueId
        uid
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const CREATE_ROOM_AREA_CATEGORY = gql`
  mutation CreateRoomAreaCategory($input: CreateRoomAreaCategoryDto!) {
    createRoomAreaCategory(input: $input) {
      roomAreaCategory {
        _id
        uniqueId
        uid
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const UPDATE_ROOM_AREA_CATEGORY = gql`
  mutation UpdateRoomAreaCategory($input: UpdateRoomAreaCategoryDto!) {
    updateRoomAreaCategory(input: $input) {
      roomAreaCategory {
        _id
        uniqueId
        uid
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const DELETE_ROOM_AREA_CATEGORY = gql`
  mutation DeleteRoomAreaCategory($input: DeleteRoomAreaCategoryDto!) {
    deleteRoomAreaCategory(input: $input) {
      roomAreaCategory {
        _id
        uniqueId
        uid
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const RESTORE_DELETE_ROOM_AREA_CATEGORY = gql`
  mutation RestoreDeleteRoomAreaCategory($input: RestoreDeleteRoomAreaCategoryDto!) {
    restoreDeleteRoomAreaCategory(input: $input) {
      roomAreaCategory {
        _id
        uniqueId
        uid
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;
