import { gql } from "@apollo/client";

// Query สำหรับดึงข้อมูล Draft (Leasing Batch Electric Detail ที่พร้อมเพิ่มเข้า Batch)
export const LOAD_DRAFT_LEASING_BATCH_ELECTRIC_DETAIL = gql`
  query LoadDraftLeasingBatchElectricDetail($input: LoadDraftLeasingBatchElectricDetailDto!) {
    loadDraftLeasingBatchElectricDetail(input: $input) {
      count
      items {
        leasingElectricId
        leasingIndexId
        lastNumber
        currency
        electricityConversionFee
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomAreaId
          }
        }
        electric {
          _id
          name
        }
        fixedAmount {
          _id
          amount
        }
      }
    }
  }
`;

export const LOAD_LEASING_BATCH_ELECTRIC_DETAIL = gql`
  query LoadLeasingBatchElectricDetail($input: LoadLeasingBatchElectricDetailDto!) {
    loadLeasingBatchElectricDetail(input: $input) {
      count
      leasingBatchElectricDetail {
        _id
        uid
        uniqueId
        leasingBatchElectricId
        leasingIndexId
        leasingElectricId
        electricId
        lastNumber
        currentNumber
        unitAmount
        amount
        sumUnitAmount
        sumAmount
        electricityConversionFee
        fixedAmountId
        currency
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        buId
        customer {
          _id
          firstName
          lastName
          phoneNumber
        }
        electric {
          _id
          name
        }
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomAreaId
          }
   
        }
        fixedAmount {
          _id
          amount
        }
      }
    }
  }
`;

export const CREATE_LEASING_BATCH_ELECTRIC_DETAIL = gql`
  mutation CreateLeasingBatchElectricDetail($input: CreateLeasingBatchElectricDetailDto!) {
    createLeasingBatchElectricDetail(input: $input) {
      leasingBatchElectricDetail {
        _id
        uid
        uniqueId
        leasingBatchElectricId
        leasingIndexId
        leasingElectricId
        electricId
        lastNumber
        currentNumber
        unitAmount
        amount
        sumUnitAmount
        sumAmount
        electricityConversionFee
        fixedAmountId
        currency
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomAreaId
          }
        }
        fixedAmount {
          _id
          amount
        }
      }
    }
  }
`;

export const UPDATE_LEASING_BATCH_ELECTRIC_DETAIL = gql`
  mutation UpdateLeasingBatchElectricDetail($input: UpdateLeasingBatchElectricDetailDto!) {
    updateLeasingBatchElectricDetail(input: $input) {
      leasingBatchElectricDetail {
        _id
        uid
        uniqueId
        leasingBatchElectricId
        leasingIndexId
        leasingElectricId
        electricId
        lastNumber
        currentNumber
        unitAmount
        amount
        sumUnitAmount
        sumAmount
        electricityConversionFee
        fixedAmountId
        currency
        status
        isActive
        createdAt
        createdBy
        updatedAt
        updatedBy
        customer {
          _id
          firstName
          lastName
          phoneNumber
        }
        electric {
          _id
          name
        }
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomAreaId
          }
        }
        fixedAmount {
          _id
          amount
        }
      }
    }
  }
`;

export const DELETE_LEASING_BATCH_ELECTRIC_DETAIL = gql`
  mutation DeleteLeasingBatchElectricDetail($input: DeleteLeasingBatchElectricDetailDto!) {
    deleteLeasingBatchElectricDetail(input: $input) {
      leasingBatchElectricDetail {
        _id
        uid
        isActive
        updatedAt
        updatedBy
      }
    }
  }
`;

// Mutation สำหรับสร้าง Batch Detail จาก Draft (Multiple items)
export const CREATE_BATCH_DETAILS_FROM_DRAFT = gql`
  mutation CreateBatchDetailsFromDraft($input: CreateBatchDetailsFromDraftDto!) {
    createBatchDetailsFromDraft(input: $input) {
      count
      leasingBatchElectricDetail {
        _id
        uid
        uniqueId
        leasingBatchElectricId
        leasingIndexId
        leasingElectricId
        electricId
        lastNumber
        currentNumber
        status
        isActive
        customer {
          _id
          firstName
          lastName
          phoneNumber
        }
        electric {
          _id
          name
        }
        leasingIndex {
          _id
          contractNo
          customer {
            _id
            firstName
            lastName
            phoneNumber
          }
          leasingOrder {
            _id
            name
            roomAreaId
          }
        }
        fixedAmount {
          _id
          amount
        }
      }
    }
  }
`;
