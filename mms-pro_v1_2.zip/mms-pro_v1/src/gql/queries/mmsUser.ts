import { gql } from "@apollo/client";

// MMS User Queries - Using correct GraphQL type names
export const LOAD_MMS_USER = gql`
  query LoadMmsUser($input: LoadMMSUserDto!) {
    loadUser(input: $input) {
      count
      user {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        createdBy
        updatedBy
        buId
        empId
        roleName
        permission {
          feature
          action
        }
      }
    }
  }
`;

export const CREATE_MMS_USER = gql`
  mutation CreateUser($input: CreateMMSUserDto!) {
    createUser(input: $input) {
      user {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        buId
        empId
        roleName
        permission {
          feature
          action
        }
      }
    }
  }
`;

export const UPDATE_MMS_USER = gql`
  mutation UpdateUser($input: UpdateMMSUserDto!) {
    updateUser(input: $input) {
      user {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        buId
        empId
        roleName
        permission {
          feature
          action
        }
      }
    }
  }
`;

export const DELETE_MMS_USER = gql`
  mutation DeleteUser($input: DeleteMMSUserDto!) {
    deleteUser(input: $input) {
      user {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const RESTORE_DELETE_MMS_USER = gql`
  mutation RestoreDeleteUser($input: RestoreDeleteMMSUserDto!) {
    restoreDeleteUser(input: $input) {
      user {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        buId
        empId
        roleName
        permission {
          feature
          action
        }
      }
    }
  }
`;

// Employee Query - Load Employee by ID
export const LOAD_EMPLOYEE_BY_ID = gql`
  query EmployeeLoadById($input: LoadEmployeeByIdDto!) {
    employeeLoadById(input: $input) {
      _id
      empID
      empNumber
      fNameLa
      lNameLa
      fNameEn
      lNameEn
      nickNameLa
      nickNameEn
      phone
      email
      userName
      genderID
      dob
      createdAt
      companyId {
        _id
        enName
        laName
        companyCode
      }
      depId {
        _id
        enName
        laName
      }
      levelId {
        _id
        enName
        laName
      }
    }
  }
`;

// Employee Query - Search Employees
export const SEARCH_EMPLOYEES = gql`
  query EmployeeLoadAll($query: QueryProps!) {
    employeeLoadAll(query: $query) {
      items {
        _id
        empID
        empNumber
        fNameLa
        lNameLa
        fNameEn
        lNameEn
        nickNameLa
        nickNameEn
        phone
        email
        userName
        companyId {
          _id
          enName
          laName
          companyCode
        }
        depId {
          _id
          enName
          laName
        }
        levelId {
          _id
          enName
          laName
        }
      }
      total
    }
  }
`;

// Company Query - Load All Companies
export const LOAD_ALL_COMPANIES = gql`
  query CompanyLoadAll($query: QueryProps!) {
    companyLoadAll(query: $query) {
      items {
        _id
        createdAt
        updatedAt
        companyCode
        laName
        enName
      }
    }
  }
`;

