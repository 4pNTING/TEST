import { gql } from "@apollo/client";


export const LOAD_ZONE = gql`
  query LoadZone($input: LoadZoneDto!) {
    loadZone(input: $input) {
      count
      zone {
        _id
        uniqueId
        uid
        buId
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const CREATE_ZONE = gql`
  mutation CreateZone($input: CreateZoneDto!) {
    createZone(input: $input) {
      zone {
        _id
        uniqueId
        uid
        buId
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const UPDATE_ZONE = gql`
  mutation UpdateZone($input: UpdateZoneDto!) {
    updateZone(input: $input) {
      zone {
        _id
        uniqueId
        uid
        buId
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;

export const DELETE_ZONE = gql`
  mutation DeleteZone($input: DeleteZoneDto!) {
    deleteZone(input: $input) {
      zone {
        _id
        uniqueId
        uid
        name
        isActive
        updatedAt
      }
    }
  }
`;

export const RESTORE_DELETE_ZONE = gql`
  mutation RestoreDeleteZone($input: RestoreDeleteZoneDto!) {
    restoreDeleteZone(input: $input) {
      zone {
        _id
        uniqueId
        uid
        buId
        name
        isActive
        createdAt
        updatedAt
      }
    }
  }
`;
