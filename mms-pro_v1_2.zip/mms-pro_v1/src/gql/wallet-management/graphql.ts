/* eslint-disable */
export type Maybe<T> = T | null;
export type InputMaybe<T> = Maybe<T>;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
export type MakeEmpty<T extends { [key: string]: unknown }, K extends keyof T> = { [_ in K]?: never };
export type Incremental<T> = T | { [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: { input: string; output: string; }
  String: { input: string; output: string; }
  Boolean: { input: boolean; output: boolean; }
  Int: { input: number; output: number; }
  Float: { input: number; output: number; }
};

export type AddAccessToUserBuByAdminDto = {
  serviceAccountId?: InputMaybe<Scalars['String']['input']>;
  userId?: InputMaybe<Scalars['String']['input']>;
};

export type AddAccessToUserBuByAdminDtoResponse = {
  __typename?: 'AddAccessToUserBUByAdminDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type AdminConfigType = {
  __typename?: 'AdminConfigType';
  assignBy?: Maybe<Scalars['String']['output']>;
  assignDate?: Maybe<Scalars['String']['output']>;
  assignId?: Maybe<Scalars['String']['output']>;
  level?: Maybe<Scalars['String']['output']>;
};

export type AdminInfoType = {
  __typename?: 'AdminInfoType';
  _id?: Maybe<Scalars['String']['output']>;
  config?: Maybe<AdminConfigType>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  password?: Maybe<Scalars['String']['output']>;
  phoneNumber?: Maybe<Scalars['String']['output']>;
  platform?: Maybe<Scalars['String']['output']>;
  prefix?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  username?: Maybe<Scalars['String']['output']>;
};

export type AdminProfileImageInput = {
  cover?: InputMaybe<Scalars['String']['input']>;
  profile?: InputMaybe<Scalars['String']['input']>;
};

export type AdminProfileImageType = {
  __typename?: 'AdminProfileImageType';
  cover?: Maybe<Scalars['String']['output']>;
  profile?: Maybe<Scalars['String']['output']>;
};

export type AdminProfileType = {
  __typename?: 'AdminProfileType';
  _id?: Maybe<Scalars['String']['output']>;
  address?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  district?: Maybe<Scalars['String']['output']>;
  firstName?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  image?: Maybe<AdminProfileImageType>;
  isActive?: Maybe<Scalars['String']['output']>;
  lastName?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  postcode?: Maybe<Scalars['String']['output']>;
  province?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  village?: Maybe<Scalars['String']['output']>;
};

export type AdminSignatureType = {
  __typename?: 'AdminSignatureType';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  privateKey?: Maybe<Scalars['String']['output']>;
  publicKey?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type AdminSigninDto = {
  password: Scalars['String']['input'];
  username: Scalars['String']['input'];
};

export type AdminSigninDtoResponse = {
  __typename?: 'AdminSigninDtoResponse';
  authorization: Scalars['String']['output'];
};

export type AdminSignupDto = {
  firstName: Scalars['String']['input'];
  lastName: Scalars['String']['input'];
  password: Scalars['String']['input'];
  super?: InputMaybe<Scalars['String']['input']>;
  username: Scalars['String']['input'];
};

export type AdminSignupDtoResponse = {
  __typename?: 'AdminSignupDtoResponse';
  admin?: Maybe<AdminType>;
};

export type AdminType = {
  __typename?: 'AdminType';
  admin?: Maybe<AdminInfoType>;
  adminProfile?: Maybe<AdminProfileType>;
  adminSignature?: Maybe<AdminSignatureType>;
};

export type AdminValidateTokenDtoResponse = {
  __typename?: 'AdminValidateTokenDtoResponse';
  admin?: Maybe<AdminType>;
};

export type ChangeMerchantPasswordDto = {
  newPassword: Scalars['String']['input'];
  prePassword: Scalars['String']['input'];
};

export type ChangeMerchantPasswordResponseDto = {
  __typename?: 'ChangeMerchantPasswordResponseDto';
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ChangeMerchantUsernameByAdminDto = {
  merchantId: Scalars['String']['input'];
  newUsername: Scalars['String']['input'];
};

export type ChangeMerchantUsernameByAdminDtoResponse = {
  __typename?: 'ChangeMerchantUsernameByAdminDtoResponse';
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ChangeMerchantUsernameDto = {
  newUsername: Scalars['String']['input'];
  password: Scalars['String']['input'];
  preUsername: Scalars['String']['input'];
};

export type ChangeMerchantUsernameDtoResponse = {
  __typename?: 'ChangeMerchantUsernameDtoResponse';
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ChangeServiceAccountPasswordDto = {
  newPassword: Scalars['String']['input'];
  prePassword: Scalars['String']['input'];
};

export type ChangeServiceAccountPasswordResponseDto = {
  __typename?: 'ChangeServiceAccountPasswordResponseDto';
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ChangeServiceAccountUsernameByAdminDto = {
  newUsername: Scalars['String']['input'];
  serviceAccountId: Scalars['String']['input'];
};

export type ChangeServiceAccountUsernameByAdminDtoResponse = {
  __typename?: 'ChangeServiceAccountUsernameByAdminDtoResponse';
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ChangeServiceAccountUsernameDto = {
  newUsername: Scalars['String']['input'];
  password: Scalars['String']['input'];
  preUsername: Scalars['String']['input'];
};

export type ChangeServiceAccountUsernameDtoResponse = {
  __typename?: 'ChangeServiceAccountUsernameDtoResponse';
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ChangeTopupTransactionMethodDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
  topupMethod?: InputMaybe<Scalars['String']['input']>;
};

export type ChangeTopupTransactionMethodDtoResponse = {
  __typename?: 'ChangeTopupTransactionMethodDtoResponse';
  topup?: Maybe<TopupType>;
};

export type CheckExistMerchantByUsernameDto = {
  username?: InputMaybe<Scalars['String']['input']>;
};

export type CheckExistMerchantByUsernameDtoResponse = {
  __typename?: 'CheckExistMerchantByUsernameDtoResponse';
  merchant?: Maybe<MerchantType>;
};

export type CheckExistUserByUsernameDto = {
  username?: InputMaybe<Scalars['String']['input']>;
};

export type CheckExistUserByUsernameDtoResponse = {
  __typename?: 'CheckExistUserByUsernameDtoResponse';
  user?: Maybe<UserType>;
};

export type CheckExistWalletCardDto = {
  cardNo: Scalars['String']['input'];
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type CheckExistWalletCardDtoResponse = {
  __typename?: 'CheckExistWalletCardDtoResponse';
  wallet?: Maybe<WalletType>;
  walletCard?: Maybe<WalletCardType>;
};

export type ConditionInput = {
  field?: InputMaybe<Scalars['String']['input']>;
  value?: InputMaybe<Scalars['String']['input']>;
};

export type ConfirmCreateCustomerWithdrawCashToBu = {
  _id: Scalars['String']['input'];
};

export type ConfirmCreateCustomerWithdrawCashToBuResponse = {
  __typename?: 'ConfirmCreateCustomerWithdrawCashToBUResponse';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  generateId?: Maybe<Scalars['String']['output']>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
  withdraw?: Maybe<WithdrawType>;
};

export type ConfirmCreateIssuedDto = {
  _id: Scalars['String']['input'];
};

export type ConfirmCreateIssuedDtoResponse = {
  __typename?: 'ConfirmCreateIssuedDtoResponse';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  generateId?: Maybe<Scalars['String']['output']>;
  issued?: Maybe<IssuedType>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
};

export type ConfirmCreateMerchantDividendDto = {
  _id: Scalars['String']['input'];
};

export type ConfirmCreateMerchantDividendDtoResponse = {
  __typename?: 'ConfirmCreateMerchantDividendDtoResponse';
  merchantDividend?: Maybe<MerchantDividendType>;
};

export type ConfirmCreateMerchantDividendQueueDto = {
  customTime: Scalars['String']['input'];
};

export type ConfirmCreateMerchantDividendQueueDtoResponse = {
  __typename?: 'ConfirmCreateMerchantDividendQueueDtoResponse';
  isComplete?: Maybe<Scalars['Boolean']['output']>;
};

export type ConfirmCreateTopupBatchDto = {
  _id: Scalars['String']['input'];
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type ConfirmCreateTopupBatchDtoResponse = {
  __typename?: 'ConfirmCreateTopupBatchDtoResponse';
  topupBatch?: Maybe<TopupBatchType>;
};

export type ConfirmCreateUserOtpDto = {
  otp: Scalars['String']['input'];
  phoneNumber: Scalars['String']['input'];
};

export type ConfirmCreateUserOtpDtoResponse = {
  __typename?: 'ConfirmCreateUserOTPDtoResponse';
  authorization?: Maybe<Scalars['String']['output']>;
  key?: Maybe<Scalars['String']['output']>;
};

export type ConfirmCreateWalletMerchantOrderForCardDto = {
  debugDateTime?: InputMaybe<Scalars['String']['input']>;
  debugKey?: InputMaybe<Scalars['String']['input']>;
  order: Scalars['String']['input'];
  walletCardId: Scalars['String']['input'];
};

export type ConfirmCreateWalletMerchantOrderForCardDtoResponse = {
  __typename?: 'ConfirmCreateWalletMerchantOrderForCardDtoResponse';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  generateId?: Maybe<Scalars['String']['output']>;
  remainAmount?: Maybe<Scalars['Float']['output']>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
};

export type CreateAcceptorAccountSignatureDto = {
  fullname: Scalars['String']['input'];
};

export type CreateAcceptorAccountSignatureDtoResponse = {
  __typename?: 'CreateAcceptorAccountSignatureDtoResponse';
  _id?: Maybe<Scalars['String']['output']>;
};

export type CreateBuTopupCashToCardDto = {
  amount: Scalars['Float']['input'];
  debugDateTime?: InputMaybe<Scalars['String']['input']>;
  debugKey?: InputMaybe<Scalars['String']['input']>;
  description: Scalars['String']['input'];
  receiver: Scalars['String']['input'];
  sender?: InputMaybe<Scalars['String']['input']>;
  topupMethod: Scalars['String']['input'];
};

export type CreateBuTopupCashToCardDtoResponse = {
  __typename?: 'CreateBUTopupCashToCardDtoResponse';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  generateId?: Maybe<Scalars['String']['output']>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
  topup?: Maybe<TopupType>;
};

export type CreateBuTopupCashToCustomerDto = {
  amount: Scalars['Float']['input'];
  description: Scalars['String']['input'];
  receiver: Scalars['String']['input'];
  topupMethod: Scalars['String']['input'];
};

export type CreateBuTopupCashToCustomerDtoResponse = {
  __typename?: 'CreateBUTopupCashToCustomerDtoResponse';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  generateId?: Maybe<Scalars['String']['output']>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
  topup?: Maybe<TopupType>;
};

export type CreateBuTopupCashToStaffDto = {
  amount: Scalars['Float']['input'];
  description: Scalars['String']['input'];
  receiver: Scalars['String']['input'];
  sender: Scalars['String']['input'];
  topupMethod: Scalars['String']['input'];
};

export type CreateBuTopupCashToStaffDtoResponse = {
  __typename?: 'CreateBUTopupCashToStaffDtoResponse';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  generateId?: Maybe<Scalars['String']['output']>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
  topup?: Maybe<TopupType>;
};

export type CreateBuWalletDto = {
  firstName: Scalars['String']['input'];
  lastName: Scalars['String']['input'];
  level: Scalars['String']['input'];
  password: Scalars['String']['input'];
  username: Scalars['String']['input'];
};

export type CreateBuWalletDtoResponse = {
  __typename?: 'CreateBUWalletDtoResponse';
  wallet?: Maybe<WalletType>;
};

export type CreateCardTopupBatchDetailDto = {
  _id: Scalars['String']['input'];
  objects: Array<CreateCardTopupBatchDetailObject>;
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type CreateCardTopupBatchDetailDtoResponse = {
  __typename?: 'CreateCardTopupBatchDetailDtoResponse';
  topupBatch?: Maybe<TopupBatchType>;
  topupBatchDetail?: Maybe<Array<TopupBatchDetailType>>;
};

export type CreateCardTopupBatchDetailObject = {
  _id: Scalars['String']['input'];
  amount: Scalars['Float']['input'];
};

export type CreateCardWithdrawCashToBuDto = {
  debugDateTime?: InputMaybe<Scalars['String']['input']>;
  debugKey?: InputMaybe<Scalars['String']['input']>;
  description: Scalars['String']['input'];
  sender: Scalars['String']['input'];
};

export type CreateCardWithdrawCashToBuDtoResponse = {
  __typename?: 'CreateCardWithdrawCashToBUDtoResponse';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  generateId?: Maybe<Scalars['String']['output']>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
  withdraw?: Maybe<WithdrawType>;
};

export type CreateCustomerWithdrawCashToBuDto = {
  amount: Scalars['Float']['input'];
  description: Scalars['String']['input'];
};

export type CreateCustomerWithdrawCashToBuDtoResponse = {
  __typename?: 'CreateCustomerWithdrawCashToBUDtoResponse';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  generateId?: Maybe<Scalars['String']['output']>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
  withdraw?: Maybe<WithdrawType>;
};

export type CreateIssuedDto = {
  amount: Scalars['Float']['input'];
  description: Scalars['String']['input'];
  reference?: InputMaybe<IssuedReferenceInput>;
};

export type CreateIssuedDtoResponse = {
  __typename?: 'CreateIssuedDtoResponse';
  issued?: Maybe<IssuedType>;
};

export type CreateMerchantCategoryRequest = {
  name: Scalars['String']['input'];
};

export type CreateMerchantCategoryResponse = {
  __typename?: 'CreateMerchantCategoryResponse';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  laName?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type CreateMerchantDividendDto = {
  between: LoadReportBetweenInput;
};

export type CreateMerchantDividendDtoResponse = {
  __typename?: 'CreateMerchantDividendDtoResponse';
  merchantDividend?: Maybe<Array<Maybe<MerchantDividendType>>>;
};

export type CreateMerchantDividendQueueDto = {
  customTime: Scalars['String']['input'];
};

export type CreateMerchantDividendQueueDtoResponse = {
  __typename?: 'CreateMerchantDividendQueueDtoResponse';
  isComplete?: Maybe<Scalars['Boolean']['output']>;
};

export type CreateMerchantRequest = {
  email: Scalars['String']['input'];
  merchantCategoryId: Scalars['String']['input'];
  merchantCode: Scalars['String']['input'];
  name: Scalars['String']['input'];
  phoneNumber: Scalars['String']['input'];
  username: Scalars['String']['input'];
};

export type CreateMerchantResponse = {
  __typename?: 'CreateMerchantResponse';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  email?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  merchantCategory?: Maybe<MerchantCategoryModel>;
  merchantCategoryId?: Maybe<Scalars['Int']['output']>;
  merchantCode?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  phoneNumber?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  username?: Maybe<Scalars['String']['output']>;
};

export type CreateOnlyWalletDtoResponse = {
  __typename?: 'CreateOnlyWalletDtoResponse';
  wallet?: Maybe<WalletType>;
};

export type CreateRequestorAccountSignatureDto = {
  fullname: Scalars['String']['input'];
};

export type CreateRequestorAccountSignatureDtoResponse = {
  __typename?: 'CreateRequestorAccountSignatureDtoResponse';
  _id?: Maybe<Scalars['String']['output']>;
};

export type CreateRoleRequest = {
  name: Scalars['String']['input'];
};

export type CreateRoleResponse = {
  __typename?: 'CreateRoleResponse';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  enName?: Maybe<Scalars['String']['output']>;
  laName?: Maybe<Scalars['String']['output']>;
  level?: Maybe<Scalars['String']['output']>;
  menus?: Maybe<Array<RoleMenuModel>>;
  systemCode?: Maybe<Scalars['String']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type CreateServiceAccountSignatureDto = {
  username: Scalars['String']['input'];
};

export type CreateServiceAccountSignatureDtoResponse = {
  __typename?: 'CreateServiceAccountSignatureDtoResponse';
  _id?: Maybe<Scalars['String']['output']>;
};

export type CreateSmsRequest = {
  name: Scalars['String']['input'];
};

export type CreateSmsResponse = {
  __typename?: 'CreateSmsResponse';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type CreateSystemTopupCashToBuDto = {
  amount: Scalars['Float']['input'];
  description: Scalars['String']['input'];
  receiver: Scalars['String']['input'];
  topupMethod: Scalars['String']['input'];
};

export type CreateSystemTopupCashToBuDtoResponse = {
  __typename?: 'CreateSystemTopupCashToBUDtoResponse';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  generateId?: Maybe<Scalars['String']['output']>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
  topup?: Maybe<TopupType>;
};

export type CreateTopupBatchDto = {
  description: Scalars['String']['input'];
  target: Scalars['String']['input'];
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type CreateTopupBatchDtoResponse = {
  __typename?: 'CreateTopupBatchDtoResponse';
  topupBatch?: Maybe<TopupBatchType>;
};

export type CreateUserOtpDto = {
  expiredAt: Scalars['Int']['input'];
  otp: Scalars['String']['input'];
  phoneNumber: Scalars['String']['input'];
};

export type CreateUserOtpDtoResponse = {
  __typename?: 'CreateUserOTPDtoResponse';
  isComplete?: Maybe<Scalars['Boolean']['output']>;
};

export type CreateWalletCardDto = {
  attach?: InputMaybe<Scalars['String']['input']>;
  cardName: Scalars['String']['input'];
  cardNo: Scalars['String']['input'];
  cardType?: InputMaybe<Scalars['String']['input']>;
  staffId?: InputMaybe<Scalars['String']['input']>;
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type CreateWalletCardDtoResponse = {
  __typename?: 'CreateWalletCardDtoResponse';
  walletCard?: Maybe<WalletCardType>;
  walletCardAssignment?: Maybe<WalletCardAssignmentType>;
};

export type CreateWalletCategoryDto = {
  name?: InputMaybe<Scalars['String']['input']>;
  walletCategoryRoleId?: InputMaybe<Scalars['String']['input']>;
};

export type CreateWalletCategoryDtoResponse = {
  __typename?: 'CreateWalletCategoryDtoResponse';
  _id?: Maybe<Scalars['String']['output']>;
};

export type CreateWalletDto = {
  firstName: Scalars['String']['input'];
  key?: InputMaybe<Scalars['String']['input']>;
  lastName: Scalars['String']['input'];
  password?: InputMaybe<Scalars['String']['input']>;
  phoneNumber: Scalars['String']['input'];
};

export type CreateWalletDtoResponse = {
  __typename?: 'CreateWalletDtoResponse';
  authorization?: Maybe<Scalars['String']['output']>;
};

export type CreateWalletIssuerDto = {
  firstName: Scalars['String']['input'];
  lastName: Scalars['String']['input'];
  password: Scalars['String']['input'];
  username: Scalars['String']['input'];
};

export type CreateWalletIssuerDtoResponse = {
  __typename?: 'CreateWalletIssuerDtoResponse';
  wallet?: Maybe<WalletType>;
};

export type CreateWalletMerchantDto = {
  name: Scalars['String']['input'];
  password: Scalars['String']['input'];
  username: Scalars['String']['input'];
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type CreateWalletMerchantDtoResponse = {
  __typename?: 'CreateWalletMerchantDtoResponse';
  walletMerchant?: Maybe<WalletMerchantDto>;
};

export type CreateWalletMerchantOrderForCardDto = {
  amount: Scalars['Float']['input'];
  description: Scalars['String']['input'];
};

export type CreateWalletMerchantOrderForCardDtoResponse = {
  __typename?: 'CreateWalletMerchantOrderForCardDtoResponse';
  order?: Maybe<Scalars['String']['output']>;
};

export type CreateWalletMerchantQrDto = {
  merchantId: Scalars['String']['input'];
};

export type CreateWalletMerchantQrDtoResponse = {
  __typename?: 'CreateWalletMerchantQRDtoResponse';
  qr?: Maybe<Scalars['String']['output']>;
};

export type CreateWalletQrDto = {
  walletId: Scalars['String']['input'];
};

export type CreateWalletQrDtoResponse = {
  __typename?: 'CreateWalletQRDtoResponse';
  qr?: Maybe<Scalars['String']['output']>;
};

export type CreateWalletQrTransferDto = {
  amount: Scalars['Float']['input'];
  description: Scalars['String']['input'];
  qr: Scalars['String']['input'];
};

export type CreateWalletQrTransferDtoResponse = {
  __typename?: 'CreateWalletQRTransferDtoResponse';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  generateId?: Maybe<Scalars['String']['output']>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
};

export type CreateWalletStaffDto = {
  staffId: Scalars['String']['input'];
  walletId: Scalars['String']['input'];
};

export type CreateWalletStaffDtoResponse = {
  __typename?: 'CreateWalletStaffDtoResponse';
  walletStaff?: Maybe<WalletStaffType>;
};

export type CreateWalletTransferDto = {
  amount: Scalars['Float']['input'];
  description: Scalars['String']['input'];
  receiver: Scalars['String']['input'];
};

export type CreateWalletTransferDtoResponse = {
  __typename?: 'CreateWalletTransferDtoResponse';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  generateId?: Maybe<Scalars['String']['output']>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
};

export type DateFilterInput = {
  endDate?: InputMaybe<Scalars['String']['input']>;
  startDate?: InputMaybe<Scalars['String']['input']>;
};

export type DeleteAdminDtoResponse = {
  __typename?: 'DeleteAdminDtoResponse';
  admin?: Maybe<AdminType>;
};

export type DeleteCardTopupBatchDetailDto = {
  _id: Scalars['String']['input'];
  objects: Array<DeleteCardTopupBatchDetailObject>;
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type DeleteCardTopupBatchDetailDtoResponse = {
  __typename?: 'DeleteCardTopupBatchDetailDtoResponse';
  topupBatch?: Maybe<TopupBatchType>;
  topupBatchDetail?: Maybe<Array<TopupBatchDetailType>>;
};

export type DeleteCardTopupBatchDetailObject = {
  _id: Scalars['String']['input'];
  amount: Scalars['Float']['input'];
};

export type DeleteIssuedDto = {
  _id: Scalars['String']['input'];
};

export type DeleteIssuedDtoResponse = {
  __typename?: 'DeleteIssuedDtoResponse';
  issued?: Maybe<IssuedType>;
};

export type DeleteMerchantByAdminDto = {
  merchantId: Scalars['String']['input'];
};

export type DeleteMerchantCategoryRequest = {
  _id: Scalars['String']['input'];
};

export type DeleteMerchantCategoryResponse = {
  __typename?: 'DeleteMerchantCategoryResponse';
  _id: Scalars['String']['output'];
};

export type DeleteMerchantDtoResponse = {
  __typename?: 'DeleteMerchantDtoResponse';
  merchant?: Maybe<MerchantType>;
};

export type DeleteMerchantRequest = {
  _id: Scalars['String']['input'];
};

export type DeleteMerchantResponse = {
  __typename?: 'DeleteMerchantResponse';
  _id: Scalars['String']['output'];
};

export type DeleteRoleRequest = {
  _id: Scalars['String']['input'];
};

export type DeleteRoleResponse = {
  __typename?: 'DeleteRoleResponse';
  _id: Scalars['String']['output'];
};

export type DeleteServiceAccountDtoResponse = {
  __typename?: 'DeleteServiceAccountDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type DeleteSmsRequest = {
  _id: Scalars['String']['input'];
};

export type DeleteSmsResponse = {
  __typename?: 'DeleteSmsResponse';
  _id: Scalars['String']['output'];
};

export type DeleteTopupBatchDto = {
  _id: Scalars['String']['input'];
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type DeleteTopupBatchDtoResponse = {
  __typename?: 'DeleteTopupBatchDtoResponse';
  topupBatch?: Maybe<TopupBatchType>;
};

export type DeleteUserByAdminDto = {
  userId: Scalars['String']['input'];
};

export type DeleteUserByAdminDtoResponse = {
  __typename?: 'DeleteUserByAdminDtoResponse';
  user?: Maybe<UserType>;
};

export type DeleteUserDtoResponse = {
  __typename?: 'DeleteUserDtoResponse';
  user?: Maybe<UserType>;
};

export type DeleteWalletCardArrayDto = {
  _ids: Array<Scalars['String']['input']>;
};

export type DeleteWalletCardArrayDtoResponse = {
  __typename?: 'DeleteWalletCardArrayDtoResponse';
  walletCard?: Maybe<Array<WalletCardType>>;
};

export type DeleteWalletCardDto = {
  _id: Scalars['String']['input'];
};

export type DeleteWalletCardDtoResponse = {
  __typename?: 'DeleteWalletCardDtoResponse';
  walletCard?: Maybe<WalletCardType>;
};

export type DeleteWalletDto = {
  _id: Scalars['String']['input'];
};

export type DeleteWalletDtoResponse = {
  __typename?: 'DeleteWalletDtoResponse';
  wallet?: Maybe<WalletType>;
};

export type DeleteWalletMerchantDto = {
  _id: Scalars['String']['input'];
};

export type DeleteWalletMerchantDtoResponse = {
  __typename?: 'DeleteWalletMerchantDtoResponse';
  walletMerchant?: Maybe<WalletMerchantDto>;
};

export type DeleteWalletStaffDto = {
  _id: Scalars['String']['input'];
};

export type DeleteWalletStaffDtoResponse = {
  __typename?: 'DeleteWalletStaffDtoResponse';
  walletStaff: WalletStaffType;
};

export type DeniedCreateCustomerWithdrawCashToBuDto = {
  _id: Scalars['String']['input'];
};

export type DeniedCreateCustomerWithdrawCashToBuDtoResponse = {
  __typename?: 'DeniedCreateCustomerWithdrawCashToBUDtoResponse';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  generateId?: Maybe<Scalars['String']['output']>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
  withdraw?: Maybe<WithdrawType>;
};

export type DeniedCreateTopupBatchDto = {
  _id: Scalars['String']['input'];
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type DeniedCreateTopupBatchDtoResponse = {
  __typename?: 'DeniedCreateTopupBatchDtoResponse';
  topupBatch?: Maybe<TopupBatchType>;
};

export type DeniedIssuedDto = {
  _id: Scalars['String']['input'];
};

export type DeniedIssuedDtoResponse = {
  __typename?: 'DeniedIssuedDtoResponse';
  issued?: Maybe<IssuedType>;
};

export type ExchangeReferenceType = {
  __typename?: 'ExchangeReferenceType';
  paymentMethod?: Maybe<Scalars['String']['output']>;
  referenceHash?: Maybe<Scalars['String']['output']>;
};

export type FreezeAllCardToLostDtoResponse = {
  __typename?: 'FreezeAllCardToLostDtoResponse';
  isComplete?: Maybe<Scalars['Boolean']['output']>;
};

export type InNumberInput = {
  field?: InputMaybe<Scalars['String']['input']>;
  value?: InputMaybe<Array<Scalars['Int']['input']>>;
};

export type InStringInput = {
  field?: InputMaybe<Scalars['String']['input']>;
  value?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type IssuedReferenceInput = {
  issuedMethod: Scalars['String']['input'];
  qrInfo: IssuedReferenceQrInfoInput;
};

export type IssuedReferenceQrInfoInput = {
  transactionId: Scalars['String']['input'];
};

export type IssuedReferenceQrInfoType = {
  __typename?: 'IssuedReferenceQRInfoType';
  transactionId?: Maybe<Scalars['String']['output']>;
};

export type IssuedReferenceType = {
  __typename?: 'IssuedReferenceType';
  issuedMethod: Scalars['String']['output'];
  qrInfo?: Maybe<IssuedReferenceQrInfoType>;
};

export type IssuedType = {
  __typename?: 'IssuedType';
  _id?: Maybe<Scalars['String']['output']>;
  acceptor?: Maybe<Scalars['String']['output']>;
  acceptorHash?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  reference?: Maybe<IssuedReferenceType>;
  requestor?: Maybe<Scalars['String']['output']>;
  requestorHash?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  transactionId?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type LoadAdminByIdDto = {
  adminId: Scalars['String']['input'];
};

export type LoadAdminByIdDtoResponse = {
  __typename?: 'LoadAdminByIdDtoResponse';
  admin?: Maybe<AdminType>;
};

export type LoadAdminDetailByTokenDtoResponse = {
  __typename?: 'LoadAdminDetailByTokenDtoResponse';
  admin?: Maybe<AdminType>;
};

export type LoadAdminDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
};

export type LoadAdminDtoResponse = {
  __typename?: 'LoadAdminDtoResponse';
  admin?: Maybe<Array<AdminType>>;
  count?: Maybe<Scalars['Int']['output']>;
};

export type LoadAllMerchantCategoryResponse = {
  __typename?: 'LoadAllMerchantCategoryResponse';
  items: Array<ResponseMerchantCategoryModel>;
};

export type LoadAllMerchantResponse = {
  __typename?: 'LoadAllMerchantResponse';
  items: Array<ResponseMerchantModel>;
};

export type LoadAllRoleResponse = {
  __typename?: 'LoadAllRoleResponse';
  items: Array<ResponseRoleModel>;
};

export type LoadAllSmsResponse = {
  __typename?: 'LoadAllSmsResponse';
  items: Array<ResponseSmsModel>;
};

export type LoadBuTopupCashToCardDto = {
  between?: InputMaybe<LoadReportBetweenInput>;
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
  status?: InputMaybe<Scalars['String']['input']>;
};

export type LoadBuTopupCashToCardDtoResponse = {
  __typename?: 'LoadBUTopupCashToCardDtoResponse';
  count: Scalars['Int']['output'];
  topup?: Maybe<Array<Maybe<TopupType>>>;
};

export type LoadBuTopupCashToCustomerDto = {
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
  receiver?: InputMaybe<Scalars['String']['input']>;
  status?: InputMaybe<Scalars['String']['input']>;
};

export type LoadBuTopupCashToCustomerDtoResponse = {
  __typename?: 'LoadBUTopupCashToCustomerDtoResponse';
  count: Scalars['Int']['output'];
  topup?: Maybe<Array<Maybe<TopupType>>>;
};

export type LoadBuTopupCashToStaffDto = {
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
  receiver?: InputMaybe<Scalars['String']['input']>;
  status?: InputMaybe<Scalars['String']['input']>;
};

export type LoadBuTopupCashToStaffDtoResponse = {
  __typename?: 'LoadBUTopupCashToStaffDtoResponse';
  count: Scalars['Int']['output'];
  topup?: Maybe<Array<Maybe<TopupType>>>;
};

export type LoadCardWithdrawCashToBuDto = {
  between?: InputMaybe<LoadReportBetweenInput>;
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
  status?: InputMaybe<Scalars['String']['input']>;
};

export type LoadCardWithdrawCashToBuResponseDto = {
  __typename?: 'LoadCardWithdrawCashToBUResponseDto';
  count: Scalars['Int']['output'];
  withdraw?: Maybe<Array<Maybe<WithdrawType>>>;
};

export type LoadCustomerWithdrawCashToBuDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
  receiver: Scalars['String']['input'];
  status: Scalars['String']['input'];
};

export type LoadCustomerWithdrawCashToBuResponseDto = {
  __typename?: 'LoadCustomerWithdrawCashToBUResponseDto';
  count: Scalars['Int']['output'];
  withdraw?: Maybe<Array<Maybe<WithdrawType>>>;
};

export type LoadIssuedDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
  status?: InputMaybe<Scalars['String']['input']>;
};

export type LoadIssuedDtoResponse = {
  __typename?: 'LoadIssuedDtoResponse';
  count: Scalars['Int']['output'];
  issued?: Maybe<Array<Maybe<IssuedType>>>;
};

export type LoadMerchantByIdDto = {
  merchantId: Scalars['String']['input'];
};

export type LoadMerchantByIdDtoResponse = {
  __typename?: 'LoadMerchantByIdDtoResponse';
  merchant?: Maybe<MerchantType>;
};

export type LoadMerchantByIdRequest = {
  _id: Scalars['String']['input'];
};

export type LoadMerchantByIdResponse = {
  __typename?: 'LoadMerchantByIdResponse';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  email?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  merchantCategory?: Maybe<MerchantCategoryModel>;
  merchantCategoryId?: Maybe<Scalars['Int']['output']>;
  merchantCode?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  phoneNumber?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  username?: Maybe<Scalars['String']['output']>;
};

export type LoadMerchantByTokenDtoResponse = {
  __typename?: 'LoadMerchantByTokenDtoResponse';
  merchant?: Maybe<MerchantType>;
};

export type LoadMerchantCategoryByIdRequest = {
  _id: Scalars['String']['input'];
};

export type LoadMerchantCategoryByIdResponse = {
  __typename?: 'LoadMerchantCategoryByIdResponse';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  laName?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type LoadMerchantDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
};

export type LoadMerchantDtoResponse = {
  __typename?: 'LoadMerchantDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  merchant?: Maybe<Array<MerchantType>>;
};

export type LoadMerchantSignatureArrayByIdDto = {
  merchantId: Array<Scalars['String']['input']>;
};

export type LoadMerchantSignatureArrayByIdDtoResponse = {
  __typename?: 'LoadMerchantSignatureArrayByIdDtoResponse';
  merchantSignature?: Maybe<Array<MerchantSignatureType>>;
};

export type LoadMerchantSignatureByIdDto = {
  merchantId: Scalars['String']['input'];
};

export type LoadMerchantSignatureByIdDtoResponse = {
  __typename?: 'LoadMerchantSignatureByIdDtoResponse';
  merchantSignature?: Maybe<MerchantSignatureType>;
};

export type LoadMyWalletDtoResponse = {
  __typename?: 'LoadMyWalletDtoResponse';
  wallet?: Maybe<WalletType>;
  walletStaff?: Maybe<WalletStaffType>;
};

export type LoadOnlyServiceAccountIdFromBuIdByAdminDto = {
  buId: Scalars['String']['input'];
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
};

export type LoadOnlyServiceAccountIdFromBuIdByAdminDtoResponse = {
  __typename?: 'LoadOnlyServiceAccountIdFromBUIdByAdminDtoResponse';
  count?: Maybe<Scalars['Float']['output']>;
  serviceAccount?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
};

export type LoadReportBetweenInput = {
  end: Scalars['String']['input'];
  start: Scalars['String']['input'];
};

export type LoadReportBetweenType = {
  __typename?: 'LoadReportBetweenType';
  end: Scalars['String']['output'];
  start: Scalars['String']['output'];
};

export type LoadReportFilterSummaryDailyCounterServiceDetailDto = {
  __typename?: 'LoadReportFilterSummaryDailyCounterServiceDetailDto';
  between?: Maybe<LoadReportBetweenType>;
  firstName?: Maybe<Scalars['String']['output']>;
  lastName?: Maybe<Scalars['String']['output']>;
  prefix?: Maybe<Scalars['String']['output']>;
  topup?: Maybe<LoadReportSummaryBuWalletTopupDto>;
  withdraw?: Maybe<LoadReportSummaryBuWalletWithdrawDto>;
};

export type LoadReportFilterSummaryDailyCounterServiceDto = {
  between: LoadReportBetweenInput;
};

export type LoadReportFilterSummaryDailyCounterServiceDtoResponse = {
  __typename?: 'LoadReportFilterSummaryDailyCounterServiceDtoResponse';
  report?: Maybe<LoadReportFilterSummaryDailyCounterServiceDetailDto>;
};

export type LoadReportFilterSummaryDailyDetailDto = {
  __typename?: 'LoadReportFilterSummaryDailyDetailDto';
  _id?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  reference?: Maybe<LoadReportFilterSummaryDailyDetailReferenceDto>;
  statementType?: Maybe<TopupStatementTypeDto>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  walletCard?: Maybe<WalletCardType>;
  walletId?: Maybe<Scalars['String']['output']>;
};

export type LoadReportFilterSummaryDailyDetailReferenceDto = {
  __typename?: 'LoadReportFilterSummaryDailyDetailReferenceDto';
  collection?: Maybe<Scalars['String']['output']>;
  method?: Maybe<Scalars['String']['output']>;
  queue?: Maybe<Scalars['String']['output']>;
  referenceHash?: Maybe<Scalars['String']['output']>;
};

export type LoadReportFilterSummaryDailyMerchantDto = {
  between: LoadReportBetweenInput;
  limit: Scalars['Int']['input'];
  merchantId?: InputMaybe<Scalars['String']['input']>;
  page: Scalars['Int']['input'];
};

export type LoadReportFilterSummaryDailyMerchantDtoResponse = {
  __typename?: 'LoadReportFilterSummaryDailyMerchantDtoResponse';
  count?: Maybe<Scalars['Float']['output']>;
  report?: Maybe<Array<Maybe<LoadReportFilterSummaryDailyDetailDto>>>;
};

export type LoadReportSummaryBuWalletTopupDto = {
  __typename?: 'LoadReportSummaryBUWalletTopupDto';
  cash?: Maybe<Scalars['Float']['output']>;
  total?: Maybe<Scalars['Float']['output']>;
  transfer?: Maybe<Scalars['Float']['output']>;
};

export type LoadReportSummaryBuWalletWithdrawDto = {
  __typename?: 'LoadReportSummaryBUWalletWithdrawDto';
  cash?: Maybe<Scalars['Float']['output']>;
  total?: Maybe<Scalars['Float']['output']>;
  transfer?: Maybe<Scalars['Float']['output']>;
};

export type LoadReportSummaryDailyCounterServiceBySupervisorDto = {
  between: LoadReportBetweenInput;
};

export type LoadReportSummaryDailyCounterServiceBySupervisorDtoResponse = {
  __typename?: 'LoadReportSummaryDailyCounterServiceBySupervisorDtoResponse';
  report?: Maybe<Array<Maybe<LoadReportFilterSummaryDailyCounterServiceDetailDto>>>;
};

export type LoadReportSummaryDailyMerchantDetailDetailDto = {
  __typename?: 'LoadReportSummaryDailyMerchantDetailDetailDto';
  between?: Maybe<LoadReportBetweenType>;
  income?: Maybe<LoadReportSummaryIncomeDto>;
  name?: Maybe<Scalars['String']['output']>;
  walletId?: Maybe<Scalars['String']['output']>;
};

export type LoadReportSummaryDailyMerchantDto = {
  between: LoadReportBetweenInput;
  merchantId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadReportSummaryDailyMerchantDtoResponse = {
  __typename?: 'LoadReportSummaryDailyMerchantDtoResponse';
  report?: Maybe<Array<Maybe<LoadReportSummaryDailyMerchantDetailDetailDto>>>;
};

export type LoadReportSummaryIncomeDto = {
  __typename?: 'LoadReportSummaryIncomeDto';
  cardStaffTransaction?: Maybe<Scalars['Float']['output']>;
  cardStaffTransfer?: Maybe<Scalars['Float']['output']>;
  cardTransaction?: Maybe<Scalars['Float']['output']>;
  cardTransfer?: Maybe<Scalars['Float']['output']>;
  cash?: Maybe<Scalars['Float']['output']>;
  total?: Maybe<Scalars['Float']['output']>;
  totalTransaction?: Maybe<Scalars['Float']['output']>;
  transfer?: Maybe<Scalars['Float']['output']>;
  walletStaffTransaction?: Maybe<Scalars['Float']['output']>;
  walletStaffTransfer?: Maybe<Scalars['Float']['output']>;
  walletTransaction?: Maybe<Scalars['Float']['output']>;
  walletTransfer?: Maybe<Scalars['Float']['output']>;
};

export type LoadRoleByIdRequest = {
  _id: Scalars['String']['input'];
};

export type LoadRoleByIdResponse = {
  __typename?: 'LoadRoleByIdResponse';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  enName?: Maybe<Scalars['String']['output']>;
  laName?: Maybe<Scalars['String']['output']>;
  level?: Maybe<Scalars['String']['output']>;
  menus?: Maybe<Array<RoleMenuModel>>;
  systemCode?: Maybe<Scalars['String']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type LoadServiceAccountByIdDto = {
  serviceAccountId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadServiceAccountByIdDtoResponse = {
  __typename?: 'LoadServiceAccountByIdDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type LoadServiceAccountDetailByTokenDtoResponse = {
  __typename?: 'LoadServiceAccountDetailByTokenDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type LoadServiceAccountDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
};

export type LoadServiceAccountDtoResponse = {
  __typename?: 'LoadServiceAccountDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  serviceAccount?: Maybe<Array<ServiceAccountType>>;
};

export type LoadServiceAccountSignatureArrayByIdDto = {
  serviceAccountId: Array<Scalars['String']['input']>;
};

export type LoadServiceAccountSignatureArrayByIdDtoResponse = {
  __typename?: 'LoadServiceAccountSignatureArrayByIdDtoResponse';
  serviceAccountSignature?: Maybe<Array<ServiceAccountSignatureType>>;
};

export type LoadServiceAccountSignatureByIdDto = {
  serviceAccountId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadServiceAccountSignatureByIdDtoResponse = {
  __typename?: 'LoadServiceAccountSignatureByIdDtoResponse';
  serviceAccountSignature?: Maybe<ServiceAccountSignatureType>;
};

export type LoadSmsByIdRequest = {
  _id: Scalars['String']['input'];
};

export type LoadSmsByIdResponse = {
  __typename?: 'LoadSmsByIdResponse';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type LoadSystemTopupCashToBuDto = {
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
  receiver?: InputMaybe<Scalars['String']['input']>;
  status?: InputMaybe<Scalars['String']['input']>;
};

export type LoadSystemTopupCashToBuDtoResponse = {
  __typename?: 'LoadSystemTopupCashToBUDtoResponse';
  count: Scalars['Int']['output'];
  topup?: Maybe<Array<Maybe<TopupType>>>;
};

export type LoadTopupBatchDetailByIdDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
  status?: InputMaybe<Scalars['String']['input']>;
  topupBatchId: Scalars['String']['input'];
};

export type LoadTopupBatchDetailByIdDtoResponse = {
  __typename?: 'LoadTopupBatchDetailByIdDtoResponse';
  count: Scalars['Int']['output'];
  topupBatch?: Maybe<TopupBatchType>;
  topupBatchDetail?: Maybe<Array<Maybe<TopupBatchDetailType>>>;
};

export type LoadTopupBatchDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
  status?: InputMaybe<Scalars['String']['input']>;
  target?: InputMaybe<Scalars['String']['input']>;
};

export type LoadTopupBatchDtoResponse = {
  __typename?: 'LoadTopupBatchDtoResponse';
  count: Scalars['Int']['output'];
  topupBatch?: Maybe<Array<Maybe<TopupBatchType>>>;
};

export type LoadUserByIdDto = {
  userId: Scalars['String']['input'];
};

export type LoadUserByIdDtoResponse = {
  __typename?: 'LoadUserByIdDtoResponse';
  user?: Maybe<UserType>;
};

export type LoadUserDetailByTokenDtoResponse = {
  __typename?: 'LoadUserDetailByTokenDtoResponse';
  user?: Maybe<UserType>;
};

export type LoadUserDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
};

export type LoadUserDtoResponse = {
  __typename?: 'LoadUserDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  user?: Maybe<Array<UserType>>;
};

export type LoadUserSignatureArrayByIdDto = {
  userId: Array<Scalars['String']['input']>;
};

export type LoadUserSignatureArrayByIdDtoResponse = {
  __typename?: 'LoadUserSignatureArrayByIdDtoResponse';
  userSignature?: Maybe<Array<UserSignatureType>>;
};

export type LoadUserSignatureByIdDto = {
  userId: Scalars['String']['input'];
};

export type LoadUserSignatureByIdDtoResponse = {
  __typename?: 'LoadUserSignatureByIdDtoResponse';
  userSignature?: Maybe<UserSignatureType>;
};

export type LoadWalletBuBalanceDto = {
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletBuBalanceDtoResponse = {
  __typename?: 'LoadWalletBUBalanceDtoResponse';
  amount: Scalars['Float']['output'];
};

export type LoadWalletBuDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
  walletCategoryId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletBuDtoResponse = {
  __typename?: 'LoadWalletBUDtoResponse';
  count: Scalars['Int']['output'];
  wallet?: Maybe<Array<Maybe<WalletType>>>;
};

export type LoadWalletBalanceDtoResponse = {
  __typename?: 'LoadWalletBalanceDtoResponse';
  amount: Scalars['Float']['output'];
};

export type LoadWalletByIdDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletByIdDtoResponse = {
  __typename?: 'LoadWalletByIdDtoResponse';
  wallet?: Maybe<WalletType>;
};

export type LoadWalletByServiceDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
};

export type LoadWalletByServiceDtoResponse = {
  __typename?: 'LoadWalletByServiceDtoResponse';
  count: Scalars['Int']['output'];
  wallet?: Maybe<Array<Maybe<WalletType>>>;
};

export type LoadWalletCardBalanceDto = {
  walletCardId: Scalars['String']['input'];
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletCardBalanceDtoResponse = {
  __typename?: 'LoadWalletCardBalanceDtoResponse';
  amount: Scalars['Float']['output'];
};

export type LoadWalletCardByIdDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
  cardNo?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletCardByIdDtoResponse = {
  __typename?: 'LoadWalletCardByIdDtoResponse';
  wallet?: Maybe<WalletType>;
  walletCard?: Maybe<WalletCardType>;
};

export type LoadWalletCardByTopupBatchIdDto = {
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
  status: Scalars['String']['input'];
  topupBatchId: Scalars['String']['input'];
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletCardByTopupBatchIdDtoResponse = {
  __typename?: 'LoadWalletCardByTopupBatchIdDtoResponse';
  count: Scalars['Int']['output'];
  walletCard?: Maybe<Array<Maybe<WalletCardType>>>;
};

export type LoadWalletCardDto = {
  between?: InputMaybe<LoadWalletCardStatementListBetweenDto>;
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
  status?: InputMaybe<Scalars['String']['input']>;
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletCardDtoResponse = {
  __typename?: 'LoadWalletCardDtoResponse';
  count: Scalars['Int']['output'];
  total?: Maybe<Scalars['Int']['output']>;
  walletCard?: Maybe<Array<Maybe<WalletCardType>>>;
};

export type LoadWalletCardReceiptTagDetailDto = {
  tag: Scalars['String']['input'];
  walletCardId: Scalars['String']['input'];
};

export type LoadWalletCardReceiptTagDetailReceiverDto = {
  __typename?: 'LoadWalletCardReceiptTagDetailReceiverDto';
  receiveBy?: Maybe<Scalars['String']['output']>;
  walletId?: Maybe<Scalars['String']['output']>;
  walletInfo?: Maybe<LoadWalletCardReceiptTagDetailWalletInfoDto>;
};

export type LoadWalletCardReceiptTagDetailResponseDto = {
  __typename?: 'LoadWalletCardReceiptTagDetailResponseDto';
  amount?: Maybe<Scalars['Float']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  receiver?: Maybe<LoadWalletCardReceiptTagDetailReceiverDto>;
  reference?: Maybe<WalletCardTagReferenceDto>;
  sender?: Maybe<LoadWalletCardReceiptTagDetailSenderDto>;
  statementType?: Maybe<StatementTypeDtoResponse>;
};

export type LoadWalletCardReceiptTagDetailSenderDto = {
  __typename?: 'LoadWalletCardReceiptTagDetailSenderDto';
  sendBy?: Maybe<Scalars['String']['output']>;
  walletId?: Maybe<Scalars['String']['output']>;
  walletInfo?: Maybe<LoadWalletCardReceiptTagDetailWalletInfoDto>;
};

export type LoadWalletCardReceiptTagDetailWalletInfoDto = {
  __typename?: 'LoadWalletCardReceiptTagDetailWalletInfoDto';
  cardName?: Maybe<Scalars['String']['output']>;
  cardNo?: Maybe<Scalars['String']['output']>;
  firstName?: Maybe<Scalars['String']['output']>;
  lastName?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
};

export type LoadWalletCardStatementListBetweenDto = {
  end: Scalars['String']['input'];
  start: Scalars['String']['input'];
};

export type LoadWalletCardStatementListDetail = {
  __typename?: 'LoadWalletCardStatementListDetail';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  expend?: Maybe<UserProfileType>;
  income?: Maybe<UserProfileType>;
  merchant?: Maybe<MerchantProfileType>;
  reference?: Maybe<WalletCardTagReferenceDto>;
  serviceAccount?: Maybe<ServiceAccountProfileType>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
};

export type LoadWalletCardStatementListDto = {
  between: LoadWalletCardStatementListBetweenDto;
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
  read?: InputMaybe<Scalars['String']['input']>;
  statement?: InputMaybe<Scalars['String']['input']>;
  transaction?: InputMaybe<Scalars['String']['input']>;
  walletCardId: Scalars['String']['input'];
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletCardStatementListDtoResponse = {
  __typename?: 'LoadWalletCardStatementListDtoResponse';
  count?: Maybe<Scalars['Float']['output']>;
  expend?: Maybe<Scalars['Float']['output']>;
  income?: Maybe<Scalars['Float']['output']>;
  statement?: Maybe<Array<Maybe<LoadWalletCardStatementListDetail>>>;
};

export type LoadWalletCardSummaryActivityDetailDto = {
  cardNo: Scalars['String']['input'];
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
  status?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletCardSummaryActivityDetailResponseDto = {
  __typename?: 'LoadWalletCardSummaryActivityDetailResponseDto';
  count?: Maybe<Scalars['Int']['output']>;
  walletCardActivity?: Maybe<Array<Maybe<WalletCardActivityType>>>;
};

export type LoadWalletCardSummaryActivityDto = {
  between?: InputMaybe<LoadWalletCardStatementListBetweenDto>;
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
  status?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletCardSummaryActivityResponseDto = {
  __typename?: 'LoadWalletCardSummaryActivityResponseDto';
  count?: Maybe<Scalars['Int']['output']>;
  total?: Maybe<Scalars['Float']['output']>;
  walletCardActivity?: Maybe<Array<Maybe<WalletCardActivityType>>>;
};

export type LoadWalletCategoryBuDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
};

export type LoadWalletCategoryBuDtoResponse = {
  __typename?: 'LoadWalletCategoryBUDtoResponse';
  count: Scalars['Int']['output'];
  walletCategory?: Maybe<Array<Maybe<WalletCategoryType>>>;
};

export type LoadWalletCategoryDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
};

export type LoadWalletCategoryDtoResponse = {
  __typename?: 'LoadWalletCategoryDtoResponse';
  count: Scalars['Int']['output'];
  walletCategory?: Maybe<Array<Maybe<WalletCategoryType>>>;
};

export type LoadWalletDestinationByQrDto = {
  qr: Scalars['String']['input'];
};

export type LoadWalletDestinationByQrDtoResponse = {
  __typename?: 'LoadWalletDestinationByQRDtoResponse';
  name?: Maybe<Scalars['String']['output']>;
  walletId?: Maybe<Scalars['String']['output']>;
};

export type LoadWalletDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
  walletCategoryId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletDtoResponse = {
  __typename?: 'LoadWalletDtoResponse';
  count: Scalars['Int']['output'];
  wallet?: Maybe<Array<Maybe<WalletType>>>;
};

export type LoadWalletMerchantBalanceDtoResponse = {
  __typename?: 'LoadWalletMerchantBalanceDtoResponse';
  amount: Scalars['Float']['output'];
};

export type LoadWalletMerchantDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletMerchantDtoResponse = {
  __typename?: 'LoadWalletMerchantDtoResponse';
  count: Scalars['Float']['output'];
  walletMerchant?: Maybe<Array<Maybe<WalletMerchantDto>>>;
};

export type LoadWalletMerchantReceiptTagDetailDto = {
  tag: Scalars['String']['input'];
};

export type LoadWalletMerchantReceiptTagDetailReceiverDto = {
  __typename?: 'LoadWalletMerchantReceiptTagDetailReceiverDto';
  receiveBy?: Maybe<Scalars['String']['output']>;
  walletId: Scalars['String']['output'];
  walletInfo: LoadWalletMerchantReceiptTagDetailWalletInfoDto;
};

export type LoadWalletMerchantReceiptTagDetailResponseDto = {
  __typename?: 'LoadWalletMerchantReceiptTagDetailResponseDto';
  amount?: Maybe<Scalars['Float']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  receiver?: Maybe<LoadWalletMerchantReceiptTagDetailReceiverDto>;
  reference?: Maybe<WalletMerchantTagReferenceDto>;
  sender?: Maybe<LoadWalletMerchantReceiptTagDetailSenderDto>;
  statementType?: Maybe<StatementTypeDtoResponse>;
};

export type LoadWalletMerchantReceiptTagDetailSenderDto = {
  __typename?: 'LoadWalletMerchantReceiptTagDetailSenderDto';
  sendBy?: Maybe<Scalars['String']['output']>;
  walletId: Scalars['String']['output'];
  walletInfo: LoadWalletMerchantReceiptTagDetailWalletInfoDto;
};

export type LoadWalletMerchantReceiptTagDetailWalletInfoDto = {
  __typename?: 'LoadWalletMerchantReceiptTagDetailWalletInfoDto';
  cardName?: Maybe<Scalars['String']['output']>;
  cardNo?: Maybe<Scalars['String']['output']>;
  firstName?: Maybe<Scalars['String']['output']>;
  lastName?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
};

export type LoadWalletMerchantStatementListBetweenDto = {
  end: Scalars['String']['input'];
  start: Scalars['String']['input'];
};

export type LoadWalletMerchantStatementListDetail = {
  __typename?: 'LoadWalletMerchantStatementListDetail';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  reference?: Maybe<WalletMerchantTagReferenceDto>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
};

export type LoadWalletMerchantStatementListDto = {
  between: LoadWalletMerchantStatementListBetweenDto;
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
  read?: InputMaybe<Scalars['String']['input']>;
  statement?: InputMaybe<Scalars['String']['input']>;
  transaction?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletMerchantStatementListDtoResponse = {
  __typename?: 'LoadWalletMerchantStatementListDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  expend?: Maybe<Scalars['Float']['output']>;
  income?: Maybe<Scalars['Float']['output']>;
  statement?: Maybe<Array<Maybe<LoadWalletMerchantStatementListDetail>>>;
};

export type LoadWalletStaffBalanceDtoResponse = {
  __typename?: 'LoadWalletStaffBalanceDtoResponse';
  amount: Scalars['Float']['output'];
};

export type LoadWalletStaffDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Float']['input'];
  page: Scalars['Float']['input'];
  walletId: Scalars['String']['input'];
};

export type LoadWalletStaffDtoResponse = {
  __typename?: 'LoadWalletStaffDtoResponse';
  count: Scalars['Float']['output'];
  walletStaff: Array<WalletStaffType>;
};

export type LoadWalletStaffStatementListDetail = {
  __typename?: 'LoadWalletStaffStatementListDetail';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
};

export type LoadWalletStaffStatementListDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
  read?: InputMaybe<Scalars['String']['input']>;
  statement?: InputMaybe<Scalars['String']['input']>;
  transaction?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletStaffStatementListDtoResponse = {
  __typename?: 'LoadWalletStaffStatementListDtoResponse';
  count: Scalars['Float']['output'];
  statement?: Maybe<Array<Maybe<LoadWalletStaffStatementListDetail>>>;
};

export type LoadWalletStatementListBetweenDto = {
  end: Scalars['String']['input'];
  start: Scalars['String']['input'];
};

export type LoadWalletStatementListDetailType = {
  __typename?: 'LoadWalletStatementListDetailType';
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  expend?: Maybe<UserProfileType>;
  income?: Maybe<UserProfileType>;
  merchant?: Maybe<MerchantProfileType>;
  reference?: Maybe<WalletTagReferenceDto>;
  serviceAccount?: Maybe<ServiceAccountProfileType>;
  statementType?: Maybe<StatementTypeDtoResponse>;
  tag?: Maybe<Scalars['String']['output']>;
};

export type LoadWalletStatementListDto = {
  between: LoadWalletStatementListBetweenDto;
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
  read?: InputMaybe<Scalars['String']['input']>;
  statement?: InputMaybe<Scalars['String']['input']>;
  transaction?: InputMaybe<Scalars['String']['input']>;
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWalletStatementListDtoResponse = {
  __typename?: 'LoadWalletStatementListDtoResponse';
  count: Scalars['Int']['output'];
  expend?: Maybe<Scalars['Float']['output']>;
  income?: Maybe<Scalars['Float']['output']>;
  statement?: Maybe<Array<Maybe<LoadWalletStatementListDetailType>>>;
};

export type MerchantCategoryModel = {
  __typename?: 'MerchantCategoryModel';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  laName: Scalars['String']['output'];
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type MerchantConfigType = {
  __typename?: 'MerchantConfigType';
  assignBy?: Maybe<Scalars['String']['output']>;
  assignDate?: Maybe<Scalars['String']['output']>;
  assignId?: Maybe<Scalars['String']['output']>;
  level?: Maybe<Scalars['String']['output']>;
};

export type MerchantDividendType = {
  __typename?: 'MerchantDividendType';
  _id?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  confirmBy?: Maybe<Scalars['String']['output']>;
  confirmHash?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  end?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  serviceAccount?: Maybe<Scalars['String']['output']>;
  serviceAccountHash?: Maybe<Scalars['String']['output']>;
  start?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  walletId?: Maybe<Scalars['String']['output']>;
  withdrawId?: Maybe<Scalars['String']['output']>;
};

export type MerchantInfoType = {
  __typename?: 'MerchantInfoType';
  _id?: Maybe<Scalars['String']['output']>;
  config?: Maybe<MerchantConfigType>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  password?: Maybe<Scalars['String']['output']>;
  phoneNumber?: Maybe<Scalars['String']['output']>;
  platform?: Maybe<Scalars['String']['output']>;
  prefix?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Float']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  username?: Maybe<Scalars['String']['output']>;
};

export type MerchantProfileImageInput = {
  cover?: InputMaybe<Scalars['String']['input']>;
  profile?: InputMaybe<Scalars['String']['input']>;
};

export type MerchantProfileImageType = {
  __typename?: 'MerchantProfileImageType';
  cover?: Maybe<Scalars['String']['output']>;
  profile?: Maybe<Scalars['String']['output']>;
};

export type MerchantProfileType = {
  __typename?: 'MerchantProfileType';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  image?: Maybe<MerchantProfileImageType>;
  isActive?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Float']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type MerchantSignatureType = {
  __typename?: 'MerchantSignatureType';
  _id: Scalars['String']['output'];
  createdAt: Scalars['String']['output'];
  hash: Scalars['String']['output'];
  isActive: Scalars['String']['output'];
  ownerId: Scalars['String']['output'];
  privateKey: Scalars['String']['output'];
  publicKey: Scalars['String']['output'];
  uid: Scalars['String']['output'];
  uniqueId: Scalars['Float']['output'];
  updatedAt: Scalars['String']['output'];
};

export type MerchantSigninDto = {
  password: Scalars['String']['input'];
  username: Scalars['String']['input'];
};

export type MerchantSigninDtoResponse = {
  __typename?: 'MerchantSigninDtoResponse';
  authorization: Scalars['String']['output'];
  business?: Maybe<Scalars['String']['output']>;
};

export type MerchantSignupDto = {
  name: Scalars['String']['input'];
  password: Scalars['String']['input'];
  username: Scalars['String']['input'];
};

export type MerchantSignupDtoResponse = {
  __typename?: 'MerchantSignupDtoResponse';
  merchant?: Maybe<MerchantType>;
};

export type MerchantType = {
  __typename?: 'MerchantType';
  merchant?: Maybe<MerchantInfoType>;
  merchantProfile?: Maybe<MerchantProfileType>;
};

export type MerchantValidateTokenDtoResponse = {
  __typename?: 'MerchantValidateTokenDtoResponse';
  merchant?: Maybe<MerchantType>;
};

export type Mutation = {
  __typename?: 'Mutation';
  addAccessToUserBUByAdmin: AddAccessToUserBuByAdminDtoResponse;
  adminSignup: AdminSignupDtoResponse;
  changeMerchantPassword: ChangeMerchantPasswordResponseDto;
  changeMerchantUsername: ChangeMerchantUsernameDtoResponse;
  changeMerchantUsernameByAdmin: ChangeMerchantUsernameByAdminDtoResponse;
  changeServiceAccountPassword: ChangeServiceAccountPasswordResponseDto;
  changeServiceAccountUsername: ChangeServiceAccountUsernameDtoResponse;
  changeServiceAccountUsernameByAdmin: ChangeServiceAccountUsernameByAdminDtoResponse;
  changeTopupTransactionMethod: ChangeTopupTransactionMethodDtoResponse;
  confirmCreateCustomerWithdrawCashToBU: ConfirmCreateCustomerWithdrawCashToBuResponse;
  confirmCreateIssued: ConfirmCreateIssuedDtoResponse;
  confirmCreateMerchantDividend: ConfirmCreateMerchantDividendDtoResponse;
  confirmCreateMerchantDividendQueue: ConfirmCreateMerchantDividendQueueDtoResponse;
  confirmCreateTopupBatch: ConfirmCreateTopupBatchDtoResponse;
  confirmCreateUserOTP: ConfirmCreateUserOtpDtoResponse;
  confirmCreateWalletMerchantOrderForCard: ConfirmCreateWalletMerchantOrderForCardDtoResponse;
  createAcceptorAccountSignature: CreateAcceptorAccountSignatureDtoResponse;
  createBUTopupCashToCard: CreateBuTopupCashToCardDtoResponse;
  createBUTopupCashToCustomer: CreateBuTopupCashToCustomerDtoResponse;
  createBUTopupCashToStaff: CreateBuTopupCashToStaffDtoResponse;
  createBUWallet: CreateBuWalletDtoResponse;
  createCardTopupBatchDetail: CreateCardTopupBatchDetailDtoResponse;
  createCardWithdrawCashToBU: CreateCardWithdrawCashToBuDtoResponse;
  createCustomerWithdrawCashToBU: CreateCustomerWithdrawCashToBuDtoResponse;
  createIssued: CreateIssuedDtoResponse;
  createMerchantDividend: CreateMerchantDividendDtoResponse;
  createMerchantDividendQueue: CreateMerchantDividendQueueDtoResponse;
  createOnlyWallet: CreateOnlyWalletDtoResponse;
  createRequestorAccountSignature: CreateRequestorAccountSignatureDtoResponse;
  createServiceAccountSignature: CreateServiceAccountSignatureDtoResponse;
  createSystemTopupCashToBU: CreateSystemTopupCashToBuDtoResponse;
  createTopupBatch: CreateTopupBatchDtoResponse;
  createUserOTP: CreateUserOtpDtoResponse;
  createWallet: CreateWalletDtoResponse;
  createWalletCard: CreateWalletCardDtoResponse;
  createWalletCategory: CreateWalletCategoryDtoResponse;
  createWalletIssuer: CreateWalletIssuerDtoResponse;
  createWalletMerchant: CreateWalletMerchantDtoResponse;
  createWalletMerchantOrderForCard: CreateWalletMerchantOrderForCardDtoResponse;
  createWalletMerchantQR: CreateWalletMerchantQrDtoResponse;
  createWalletQRTransfer: CreateWalletQrTransferDtoResponse;
  createWalletStaff: CreateWalletStaffDtoResponse;
  createWalletTransfer: CreateWalletTransferDtoResponse;
  deleteAdmin: DeleteAdminDtoResponse;
  deleteCardTopupBatchDetail: DeleteCardTopupBatchDetailDtoResponse;
  deleteIssued: DeleteIssuedDtoResponse;
  deleteMerchant: DeleteMerchantDtoResponse;
  deleteMerchantByAdmin: DeleteMerchantDtoResponse;
  deleteServiceAccount: DeleteServiceAccountDtoResponse;
  deleteServiceAccountByAdmin: DeleteServiceAccountDtoResponse;
  deleteTopupBatch: DeleteTopupBatchDtoResponse;
  deleteUser: DeleteUserDtoResponse;
  deleteUserByAdmin: DeleteUserByAdminDtoResponse;
  deleteWallet: DeleteWalletDtoResponse;
  deleteWalletCard: DeleteWalletCardDtoResponse;
  deleteWalletCardArray: DeleteWalletCardArrayDtoResponse;
  deleteWalletMerchant: DeleteWalletMerchantDtoResponse;
  deleteWalletStaff: DeleteWalletStaffDtoResponse;
  deniedCreateCustomerWithdrawCashToBU: DeniedCreateCustomerWithdrawCashToBuDtoResponse;
  deniedCreateTopupBatch: DeniedCreateTopupBatchDtoResponse;
  deniedIssued: DeniedIssuedDtoResponse;
  freezeAllCardToLost: FreezeAllCardToLostDtoResponse;
  merchantCategoryCreate: CreateMerchantCategoryResponse;
  merchantCategoryDelete: DeleteMerchantCategoryResponse;
  merchantCategoryUpdate: UpdateMerchantCategoryResponse;
  merchantCreate: CreateMerchantResponse;
  merchantDelete: DeleteMerchantResponse;
  merchantSignin: MerchantSigninDtoResponse;
  merchantSignup: MerchantSignupDtoResponse;
  merchantUpdate: UpdateMerchantResponse;
  readCard: ReadCardDtoResponse;
  resetMerchantPassword: ResetMerchantPasswordResponseDto;
  resetServiceAccountPassword: ResetServiceAccountPasswordResponseDto;
  restoreDeleteAdmin: RestoreDeleteAdminDtoResponse;
  restoreDeleteIssued: RestoreDeleteIssuedDtoResponse;
  restoreDeleteMerchant: RestoreDeleteMerchantDtoResponse;
  restoreDeleteMerchantByAdmin: RestoreDeleteMerchantByAdminDtoResponse;
  restoreDeleteServiceAccount: RestoreDeleteServiceAccountDtoResponse;
  restoreDeleteServiceAccountByAdmin: RestoreDeleteServiceAccountDtoResponse;
  restoreDeleteTopupBatch: RestoreDeleteTopupBatchDtoResponse;
  restoreDeleteUser: RestoreDeleteUserDtoResponse;
  restoreDeleteUserByAdmin: RestoreDeleteUserByAdminDtoResponse;
  restoreDeleteWallet: RestoreDeleteWalletDtoResponse;
  restoreDeleteWalletCard: RestoreDeleteWalletCardDtoResponse;
  restoreDeleteWalletCardArray: RestoreDeleteWalletCardArrayDtoResponse;
  restoreDeleteWalletMerchant: RestoreDeleteWalletMerchantDtoResponse;
  restoreDeleteWalletStaff: RestoreDeleteWalletStaffDtoResponse;
  roleCreate: CreateRoleResponse;
  roleDelete: DeleteRoleResponse;
  roleUpdate: UpdateRoleResponse;
  sendSms: SendSmsResponse;
  serviceAccountSignup: ServiceAccountSignupDtoResponse;
  smsCreate: CreateSmsResponse;
  smsDelete: DeleteSmsResponse;
  smsUpdate: UpdateSmsResponse;
  updateAdminProfile: UpdateAdminProfileDtoResponse;
  updateCardTopupBatchDetail: UpdateCardTopupBatchDetailDtoResponse;
  updateIssued: UpdateIssuedDtoResponse;
  updateMerchantProfile: UpdateMerchantProfileDtoResponse;
  updateMerchantProfileByAdmin: UpdateMerchantProfileDtoResponse;
  updateServiceAccountProfile: UpdateServiceAccountProfileDtoResponse;
  updateServiceAccountProfileByAdmin: UpdateServiceAccountProfileByAdminDtoResponse;
  updateTopupBatch: UpdateTopupBatchDtoResponse;
  updateUserProfile: UpdateUserProfileDtoResponse;
  updateUserProfileByAdmin: UpdateUserProfileByAdminDtoResponse;
  updateWalletCard: UpdateWalletCardDtoResponse;
  updateWalletCardArrayToInUse: UpdateWalletCardArrayToInUseDtoResponse;
  updateWalletCardToInUse: UpdateWalletCardToInUseDtoResponse;
  updateWalletCardToLost: UpdateWalletCardToLostDtoResponse;
  updateWalletCategory: UpdateWalletCategoryDtoResponse;
  updateWalletMerchant: UpdateWalletMerchantDtoResponse;
  upgradePersonalEmployeeByAdmin: UpgradePersonalEmployeeByAdminDtoResponse;
  userBUSignup: UserBuSignupDtoResponse;
  userSignup: UserSignupDtoResponse;
  withdrawAllCardLost: WithdrawAllCardLostDtoResponse;
};


export type MutationAddAccessToUserBuByAdminArgs = {
  input: AddAccessToUserBuByAdminDto;
};


export type MutationAdminSignupArgs = {
  input: AdminSignupDto;
};


export type MutationChangeMerchantPasswordArgs = {
  input: ChangeMerchantPasswordDto;
};


export type MutationChangeMerchantUsernameArgs = {
  input: ChangeMerchantUsernameDto;
};


export type MutationChangeMerchantUsernameByAdminArgs = {
  input: ChangeMerchantUsernameByAdminDto;
};


export type MutationChangeServiceAccountPasswordArgs = {
  input: ChangeServiceAccountPasswordDto;
};


export type MutationChangeServiceAccountUsernameArgs = {
  input: ChangeServiceAccountUsernameDto;
};


export type MutationChangeServiceAccountUsernameByAdminArgs = {
  input: ChangeServiceAccountUsernameByAdminDto;
};


export type MutationChangeTopupTransactionMethodArgs = {
  input: ChangeTopupTransactionMethodDto;
};


export type MutationConfirmCreateCustomerWithdrawCashToBuArgs = {
  input: ConfirmCreateCustomerWithdrawCashToBu;
};


export type MutationConfirmCreateIssuedArgs = {
  input: ConfirmCreateIssuedDto;
};


export type MutationConfirmCreateMerchantDividendArgs = {
  input: ConfirmCreateMerchantDividendDto;
};


export type MutationConfirmCreateMerchantDividendQueueArgs = {
  input: ConfirmCreateMerchantDividendQueueDto;
};


export type MutationConfirmCreateTopupBatchArgs = {
  input: ConfirmCreateTopupBatchDto;
};


export type MutationConfirmCreateUserOtpArgs = {
  input: ConfirmCreateUserOtpDto;
};


export type MutationConfirmCreateWalletMerchantOrderForCardArgs = {
  input: ConfirmCreateWalletMerchantOrderForCardDto;
};


export type MutationCreateAcceptorAccountSignatureArgs = {
  input: CreateAcceptorAccountSignatureDto;
};


export type MutationCreateBuTopupCashToCardArgs = {
  input: CreateBuTopupCashToCardDto;
};


export type MutationCreateBuTopupCashToCustomerArgs = {
  input: CreateBuTopupCashToCustomerDto;
};


export type MutationCreateBuTopupCashToStaffArgs = {
  input: CreateBuTopupCashToStaffDto;
};


export type MutationCreateBuWalletArgs = {
  input: CreateBuWalletDto;
};


export type MutationCreateCardTopupBatchDetailArgs = {
  input: CreateCardTopupBatchDetailDto;
};


export type MutationCreateCardWithdrawCashToBuArgs = {
  input: CreateCardWithdrawCashToBuDto;
};


export type MutationCreateCustomerWithdrawCashToBuArgs = {
  input: CreateCustomerWithdrawCashToBuDto;
};


export type MutationCreateIssuedArgs = {
  input: CreateIssuedDto;
};


export type MutationCreateMerchantDividendArgs = {
  input: CreateMerchantDividendDto;
};


export type MutationCreateMerchantDividendQueueArgs = {
  input: CreateMerchantDividendQueueDto;
};


export type MutationCreateRequestorAccountSignatureArgs = {
  input: CreateRequestorAccountSignatureDto;
};


export type MutationCreateServiceAccountSignatureArgs = {
  input: CreateServiceAccountSignatureDto;
};


export type MutationCreateSystemTopupCashToBuArgs = {
  input: CreateSystemTopupCashToBuDto;
};


export type MutationCreateTopupBatchArgs = {
  input: CreateTopupBatchDto;
};


export type MutationCreateUserOtpArgs = {
  input: CreateUserOtpDto;
};


export type MutationCreateWalletArgs = {
  input: CreateWalletDto;
};


export type MutationCreateWalletCardArgs = {
  input: CreateWalletCardDto;
};


export type MutationCreateWalletCategoryArgs = {
  input: CreateWalletCategoryDto;
};


export type MutationCreateWalletIssuerArgs = {
  input: CreateWalletIssuerDto;
};


export type MutationCreateWalletMerchantArgs = {
  input: CreateWalletMerchantDto;
};


export type MutationCreateWalletMerchantOrderForCardArgs = {
  input: CreateWalletMerchantOrderForCardDto;
};


export type MutationCreateWalletMerchantQrArgs = {
  input: CreateWalletMerchantQrDto;
};


export type MutationCreateWalletQrTransferArgs = {
  input: CreateWalletQrTransferDto;
};


export type MutationCreateWalletStaffArgs = {
  input: CreateWalletStaffDto;
};


export type MutationCreateWalletTransferArgs = {
  input: CreateWalletTransferDto;
};


export type MutationDeleteCardTopupBatchDetailArgs = {
  input: DeleteCardTopupBatchDetailDto;
};


export type MutationDeleteIssuedArgs = {
  input: DeleteIssuedDto;
};


export type MutationDeleteMerchantByAdminArgs = {
  input: DeleteMerchantByAdminDto;
};


export type MutationDeleteTopupBatchArgs = {
  input: DeleteTopupBatchDto;
};


export type MutationDeleteUserByAdminArgs = {
  input: DeleteUserByAdminDto;
};


export type MutationDeleteWalletArgs = {
  input: DeleteWalletDto;
};


export type MutationDeleteWalletCardArgs = {
  input: DeleteWalletCardDto;
};


export type MutationDeleteWalletCardArrayArgs = {
  input: DeleteWalletCardArrayDto;
};


export type MutationDeleteWalletMerchantArgs = {
  input: DeleteWalletMerchantDto;
};


export type MutationDeleteWalletStaffArgs = {
  input: DeleteWalletStaffDto;
};


export type MutationDeniedCreateCustomerWithdrawCashToBuArgs = {
  input: DeniedCreateCustomerWithdrawCashToBuDto;
};


export type MutationDeniedCreateTopupBatchArgs = {
  input: DeniedCreateTopupBatchDto;
};


export type MutationDeniedIssuedArgs = {
  input: DeniedIssuedDto;
};


export type MutationMerchantCategoryCreateArgs = {
  input: CreateMerchantCategoryRequest;
};


export type MutationMerchantCategoryDeleteArgs = {
  input: DeleteMerchantCategoryRequest;
};


export type MutationMerchantCategoryUpdateArgs = {
  input: UpdateMerchantCategoryRequest;
};


export type MutationMerchantCreateArgs = {
  input: CreateMerchantRequest;
};


export type MutationMerchantDeleteArgs = {
  input: DeleteMerchantRequest;
};


export type MutationMerchantSigninArgs = {
  input: MerchantSigninDto;
};


export type MutationMerchantSignupArgs = {
  input: MerchantSignupDto;
};


export type MutationMerchantUpdateArgs = {
  input: UpdateMerchantRequest;
};


export type MutationReadCardArgs = {
  input: ReadCardDto;
};


export type MutationResetMerchantPasswordArgs = {
  input: ResetMerchantPasswordDto;
};


export type MutationResetServiceAccountPasswordArgs = {
  input: ResetServiceAccountPasswordDto;
};


export type MutationRestoreDeleteIssuedArgs = {
  input: RestoreDeleteIssuedDto;
};


export type MutationRestoreDeleteMerchantByAdminArgs = {
  input: RestoreDeleteMerchantByAdminDto;
};


export type MutationRestoreDeleteTopupBatchArgs = {
  input: RestoreDeleteTopupBatchDto;
};


export type MutationRestoreDeleteUserByAdminArgs = {
  input: RestoreDeleteUserByAdminDto;
};


export type MutationRestoreDeleteWalletArgs = {
  input: RestoreDeleteWalletDto;
};


export type MutationRestoreDeleteWalletCardArgs = {
  input: RestoreDeleteWalletCardDto;
};


export type MutationRestoreDeleteWalletCardArrayArgs = {
  input: RestoreDeleteWalletCardArrayDto;
};


export type MutationRestoreDeleteWalletMerchantArgs = {
  input: RestoreDeleteWalletMerchantDto;
};


export type MutationRestoreDeleteWalletStaffArgs = {
  input: RestoreDeleteWalletStaffDto;
};


export type MutationRoleCreateArgs = {
  input: CreateRoleRequest;
};


export type MutationRoleDeleteArgs = {
  input: DeleteRoleRequest;
};


export type MutationRoleUpdateArgs = {
  input: UpdateRoleRequest;
};


export type MutationServiceAccountSignupArgs = {
  input: ServiceAccountSignupDto;
};


export type MutationSmsCreateArgs = {
  input: CreateSmsRequest;
};


export type MutationSmsDeleteArgs = {
  input: DeleteSmsRequest;
};


export type MutationSmsUpdateArgs = {
  input: UpdateSmsRequest;
};


export type MutationUpdateAdminProfileArgs = {
  input: UpdateAdminProfileDto;
};


export type MutationUpdateCardTopupBatchDetailArgs = {
  input: UpdateCardTopupBatchDetailDto;
};


export type MutationUpdateIssuedArgs = {
  input: UpdateIssuedDto;
};


export type MutationUpdateMerchantProfileArgs = {
  input: UpdateMerchantProfileDto;
};


export type MutationUpdateMerchantProfileByAdminArgs = {
  input: UpdateMerchantProfileByAdminDto;
};


export type MutationUpdateServiceAccountProfileArgs = {
  input: UpdateServiceAccountProfileDto;
};


export type MutationUpdateServiceAccountProfileByAdminArgs = {
  input: UpdateServiceAccountProfileByAdminDto;
};


export type MutationUpdateTopupBatchArgs = {
  input: UpdateTopupBatchDto;
};


export type MutationUpdateUserProfileArgs = {
  input: UpdateUserProfileDto;
};


export type MutationUpdateUserProfileByAdminArgs = {
  input: UpdateUserProfileByAdminDto;
};


export type MutationUpdateWalletCardArgs = {
  input: UpdateWalletCardDto;
};


export type MutationUpdateWalletCardArrayToInUseArgs = {
  input: UpdateWalletCardArrayToInUseDto;
};


export type MutationUpdateWalletCardToInUseArgs = {
  input: UpdateWalletCardToInUseDto;
};


export type MutationUpdateWalletCardToLostArgs = {
  input: UpdateWalletCardToLostDto;
};


export type MutationUpdateWalletCategoryArgs = {
  input: UpdateWalletCategoryDto;
};


export type MutationUpdateWalletMerchantArgs = {
  input: UpdateWalletMerchantDto;
};


export type MutationUpgradePersonalEmployeeByAdminArgs = {
  input: UpgradePersonalEmployeeByAdminDto;
};


export type MutationUserBuSignupArgs = {
  input: UserBuSignupDto;
};


export type MutationUserSignupArgs = {
  input: UserSignupDto;
};

export type PaginateInput = {
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
};

export type Query = {
  __typename?: 'Query';
  LoadBUTopupCashToCard: LoadBuTopupCashToCardDtoResponse;
  LoadBUTopupCashToCustomer: LoadBuTopupCashToCustomerDtoResponse;
  LoadBUTopupCashToStaff: LoadBuTopupCashToStaffDtoResponse;
  LoadReportFilterSummaryDailyCounterService: LoadReportFilterSummaryDailyCounterServiceDtoResponse;
  LoadReportFilterSummaryDailyMerchant: LoadReportFilterSummaryDailyMerchantDtoResponse;
  LoadReportSummaryDailyCounterServiceBySupervisor: LoadReportSummaryDailyCounterServiceBySupervisorDtoResponse;
  LoadReportSummaryDailyMerchant: LoadReportSummaryDailyMerchantDtoResponse;
  LoadSystemTopupCashToBU: LoadSystemTopupCashToBuDtoResponse;
  adminSignin: AdminSigninDtoResponse;
  adminValidateToken: AdminValidateTokenDtoResponse;
  checkExistMerchantByUsername: CheckExistMerchantByUsernameDtoResponse;
  checkExistUserByUsername: CheckExistUserByUsernameDtoResponse;
  checkExistWalletCard: CheckExistWalletCardDtoResponse;
  createWalletQR: CreateWalletQrDtoResponse;
  loadAdmin: LoadAdminDtoResponse;
  loadAdminById: LoadAdminByIdDtoResponse;
  loadAdminDetailByToken: LoadAdminDetailByTokenDtoResponse;
  loadCardWithdrawCashToBU: LoadCardWithdrawCashToBuResponseDto;
  loadCustomerWithdrawCashToBU: LoadCustomerWithdrawCashToBuResponseDto;
  loadIssued: LoadIssuedDtoResponse;
  loadMerchant: LoadMerchantDtoResponse;
  loadMerchantById: LoadMerchantByIdDtoResponse;
  loadMerchantDetailByToken: LoadMerchantByTokenDtoResponse;
  loadMerchantSignatureArrayById: LoadMerchantSignatureArrayByIdDtoResponse;
  loadMerchantSignatureById: LoadMerchantSignatureByIdDtoResponse;
  loadMyWallet: LoadMyWalletDtoResponse;
  loadOnlyServiceAccountIdFromBUIdByAdmin: LoadOnlyServiceAccountIdFromBuIdByAdminDtoResponse;
  loadServiceAccount: LoadServiceAccountDtoResponse;
  loadServiceAccountById: LoadServiceAccountByIdDtoResponse;
  loadServiceAccountDetailByToken: LoadServiceAccountDetailByTokenDtoResponse;
  loadServiceAccountSignatureArrayById: LoadServiceAccountSignatureArrayByIdDtoResponse;
  loadServiceAccountSignatureById: LoadServiceAccountSignatureByIdDtoResponse;
  loadTopupBatch: LoadTopupBatchDtoResponse;
  loadTopupBatchDetailById: LoadTopupBatchDetailByIdDtoResponse;
  loadUser: LoadUserDtoResponse;
  loadUserById: LoadUserByIdDtoResponse;
  loadUserDetailByToken: LoadUserDetailByTokenDtoResponse;
  loadUserSignatureArrayById: LoadUserSignatureArrayByIdDtoResponse;
  loadUserSignatureById: LoadUserSignatureByIdDtoResponse;
  loadWallet: LoadWalletDtoResponse;
  loadWalletBU: LoadWalletBuDtoResponse;
  loadWalletBUBalance: LoadWalletBuBalanceDtoResponse;
  loadWalletBalance: LoadWalletBalanceDtoResponse;
  loadWalletById: LoadWalletByIdDtoResponse;
  loadWalletByService: LoadWalletByServiceDtoResponse;
  loadWalletCard: LoadWalletCardDtoResponse;
  loadWalletCardBalance: LoadWalletCardBalanceDtoResponse;
  loadWalletCardById: LoadWalletCardByIdDtoResponse;
  loadWalletCardByTopupBatchId: LoadWalletCardByTopupBatchIdDtoResponse;
  loadWalletCardReceiptTagDetail: LoadWalletCardReceiptTagDetailResponseDto;
  loadWalletCardStatementList: LoadWalletCardStatementListDtoResponse;
  loadWalletCardSummaryActivity: LoadWalletCardSummaryActivityResponseDto;
  loadWalletCardSummaryActivityDetail: LoadWalletCardSummaryActivityDetailResponseDto;
  loadWalletCategory: LoadWalletCategoryDtoResponse;
  loadWalletCategoryBU: LoadWalletCategoryBuDtoResponse;
  loadWalletDestinationByQR: LoadWalletDestinationByQrDtoResponse;
  loadWalletMerchant: LoadWalletMerchantDtoResponse;
  loadWalletMerchantBalance: LoadWalletMerchantBalanceDtoResponse;
  loadWalletMerchantReceiptTagDetail: LoadWalletMerchantReceiptTagDetailResponseDto;
  loadWalletMerchantStatementList: LoadWalletMerchantStatementListDtoResponse;
  loadWalletStaff: LoadWalletStaffDtoResponse;
  loadWalletStaffBalance: LoadWalletStaffBalanceDtoResponse;
  loadWalletStaffStatementList: LoadWalletStaffStatementListDtoResponse;
  loadWalletStatementList: LoadWalletStatementListDtoResponse;
  merchantCategoryLoadAll: LoadAllMerchantCategoryResponse;
  merchantCategoryLoadById: LoadMerchantCategoryByIdResponse;
  merchantLoadAll: LoadAllMerchantResponse;
  merchantLoadById: LoadMerchantByIdResponse;
  merchantValidateToken: MerchantValidateTokenDtoResponse;
  myRole: RoleModel;
  roleLoadAll: LoadAllRoleResponse;
  roleLoadById: LoadRoleByIdResponse;
  sayHello: Scalars['String']['output'];
  searchMerchant: SearchMerchantResponseDto;
  searchServiceAccount: SearchServiceAccountResponseDto;
  serviceAccountSignin: ServiceAccountSigninDtoResponse;
  serviceAccountValidateToken: ServiceAccountValidateTokenDtoResponse;
  smsLoadAll: LoadAllSmsResponse;
  smsLoadById: LoadSmsByIdResponse;
  userBUSignin: UserBuSigninDtoResponse;
  userSignin: UserSigninDtoResponse;
  userValidateToken: UserValidateTokenDtoResponse;
};


export type QueryLoadBuTopupCashToCardArgs = {
  input: LoadBuTopupCashToCardDto;
};


export type QueryLoadBuTopupCashToCustomerArgs = {
  input: LoadBuTopupCashToCustomerDto;
};


export type QueryLoadBuTopupCashToStaffArgs = {
  input: LoadBuTopupCashToStaffDto;
};


export type QueryLoadReportFilterSummaryDailyCounterServiceArgs = {
  input: LoadReportFilterSummaryDailyCounterServiceDto;
};


export type QueryLoadReportFilterSummaryDailyMerchantArgs = {
  input: LoadReportFilterSummaryDailyMerchantDto;
};


export type QueryLoadReportSummaryDailyCounterServiceBySupervisorArgs = {
  input: LoadReportSummaryDailyCounterServiceBySupervisorDto;
};


export type QueryLoadReportSummaryDailyMerchantArgs = {
  input: LoadReportSummaryDailyMerchantDto;
};


export type QueryLoadSystemTopupCashToBuArgs = {
  input: LoadSystemTopupCashToBuDto;
};


export type QueryAdminSigninArgs = {
  input: AdminSigninDto;
};


export type QueryCheckExistMerchantByUsernameArgs = {
  input: CheckExistMerchantByUsernameDto;
};


export type QueryCheckExistUserByUsernameArgs = {
  input: CheckExistUserByUsernameDto;
};


export type QueryCheckExistWalletCardArgs = {
  input: CheckExistWalletCardDto;
};


export type QueryCreateWalletQrArgs = {
  input: CreateWalletQrDto;
};


export type QueryLoadAdminArgs = {
  input: LoadAdminDto;
};


export type QueryLoadAdminByIdArgs = {
  input: LoadAdminByIdDto;
};


export type QueryLoadCardWithdrawCashToBuArgs = {
  input: LoadCardWithdrawCashToBuDto;
};


export type QueryLoadCustomerWithdrawCashToBuArgs = {
  input: LoadCustomerWithdrawCashToBuDto;
};


export type QueryLoadIssuedArgs = {
  input: LoadIssuedDto;
};


export type QueryLoadMerchantArgs = {
  input: LoadMerchantDto;
};


export type QueryLoadMerchantByIdArgs = {
  input: LoadMerchantByIdDto;
};


export type QueryLoadMerchantSignatureArrayByIdArgs = {
  input: LoadMerchantSignatureArrayByIdDto;
};


export type QueryLoadMerchantSignatureByIdArgs = {
  input: LoadMerchantSignatureByIdDto;
};


export type QueryLoadOnlyServiceAccountIdFromBuIdByAdminArgs = {
  input: LoadOnlyServiceAccountIdFromBuIdByAdminDto;
};


export type QueryLoadServiceAccountArgs = {
  input: LoadServiceAccountDto;
};


export type QueryLoadServiceAccountByIdArgs = {
  input: LoadServiceAccountByIdDto;
};


export type QueryLoadServiceAccountSignatureArrayByIdArgs = {
  input: LoadServiceAccountSignatureArrayByIdDto;
};


export type QueryLoadServiceAccountSignatureByIdArgs = {
  input: LoadServiceAccountSignatureByIdDto;
};


export type QueryLoadTopupBatchArgs = {
  input: LoadTopupBatchDto;
};


export type QueryLoadTopupBatchDetailByIdArgs = {
  input: LoadTopupBatchDetailByIdDto;
};


export type QueryLoadUserArgs = {
  input: LoadUserDto;
};


export type QueryLoadUserByIdArgs = {
  input: LoadUserByIdDto;
};


export type QueryLoadUserSignatureArrayByIdArgs = {
  input: LoadUserSignatureArrayByIdDto;
};


export type QueryLoadUserSignatureByIdArgs = {
  input: LoadUserSignatureByIdDto;
};


export type QueryLoadWalletArgs = {
  input: LoadWalletDto;
};


export type QueryLoadWalletBuArgs = {
  input: LoadWalletBuDto;
};


export type QueryLoadWalletBuBalanceArgs = {
  input: LoadWalletBuBalanceDto;
};


export type QueryLoadWalletByIdArgs = {
  input: LoadWalletByIdDto;
};


export type QueryLoadWalletByServiceArgs = {
  input: LoadWalletByServiceDto;
};


export type QueryLoadWalletCardArgs = {
  input: LoadWalletCardDto;
};


export type QueryLoadWalletCardBalanceArgs = {
  input: LoadWalletCardBalanceDto;
};


export type QueryLoadWalletCardByIdArgs = {
  input: LoadWalletCardByIdDto;
};


export type QueryLoadWalletCardByTopupBatchIdArgs = {
  input: LoadWalletCardByTopupBatchIdDto;
};


export type QueryLoadWalletCardReceiptTagDetailArgs = {
  input: LoadWalletCardReceiptTagDetailDto;
};


export type QueryLoadWalletCardStatementListArgs = {
  input: LoadWalletCardStatementListDto;
};


export type QueryLoadWalletCardSummaryActivityArgs = {
  input: LoadWalletCardSummaryActivityDto;
};


export type QueryLoadWalletCardSummaryActivityDetailArgs = {
  input: LoadWalletCardSummaryActivityDetailDto;
};


export type QueryLoadWalletCategoryArgs = {
  input: LoadWalletCategoryDto;
};


export type QueryLoadWalletCategoryBuArgs = {
  input: LoadWalletCategoryBuDto;
};


export type QueryLoadWalletDestinationByQrArgs = {
  input: LoadWalletDestinationByQrDto;
};


export type QueryLoadWalletMerchantArgs = {
  input: LoadWalletMerchantDto;
};


export type QueryLoadWalletMerchantReceiptTagDetailArgs = {
  input: LoadWalletMerchantReceiptTagDetailDto;
};


export type QueryLoadWalletMerchantStatementListArgs = {
  input: LoadWalletMerchantStatementListDto;
};


export type QueryLoadWalletStaffArgs = {
  input: LoadWalletStaffDto;
};


export type QueryLoadWalletStaffStatementListArgs = {
  input: LoadWalletStaffStatementListDto;
};


export type QueryLoadWalletStatementListArgs = {
  input: LoadWalletStatementListDto;
};


export type QueryMerchantCategoryLoadAllArgs = {
  query: QueryProps;
};


export type QueryMerchantCategoryLoadByIdArgs = {
  input: LoadMerchantCategoryByIdRequest;
};


export type QueryMerchantLoadAllArgs = {
  query: QueryProps;
};


export type QueryMerchantLoadByIdArgs = {
  input: LoadMerchantByIdRequest;
};


export type QueryRoleLoadAllArgs = {
  query: QueryProps;
};


export type QueryRoleLoadByIdArgs = {
  input: LoadRoleByIdRequest;
};


export type QuerySearchMerchantArgs = {
  input: SearchMerchantDto;
};


export type QuerySearchServiceAccountArgs = {
  input: SearchServiceAccountDto;
};


export type QueryServiceAccountSigninArgs = {
  input: ServiceAccountSigninDto;
};


export type QuerySmsLoadAllArgs = {
  query: QueryProps;
};


export type QuerySmsLoadByIdArgs = {
  input: LoadSmsByIdRequest;
};


export type QueryUserBuSigninArgs = {
  input: UserBuSigninDto;
};


export type QueryUserSigninArgs = {
  input: UserSigninDto;
};

export type QueryProps = {
  condition?: InputMaybe<Array<ConditionInput>>;
  dateFilter?: InputMaybe<DateFilterInput>;
  inNumber?: InputMaybe<Array<InNumberInput>>;
  inString?: InputMaybe<Array<InStringInput>>;
  joins?: InputMaybe<Array<Scalars['String']['input']>>;
  paginate?: InputMaybe<PaginateInput>;
  search?: InputMaybe<SearchInput>;
  select?: InputMaybe<Array<Scalars['String']['input']>>;
  sort?: InputMaybe<Scalars['Int']['input']>;
};

export type ReadCardDto = {
  cardNo: Scalars['String']['input'];
  scannerId: Scalars['String']['input'];
};

export type ReadCardDtoResponse = {
  __typename?: 'ReadCardDtoResponse';
  isComplete?: Maybe<Scalars['Boolean']['output']>;
};

export type ResetMerchantPasswordDto = {
  merchantId: Scalars['String']['input'];
  newPassword: Scalars['String']['input'];
};

export type ResetMerchantPasswordResponseDto = {
  __typename?: 'ResetMerchantPasswordResponseDto';
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ResetServiceAccountPasswordDto = {
  newPassword: Scalars['String']['input'];
  serviceAccountId: Scalars['String']['input'];
};

export type ResetServiceAccountPasswordResponseDto = {
  __typename?: 'ResetServiceAccountPasswordResponseDto';
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ResponseMerchantCategoryModel = {
  __typename?: 'ResponseMerchantCategoryModel';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  laName: Scalars['String']['output'];
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ResponseMerchantModel = {
  __typename?: 'ResponseMerchantModel';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  email: Scalars['String']['output'];
  isActive?: Maybe<Scalars['Boolean']['output']>;
  merchantCategory?: Maybe<MerchantCategoryModel>;
  merchantCategoryId: Scalars['Int']['output'];
  merchantCode: Scalars['String']['output'];
  name: Scalars['String']['output'];
  phoneNumber: Scalars['String']['output'];
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  username: Scalars['String']['output'];
};

export type ResponseRoleModel = {
  __typename?: 'ResponseRoleModel';
  _id: Scalars['String']['output'];
  createdAt: Scalars['String']['output'];
  enName: Scalars['String']['output'];
  laName: Scalars['String']['output'];
  level: Scalars['String']['output'];
  menus: Array<RoleMenuModel>;
  systemCode: Scalars['String']['output'];
  updatedAt: Scalars['String']['output'];
};

export type ResponseSmsModel = {
  __typename?: 'ResponseSmsModel';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  name: Scalars['String']['output'];
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type RestoreDeleteAdminDtoResponse = {
  __typename?: 'RestoreDeleteAdminDtoResponse';
  admin?: Maybe<AdminType>;
};

export type RestoreDeleteIssuedDto = {
  _id: Scalars['String']['input'];
};

export type RestoreDeleteIssuedDtoResponse = {
  __typename?: 'RestoreDeleteIssuedDtoResponse';
  issued?: Maybe<IssuedType>;
};

export type RestoreDeleteMerchantByAdminDto = {
  merchantId: Scalars['String']['input'];
};

export type RestoreDeleteMerchantByAdminDtoResponse = {
  __typename?: 'RestoreDeleteMerchantByAdminDtoResponse';
  merchant?: Maybe<MerchantType>;
};

export type RestoreDeleteMerchantDtoResponse = {
  __typename?: 'RestoreDeleteMerchantDtoResponse';
  merchant?: Maybe<MerchantType>;
};

export type RestoreDeleteServiceAccountDtoResponse = {
  __typename?: 'RestoreDeleteServiceAccountDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type RestoreDeleteTopupBatchDto = {
  _id: Scalars['String']['input'];
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type RestoreDeleteTopupBatchDtoResponse = {
  __typename?: 'RestoreDeleteTopupBatchDtoResponse';
  topupBatch?: Maybe<TopupBatchType>;
};

export type RestoreDeleteUserByAdminDto = {
  userId: Scalars['String']['input'];
};

export type RestoreDeleteUserByAdminDtoResponse = {
  __typename?: 'RestoreDeleteUserByAdminDtoResponse';
  user?: Maybe<UserType>;
};

export type RestoreDeleteUserDtoResponse = {
  __typename?: 'RestoreDeleteUserDtoResponse';
  user?: Maybe<UserType>;
};

export type RestoreDeleteWalletCardArrayDto = {
  _ids: Array<Scalars['String']['input']>;
};

export type RestoreDeleteWalletCardArrayDtoResponse = {
  __typename?: 'RestoreDeleteWalletCardArrayDtoResponse';
  walletCard?: Maybe<Array<WalletCardType>>;
};

export type RestoreDeleteWalletCardDto = {
  _id: Scalars['String']['input'];
};

export type RestoreDeleteWalletCardDtoResponse = {
  __typename?: 'RestoreDeleteWalletCardDtoResponse';
  walletCard?: Maybe<WalletCardType>;
};

export type RestoreDeleteWalletDto = {
  _id: Scalars['String']['input'];
};

export type RestoreDeleteWalletDtoResponse = {
  __typename?: 'RestoreDeleteWalletDtoResponse';
  wallet?: Maybe<WalletType>;
};

export type RestoreDeleteWalletMerchantDto = {
  _id: Scalars['String']['input'];
};

export type RestoreDeleteWalletMerchantDtoResponse = {
  __typename?: 'RestoreDeleteWalletMerchantDtoResponse';
  walletMerchant?: Maybe<WalletMerchantDto>;
};

export type RestoreDeleteWalletStaffDto = {
  _id: Scalars['String']['input'];
};

export type RestoreDeleteWalletStaffDtoResponse = {
  __typename?: 'RestoreDeleteWalletStaffDtoResponse';
  walletStaff: WalletStaffType;
};

export type RoleMenuModel = {
  __typename?: 'RoleMenuModel';
  enMenu: Scalars['String']['output'];
  enSection: Scalars['String']['output'];
  exactMatch: Scalars['Boolean']['output'];
  href: Scalars['String']['output'];
  icon: Scalars['String']['output'];
  laMenu: Scalars['String']['output'];
  laSection: Scalars['String']['output'];
  permission: Array<Scalars['String']['output']>;
  subMenu: Array<SubRoleMenuModel>;
};

export type RoleModel = {
  __typename?: 'RoleModel';
  _id: Scalars['String']['output'];
  createdAt: Scalars['String']['output'];
  enName: Scalars['String']['output'];
  laName: Scalars['String']['output'];
  level: Scalars['String']['output'];
  menus: Array<RoleMenuModel>;
  systemCode: Scalars['String']['output'];
  updatedAt: Scalars['String']['output'];
};

export type SearchInput = {
  q?: InputMaybe<Scalars['String']['input']>;
  searchField?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type SearchMerchantDto = {
  keyword: Scalars['String']['input'];
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
};

export type SearchMerchantResponseDto = {
  __typename?: 'SearchMerchantResponseDto';
  count?: Maybe<Scalars['Float']['output']>;
  merchant?: Maybe<Array<Maybe<MerchantType>>>;
};

export type SearchServiceAccountDto = {
  keyword: Scalars['String']['input'];
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
};

export type SearchServiceAccountResponseDto = {
  __typename?: 'SearchServiceAccountResponseDto';
  count?: Maybe<Scalars['Float']['output']>;
  serviceAccount?: Maybe<Array<Maybe<ServiceAccountType>>>;
};

export type SendSmsResponse = {
  __typename?: 'SendSmsResponse';
  _id?: Maybe<Scalars['String']['output']>;
  code?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  isSent: Scalars['Boolean']['output'];
  message: Scalars['String']['output'];
  name: Scalars['String']['output'];
  phoneNumber: Scalars['String']['output'];
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountConfigType = {
  __typename?: 'ServiceAccountConfigType';
  assignBy?: Maybe<Scalars['String']['output']>;
  assignDate?: Maybe<Scalars['String']['output']>;
  assignId?: Maybe<Scalars['String']['output']>;
  level?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountInfoType = {
  __typename?: 'ServiceAccountInfoType';
  _id?: Maybe<Scalars['String']['output']>;
  config: ServiceAccountConfigType;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  password?: Maybe<Scalars['String']['output']>;
  phoneNumber?: Maybe<Scalars['String']['output']>;
  platform?: Maybe<Scalars['String']['output']>;
  prefix?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Float']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  username?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountProfileImageInput = {
  cover?: InputMaybe<Scalars['String']['input']>;
  profile?: InputMaybe<Scalars['String']['input']>;
};

export type ServiceAccountProfileImageType = {
  __typename?: 'ServiceAccountProfileImageType';
  cover?: Maybe<Scalars['String']['output']>;
  profile?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountProfileType = {
  __typename?: 'ServiceAccountProfileType';
  _id?: Maybe<Scalars['String']['output']>;
  address?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  district?: Maybe<Scalars['String']['output']>;
  firstName?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  image?: Maybe<ServiceAccountProfileImageType>;
  isActive?: Maybe<Scalars['String']['output']>;
  lastName?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  postcode?: Maybe<Scalars['String']['output']>;
  province?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Float']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  village?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountSignatureType = {
  __typename?: 'ServiceAccountSignatureType';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  privateKey?: Maybe<Scalars['String']['output']>;
  publicKey?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Float']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountSigninDto = {
  password?: InputMaybe<Scalars['String']['input']>;
  username?: InputMaybe<Scalars['String']['input']>;
};

export type ServiceAccountSigninDtoResponse = {
  __typename?: 'ServiceAccountSigninDtoResponse';
  authorization: Scalars['String']['output'];
  business?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountSignupDto = {
  firstName?: InputMaybe<Scalars['String']['input']>;
  lastName?: InputMaybe<Scalars['String']['input']>;
  level?: InputMaybe<Scalars['String']['input']>;
  password?: InputMaybe<Scalars['String']['input']>;
  username?: InputMaybe<Scalars['String']['input']>;
};

export type ServiceAccountSignupDtoResponse = {
  __typename?: 'ServiceAccountSignupDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type ServiceAccountType = {
  __typename?: 'ServiceAccountType';
  serviceAccount?: Maybe<ServiceAccountInfoType>;
  serviceAccountProfile?: Maybe<ServiceAccountProfileType>;
};

export type ServiceAccountValidateTokenDtoResponse = {
  __typename?: 'ServiceAccountValidateTokenDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type StatementTypeDtoResponse = {
  __typename?: 'StatementTypeDtoResponse';
  method?: Maybe<Scalars['String']['output']>;
  statement?: Maybe<Scalars['String']['output']>;
  transaction?: Maybe<Scalars['String']['output']>;
};

export type SubRoleMenuModel = {
  __typename?: 'SubRoleMenuModel';
  enMenu: Scalars['String']['output'];
  enSection: Scalars['String']['output'];
  exactMatch: Scalars['Boolean']['output'];
  href: Scalars['String']['output'];
  icon: Scalars['String']['output'];
  laMenu: Scalars['String']['output'];
  laSection: Scalars['String']['output'];
  permission: Array<Scalars['String']['output']>;
};

export type TopupBatchDetailReferenceType = {
  __typename?: 'TopupBatchDetailReferenceType';
  paymentMethod?: Maybe<Scalars['String']['output']>;
};

export type TopupBatchDetailType = {
  __typename?: 'TopupBatchDetailType';
  _id?: Maybe<Scalars['String']['output']>;
  amount: Scalars['Float']['output'];
  cardNo?: Maybe<Scalars['String']['output']>;
  cardType?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  groupName?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  reference: TopupBatchDetailReferenceType;
  status?: Maybe<Scalars['String']['output']>;
  topupBatchId?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId: Scalars['Int']['output'];
  updatedAt?: Maybe<Scalars['String']['output']>;
  walletId?: Maybe<Scalars['String']['output']>;
};

export type TopupBatchReferenceSignType = {
  __typename?: 'TopupBatchReferenceSignType';
  datetime?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  signed?: Maybe<Scalars['String']['output']>;
};

export type TopupBatchReferenceType = {
  __typename?: 'TopupBatchReferenceType';
  confirmBy?: Maybe<TopupBatchReferenceSignType>;
  createdBy?: Maybe<TopupBatchReferenceSignType>;
  deniedBy?: Maybe<TopupBatchReferenceSignType>;
};

export type TopupBatchType = {
  __typename?: 'TopupBatchType';
  _id?: Maybe<Scalars['String']['output']>;
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  group?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  reference?: Maybe<TopupBatchReferenceType>;
  status?: Maybe<Scalars['String']['output']>;
  target?: Maybe<Scalars['String']['output']>;
  transactionId?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId: Scalars['Int']['output'];
  updatedAt?: Maybe<Scalars['String']['output']>;
  walletId?: Maybe<Scalars['String']['output']>;
};

export type TopupReferenceQrInfoType = {
  __typename?: 'TopupReferenceQRInfoType';
  transactionId?: Maybe<Scalars['String']['output']>;
};

export type TopupReferenceType = {
  __typename?: 'TopupReferenceType';
  changeMethod?: Maybe<Scalars['String']['output']>;
  changeMethodBy?: Maybe<Scalars['String']['output']>;
  changeMethodTime?: Maybe<Scalars['String']['output']>;
  manager?: Maybe<Scalars['String']['output']>;
  paymentMethod?: Maybe<Scalars['String']['output']>;
  qrInfo?: Maybe<TopupReferenceQrInfoType>;
  topupMethod?: Maybe<Scalars['String']['output']>;
};

export type TopupStatementTypeDto = {
  __typename?: 'TopupStatementTypeDto';
  statement?: Maybe<Scalars['String']['output']>;
  transaction?: Maybe<Scalars['String']['output']>;
};

export type TopupType = {
  __typename?: 'TopupType';
  _id?: Maybe<Scalars['String']['output']>;
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  receiver?: Maybe<Scalars['String']['output']>;
  reference?: Maybe<TopupReferenceType>;
  sender?: Maybe<Scalars['String']['output']>;
  serviceAccount?: Maybe<Scalars['String']['output']>;
  serviceAccountHash?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  transactionId?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId: Scalars['Int']['output'];
  updatedAt?: Maybe<Scalars['String']['output']>;
  walletCard?: Maybe<WalletCardType>;
};

export type UpdateAdminProfileDto = {
  address?: InputMaybe<Scalars['String']['input']>;
  district?: InputMaybe<Scalars['String']['input']>;
  firstName: Scalars['String']['input'];
  image?: InputMaybe<AdminProfileImageInput>;
  lastName: Scalars['String']['input'];
  postcode?: InputMaybe<Scalars['String']['input']>;
  province?: InputMaybe<Scalars['String']['input']>;
  village?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateAdminProfileDtoResponse = {
  __typename?: 'UpdateAdminProfileDtoResponse';
  admin?: Maybe<AdminType>;
};

export type UpdateCardTopupBatchDetailDto = {
  _id: Scalars['String']['input'];
  objects: Array<UpdateCardTopupBatchDetailObject>;
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateCardTopupBatchDetailDtoResponse = {
  __typename?: 'UpdateCardTopupBatchDetailDtoResponse';
  topupBatch?: Maybe<TopupBatchType>;
  topupBatchDetail?: Maybe<Array<TopupBatchDetailType>>;
};

export type UpdateCardTopupBatchDetailObject = {
  _id: Scalars['String']['input'];
  amount: Scalars['Float']['input'];
};

export type UpdateIssuedDto = {
  _id: Scalars['String']['input'];
  amount: Scalars['Float']['input'];
  description: Scalars['String']['input'];
  reference?: InputMaybe<IssuedReferenceInput>;
};

export type UpdateIssuedDtoResponse = {
  __typename?: 'UpdateIssuedDtoResponse';
  issued?: Maybe<IssuedType>;
};

export type UpdateMerchantCategoryRequest = {
  _id: Scalars['String']['input'];
  name: Scalars['String']['input'];
};

export type UpdateMerchantCategoryResponse = {
  __typename?: 'UpdateMerchantCategoryResponse';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  laName?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type UpdateMerchantProfileByAdminDto = {
  image?: InputMaybe<MerchantProfileImageInput>;
  merchantId: Scalars['String']['input'];
  name: Scalars['String']['input'];
};

export type UpdateMerchantProfileDto = {
  image?: InputMaybe<MerchantProfileImageInput>;
  name: Scalars['String']['input'];
};

export type UpdateMerchantProfileDtoResponse = {
  __typename?: 'UpdateMerchantProfileDtoResponse';
  merchant?: Maybe<MerchantType>;
};

export type UpdateMerchantRequest = {
  _id: Scalars['String']['input'];
  name: Scalars['String']['input'];
};

export type UpdateMerchantResponse = {
  __typename?: 'UpdateMerchantResponse';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  email?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  merchantCategory?: Maybe<MerchantCategoryModel>;
  merchantCategoryId?: Maybe<Scalars['Int']['output']>;
  merchantCode?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  phoneNumber?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  username?: Maybe<Scalars['String']['output']>;
};

export type UpdateRoleRequest = {
  _id: Scalars['String']['input'];
  name: Scalars['String']['input'];
};

export type UpdateRoleResponse = {
  __typename?: 'UpdateRoleResponse';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  enName?: Maybe<Scalars['String']['output']>;
  laName?: Maybe<Scalars['String']['output']>;
  level?: Maybe<Scalars['String']['output']>;
  menus?: Maybe<Array<RoleMenuModel>>;
  systemCode?: Maybe<Scalars['String']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type UpdateServiceAccountProfileByAdminDto = {
  address?: InputMaybe<Scalars['String']['input']>;
  district?: InputMaybe<Scalars['String']['input']>;
  firstName?: InputMaybe<Scalars['String']['input']>;
  image: ServiceAccountProfileImageInput;
  lastName?: InputMaybe<Scalars['String']['input']>;
  postcode?: InputMaybe<Scalars['String']['input']>;
  province?: InputMaybe<Scalars['String']['input']>;
  serviceAccountId?: InputMaybe<Scalars['String']['input']>;
  village?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateServiceAccountProfileByAdminDtoResponse = {
  __typename?: 'UpdateServiceAccountProfileByAdminDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type UpdateServiceAccountProfileDto = {
  address?: InputMaybe<Scalars['String']['input']>;
  district?: InputMaybe<Scalars['String']['input']>;
  firstName?: InputMaybe<Scalars['String']['input']>;
  image: ServiceAccountProfileImageInput;
  lastName?: InputMaybe<Scalars['String']['input']>;
  postcode?: InputMaybe<Scalars['String']['input']>;
  province?: InputMaybe<Scalars['String']['input']>;
  village?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateServiceAccountProfileDtoResponse = {
  __typename?: 'UpdateServiceAccountProfileDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type UpdateSmsRequest = {
  _id: Scalars['String']['input'];
  name: Scalars['String']['input'];
};

export type UpdateSmsResponse = {
  __typename?: 'UpdateSmsResponse';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type UpdateTopupBatchDto = {
  _id: Scalars['String']['input'];
  description: Scalars['String']['input'];
  walletId?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateTopupBatchDtoResponse = {
  __typename?: 'UpdateTopupBatchDtoResponse';
  topupBatch?: Maybe<TopupBatchType>;
};

export type UpdateUserProfileByAdminDto = {
  address?: InputMaybe<Scalars['String']['input']>;
  district?: InputMaybe<Scalars['String']['input']>;
  firstName?: InputMaybe<Scalars['String']['input']>;
  image?: InputMaybe<UserProfileImageInput>;
  lastName?: InputMaybe<Scalars['String']['input']>;
  postcode?: InputMaybe<Scalars['String']['input']>;
  province?: InputMaybe<Scalars['String']['input']>;
  userId: Scalars['String']['input'];
  village?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateUserProfileByAdminDtoResponse = {
  __typename?: 'UpdateUserProfileByAdminDtoResponse';
  user?: Maybe<UserType>;
};

export type UpdateUserProfileDto = {
  address?: InputMaybe<Scalars['String']['input']>;
  district?: InputMaybe<Scalars['String']['input']>;
  firstName: Scalars['String']['input'];
  image?: InputMaybe<UserProfileImageInput>;
  lastName: Scalars['String']['input'];
  postcode?: InputMaybe<Scalars['String']['input']>;
  province?: InputMaybe<Scalars['String']['input']>;
  village?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateUserProfileDtoResponse = {
  __typename?: 'UpdateUserProfileDtoResponse';
  user?: Maybe<UserType>;
};

export type UpdateWalletCardArrayToInUseDto = {
  _ids: Array<Scalars['String']['input']>;
};

export type UpdateWalletCardArrayToInUseDtoResponse = {
  __typename?: 'UpdateWalletCardArrayToInUseDtoResponse';
  walletCard?: Maybe<Array<WalletCardType>>;
};

export type UpdateWalletCardDto = {
  _id: Scalars['String']['input'];
  attach?: InputMaybe<Scalars['String']['input']>;
  cardName: Scalars['String']['input'];
  cardNo: Scalars['String']['input'];
  staffId?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateWalletCardDtoResponse = {
  __typename?: 'UpdateWalletCardDtoResponse';
  walletCard?: Maybe<WalletCardType>;
  walletCardAssignment?: Maybe<WalletCardAssignmentType>;
};

export type UpdateWalletCardToInUseDto = {
  _id: Scalars['String']['input'];
};

export type UpdateWalletCardToInUseDtoResponse = {
  __typename?: 'UpdateWalletCardToInUseDtoResponse';
  walletCard?: Maybe<WalletCardType>;
};

export type UpdateWalletCardToLostDto = {
  _id: Scalars['String']['input'];
};

export type UpdateWalletCardToLostDtoResponse = {
  __typename?: 'UpdateWalletCardToLostDtoResponse';
  walletCard?: Maybe<WalletCardType>;
};

export type UpdateWalletCategoryDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
  name?: InputMaybe<Scalars['String']['input']>;
  walletCategoryRoleId?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateWalletCategoryDtoResponse = {
  __typename?: 'UpdateWalletCategoryDtoResponse';
  _id?: Maybe<Scalars['String']['output']>;
};

export type UpdateWalletMerchantDto = {
  _id: Scalars['String']['input'];
  name: Scalars['String']['input'];
};

export type UpdateWalletMerchantDtoResponse = {
  __typename?: 'UpdateWalletMerchantDtoResponse';
  walletMerchant?: Maybe<WalletMerchantDto>;
};

export type UpgradePersonalEmployeeByAdminDto = {
  userId: Scalars['String']['input'];
};

export type UpgradePersonalEmployeeByAdminDtoResponse = {
  __typename?: 'UpgradePersonalEmployeeByAdminDtoResponse';
  user?: Maybe<UserType>;
};

export type UserBuSigninDto = {
  password: Scalars['String']['input'];
  username: Scalars['String']['input'];
};

export type UserBuSigninDtoResponse = {
  __typename?: 'UserBUSigninDtoResponse';
  authorization: Scalars['String']['output'];
};

export type UserBuSignupDto = {
  firstName: Scalars['String']['input'];
  lastName: Scalars['String']['input'];
  level: Scalars['String']['input'];
  password: Scalars['String']['input'];
  username: Scalars['String']['input'];
};

export type UserBuSignupDtoResponse = {
  __typename?: 'UserBUSignupDtoResponse';
  user?: Maybe<UserType>;
};

export type UserConfigType = {
  __typename?: 'UserConfigType';
  assignBy?: Maybe<Scalars['String']['output']>;
  assignDate?: Maybe<Scalars['String']['output']>;
  assignId?: Maybe<Scalars['String']['output']>;
  level?: Maybe<Scalars['String']['output']>;
};

export type UserInfoType = {
  __typename?: 'UserInfoType';
  _id?: Maybe<Scalars['String']['output']>;
  config?: Maybe<UserConfigType>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  password?: Maybe<Scalars['String']['output']>;
  phoneNumber?: Maybe<Scalars['String']['output']>;
  platform?: Maybe<Scalars['String']['output']>;
  prefix?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  username?: Maybe<Scalars['String']['output']>;
};

export type UserProfileImageInput = {
  cover?: InputMaybe<Scalars['String']['input']>;
  profile?: InputMaybe<Scalars['String']['input']>;
};

export type UserProfileImageType = {
  __typename?: 'UserProfileImageType';
  cover?: Maybe<Scalars['String']['output']>;
  profile?: Maybe<Scalars['String']['output']>;
};

export type UserProfileType = {
  __typename?: 'UserProfileType';
  _id?: Maybe<Scalars['String']['output']>;
  address?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  district?: Maybe<Scalars['String']['output']>;
  firstName?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  image?: Maybe<UserProfileImageType>;
  isActive?: Maybe<Scalars['String']['output']>;
  lastName?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  postcode?: Maybe<Scalars['String']['output']>;
  province?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  village?: Maybe<Scalars['String']['output']>;
};

export type UserSignatureType = {
  __typename?: 'UserSignatureType';
  _id: Scalars['String']['output'];
  createdAt: Scalars['String']['output'];
  hash: Scalars['String']['output'];
  isActive: Scalars['String']['output'];
  ownerId: Scalars['String']['output'];
  privateKey: Scalars['String']['output'];
  publicKey: Scalars['String']['output'];
  uid: Scalars['String']['output'];
  uniqueId: Scalars['Int']['output'];
  updatedAt: Scalars['String']['output'];
  user?: Maybe<UserInfoType>;
};

export type UserSigninDto = {
  password: Scalars['String']['input'];
  phoneNumber: Scalars['String']['input'];
};

export type UserSigninDtoResponse = {
  __typename?: 'UserSigninDtoResponse';
  authorization: Scalars['String']['output'];
};

export type UserSignupDto = {
  firstName: Scalars['String']['input'];
  lastName: Scalars['String']['input'];
  password: Scalars['String']['input'];
  phoneNumber: Scalars['String']['input'];
};

export type UserSignupDtoResponse = {
  __typename?: 'UserSignupDtoResponse';
  user?: Maybe<UserType>;
};

export type UserType = {
  __typename?: 'UserType';
  user?: Maybe<UserInfoType>;
  userProfile?: Maybe<UserProfileType>;
  userSignature?: Maybe<UserSignatureType>;
};

export type UserValidateTokenDtoResponse = {
  __typename?: 'UserValidateTokenDtoResponse';
  user?: Maybe<UserType>;
};

export type WalletCardActivityLogType = {
  __typename?: 'WalletCardActivityLogType';
  inuseBy?: Maybe<Scalars['String']['output']>;
  inuseHash?: Maybe<Scalars['String']['output']>;
  inuseTime?: Maybe<Scalars['String']['output']>;
  lostBy?: Maybe<Scalars['String']['output']>;
  lostHash?: Maybe<Scalars['String']['output']>;
  lostTime?: Maybe<Scalars['String']['output']>;
  tag?: Maybe<Scalars['String']['output']>;
};

export type WalletCardActivityType = {
  __typename?: 'WalletCardActivityType';
  _id?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  cardName?: Maybe<Scalars['String']['output']>;
  cardNo?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  log?: Maybe<WalletCardActivityLogType>;
  queue?: Maybe<Scalars['String']['output']>;
  reference?: Maybe<WalletCardReferenceType>;
  status?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  walletId?: Maybe<Scalars['String']['output']>;
};

export type WalletCardAssignmentType = {
  __typename?: 'WalletCardAssignmentType';
  _id?: Maybe<Scalars['String']['output']>;
  attach?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  staffId?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  walletId?: Maybe<Scalars['String']['output']>;
};

export type WalletCardReferenceType = {
  __typename?: 'WalletCardReferenceType';
  cardType?: Maybe<Scalars['String']['output']>;
  paymentMethod?: Maybe<Scalars['String']['output']>;
  referenceHash?: Maybe<Scalars['String']['output']>;
};

export type WalletCardTagReferenceDto = {
  __typename?: 'WalletCardTagReferenceDto';
  paymentMethod?: Maybe<Scalars['String']['output']>;
  paymentMethodType?: Maybe<Scalars['String']['output']>;
  referenceHash?: Maybe<Scalars['String']['output']>;
};

export type WalletCardType = {
  __typename?: 'WalletCardType';
  _id?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  cardName?: Maybe<Scalars['String']['output']>;
  cardNo?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  queue?: Maybe<Scalars['String']['output']>;
  reference?: Maybe<WalletCardReferenceType>;
  status?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  walletCardActivity?: Maybe<WalletCardActivityType>;
  walletCardAssignment?: Maybe<WalletCardAssignmentType>;
  walletId?: Maybe<Scalars['String']['output']>;
};

export type WalletCategoryType = {
  __typename?: 'WalletCategoryType';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  walletCategoryRoleId?: Maybe<Scalars['String']['output']>;
};

export type WalletMerchantDto = {
  __typename?: 'WalletMerchantDto';
  _id?: Maybe<Scalars['String']['output']>;
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  hash: Scalars['String']['output'];
  isActive?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  queue?: Maybe<Scalars['String']['output']>;
  reference?: Maybe<WalletMerchantReferenceDto>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  username?: Maybe<Scalars['String']['output']>;
  walletId?: Maybe<Scalars['String']['output']>;
  walletMerchantProfile?: Maybe<WalletMerchantProfileDto>;
};

export type WalletMerchantProfileDto = {
  __typename?: 'WalletMerchantProfileDto';
  name?: Maybe<Scalars['String']['output']>;
};

export type WalletMerchantReferenceDto = {
  __typename?: 'WalletMerchantReferenceDto';
  paymentMethod?: Maybe<Scalars['String']['output']>;
  referenceHash?: Maybe<Scalars['String']['output']>;
};

export type WalletMerchantTagReferenceDto = {
  __typename?: 'WalletMerchantTagReferenceDto';
  paymentMethod?: Maybe<Scalars['String']['output']>;
  paymentMethodType?: Maybe<Scalars['String']['output']>;
  referenceHash?: Maybe<Scalars['String']['output']>;
};

export type WalletProfileInfoType = {
  __typename?: 'WalletProfileInfoType';
  firstName?: Maybe<Scalars['String']['output']>;
  lastName?: Maybe<Scalars['String']['output']>;
};

export type WalletReferenceType = {
  __typename?: 'WalletReferenceType';
  group?: Maybe<Scalars['String']['output']>;
  referenceHash?: Maybe<Scalars['String']['output']>;
};

export type WalletStaffReferenceDto = {
  __typename?: 'WalletStaffReferenceDto';
  group?: Maybe<Scalars['String']['output']>;
  referenceHash?: Maybe<Scalars['String']['output']>;
};

export type WalletStaffType = {
  __typename?: 'WalletStaffType';
  _id?: Maybe<Scalars['String']['output']>;
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  queue?: Maybe<Scalars['String']['output']>;
  reference: WalletStaffReferenceDto;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  walletId?: Maybe<Scalars['String']['output']>;
};

export type WalletTagReferenceDto = {
  __typename?: 'WalletTagReferenceDto';
  paymentMethod?: Maybe<Scalars['String']['output']>;
  paymentMethodType?: Maybe<Scalars['String']['output']>;
  referenceHash?: Maybe<Scalars['String']['output']>;
};

export type WalletType = {
  __typename?: 'WalletType';
  _id?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  queue?: Maybe<Scalars['String']['output']>;
  reference?: Maybe<WalletReferenceType>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  walletCategory?: Maybe<WalletCategoryType>;
  walletCategoryId?: Maybe<Scalars['String']['output']>;
  walletProfileInfo?: Maybe<WalletProfileInfoType>;
};

export type WithdrawAllCardLostDtoResponse = {
  __typename?: 'WithdrawAllCardLostDtoResponse';
  isComplete?: Maybe<Scalars['Boolean']['output']>;
};

export type WithdrawReferenceQrInfoType = {
  __typename?: 'WithdrawReferenceQRInfoType';
  transactionId?: Maybe<Scalars['String']['output']>;
};

export type WithdrawReferenceType = {
  __typename?: 'WithdrawReferenceType';
  manager?: Maybe<Scalars['String']['output']>;
  paymentMethod?: Maybe<Scalars['String']['output']>;
  qrInfo: WithdrawReferenceQrInfoType;
  withdrawMethod?: Maybe<Scalars['String']['output']>;
};

export type WithdrawType = {
  __typename?: 'WithdrawType';
  _id?: Maybe<Scalars['String']['output']>;
  amount: Scalars['Float']['output'];
  createdAt?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  receiver?: Maybe<Scalars['String']['output']>;
  reference?: Maybe<WithdrawReferenceType>;
  sender?: Maybe<Scalars['String']['output']>;
  serviceAccount?: Maybe<Scalars['String']['output']>;
  serviceAccountHash?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  transactionId?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId: Scalars['Int']['output'];
  updatedAt?: Maybe<Scalars['String']['output']>;
  walletCard?: Maybe<WalletCardType>;
};
