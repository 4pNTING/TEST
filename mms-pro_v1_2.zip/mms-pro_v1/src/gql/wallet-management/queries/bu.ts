import { gql } from '@apollo/client';

export const createBUWalletCommand = gql(`
  mutation CreateBUWallet($input: CreateBUWalletDto!) {
  createBUWallet(input: $input) {
    wallet {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      queue
      walletCategoryId
      ownerId
      amount
      reference {
        group
        referenceHash
      }
      hash
      walletCategory {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        walletCategoryRoleId
        name
      }
        walletProfileInfo {
        firstName
        lastName
      }
    }
  }
}  
`);

export const loadWalletCategoryBUCommand = gql(`
query LoadWalletCategoryBU($input: LoadWalletCategoryBUDto!) {
  loadWalletCategoryBU(input: $input) {
    walletCategory {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      walletCategoryRoleId
      name
    }
    count
  }
}`);
export const loadWalletBUCommand = gql(`
query LoadWalletBU($input: LoadWalletBUDto!) {
  loadWalletBU(input: $input) {
    wallet {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      queue
      walletCategoryId
      ownerId
      amount
      reference {
        group
        referenceHash
      }
      hash
      walletCategory {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        walletCategoryRoleId
        name
      }
      walletProfileInfo {
        firstName
        lastName
      }
    }
    count
  }
}
`);
