import { gql } from '@apollo/client';

export const loadWalletCardCommand = gql(`
query LoadWalletCard($input: LoadWalletCardDto!) {
  loadWalletCard(input: $input) {
    walletCard {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      queue
      walletId
      cardName
      cardNo
      amount
      reference {
        cardType
        paymentMethod
        referenceHash
      }
      status
      hash
      walletCardActivity {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        queue
        walletId
        cardNo
        amount
        reference {
          cardType
          paymentMethod
          referenceHash
        }
        status
        hash
        log {
          tag
          lostBy
          lostTime
          lostHash
          inuseBy
          inuseTime
          inuseHash
        }
      }
            walletCardAssignment {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        walletId
        staffId
        attach
      }
    }
    count
  }
}
`);

export const createWalletCardCommand = gql(`
    mutation CreateWalletCard($input: CreateWalletCardDto!) {
  createWalletCard(input: $input) {
    walletCard {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      queue
      walletId
      cardName
      cardNo
      amount
      reference {
        cardType
        paymentMethod
        referenceHash
      }
      status
      hash
      walletCardActivity {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        queue
        walletId
        cardNo
        amount
        reference {
          cardType
          paymentMethod
          referenceHash
        }
        status
        hash
        log {
          tag
          lostBy
          lostTime
          lostHash
          inuseBy
          inuseTime
          inuseHash
        }
        cardName
      }
      walletCardAssignment {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        walletId
        staffId
        attach
      }
    }
  }
}
    `);

export const updateWalletCardCommand = gql(`
    mutation UpdateWalletCard($input: UpdateWalletCardDto!) {
  updateWalletCard(input: $input) {
    walletCard {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      queue
      walletId
      cardName
      cardNo
      amount
      reference {
        cardType
        paymentMethod
        referenceHash
      }
      status
      hash
      walletCardActivity {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        queue
        walletId
        cardNo
        amount
        reference {
          cardType
          paymentMethod
          referenceHash
        }
        status
        hash
        log {
          tag
          lostBy
          lostTime
          lostHash
          inuseBy
          inuseTime
          inuseHash
        }
        cardName
      }
      walletCardAssignment {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        walletId
        staffId
        attach
      }
    }
  }
}
    `);

export const restoreDeleteWalletCardCommand = gql(`
mutation RestoreDeleteWalletCard($input: RestoreDeleteWalletCardDto!) {
  restoreDeleteWalletCard(input: $input) {
    walletCard {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      queue
      walletId
      cardName
      cardNo
      amount
      reference {
        cardType
        paymentMethod
        referenceHash
      }
      status
      hash
      walletCardActivity {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        queue
        walletId
        cardNo
        amount
        reference {
          cardType
          paymentMethod
          referenceHash
        }
        status
        hash
        log {
          tag
          lostBy
          lostTime
          lostHash
          inuseBy
          inuseTime
          inuseHash
        }
        cardName
      }
      walletCardAssignment {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        walletId
        staffId
        attach
      }
    }
  }
}
    `);

export const deleteWalletCardCommand = gql(`
mutation DeleteWalletCard($input: DeleteWalletCardDto!) {
  deleteWalletCard(input: $input) {
    walletCard {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      queue
      walletId
      cardName
      cardNo
      amount
      reference {
        cardType
        paymentMethod
        referenceHash
      }
      status
      hash
      walletCardActivity {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        queue
        walletId
        cardNo
        amount
        reference {
          cardType
          paymentMethod
          referenceHash
        }
        status
        hash
        log {
          tag
          lostBy
          lostTime
          lostHash
          inuseBy
          inuseTime
          inuseHash
        }
        cardName
      }
      walletCardAssignment {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        walletId
        staffId
        attach
      }
    }
  }
}
    `);

export const updateWalletCardToInUseCommand = gql(`
mutation UpdateWalletCardToInUse($input: UpdateWalletCardToInUseDto!) {
  updateWalletCardToInUse(input: $input) {
    walletCard {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      queue
      walletId
      cardName
      cardNo
      amount
      reference {
        cardType
        paymentMethod
        referenceHash
      }
      status
      hash
      walletCardActivity {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        queue
        walletId
        cardNo
        amount
        reference {
          cardType
          paymentMethod
          referenceHash
        }
        status
        hash
        log {
          tag
          lostBy
          lostTime
          lostHash
          inuseBy
          inuseTime
          inuseHash
        }
        cardName
      }
      walletCardAssignment {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        walletId
        staffId
        attach
      }
    }
  }
}
    `);
