import { gql } from '@apollo/client';

export const loadIssuedCommand = gql(`
    query LoadIssued($input: LoadIssuedDto!) {
  loadIssued(input: $input) {
    issued {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      transactionId
      reference {
        issuedMethod
        qrInfo {
          transactionId
        }
      }
      amount
      description
      status
      requestor
      requestorHash
      acceptor
      acceptorHash
      hash
    }
    count
  }
}
`);
export const createIssuedCommand = gql(`
mutation CreateIssued($input: CreateIssuedDto!) {
  createIssued(input: $input) {
    issued {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      transactionId
      reference {
        issuedMethod
        qrInfo {
          transactionId
        }
      }
      amount
      description
      status
      requestor
      requestorHash
      acceptor
      acceptorHash
      hash
    }
  }
}    
`);
export const updateIssuedCommand = gql(`
mutation UpdateIssued($input: UpdateIssuedDto!) {
  updateIssued(input: $input) {
    issued {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      transactionId
      reference {
        issuedMethod
        qrInfo {
          transactionId
        }
      }
      amount
      description
      status
      requestor
      requestorHash
      acceptor
      acceptorHash
      hash
    }
  }
}  
`);
export const deleteIssuedCommand = gql(`
mutation DeleteIssued($input: DeleteIssuedDto!) {
  deleteIssued(input: $input) {
    issued {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      transactionId
      reference {
        issuedMethod
        qrInfo {
          transactionId
        }
      }
      amount
      description
      status
      requestor
      requestorHash
      acceptor
      acceptorHash
      hash
    }
  }
}  
`);
export const restoreDeleteIssuedCommand = gql(`
mutation RestoreDeleteIssued($input: RestoreDeleteIssuedDto!) {
  restoreDeleteIssued(input: $input) {
    issued {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      transactionId
      reference {
        issuedMethod
        qrInfo {
          transactionId
        }
      }
      amount
      description
      status
      requestor
      requestorHash
      acceptor
      acceptorHash
      hash
    }
  }
}  
`);
export const deniedIssuedCommand = gql(`
mutation DeniedIssued($input: DeniedIssuedDto!) {
  deniedIssued(input: $input) {
    issued {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      transactionId
      reference {
        issuedMethod
        qrInfo {
          transactionId
        }
      }
      amount
      description
      status
      requestor
      requestorHash
      acceptor
      acceptorHash
      hash
    }
  }
}    
`);
export const confirmCreateIssuedCommand = gql(`
mutation ConfirmCreateIssued($input: ConfirmCreateIssuedDto!) {
  confirmCreateIssued(input: $input) {
    amount
    description
    tag
    createdAt
    statementType {
      transaction
    }
      issued {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      transactionId
      reference {
        issuedMethod
        qrInfo {
          transactionId
        }
      }
      amount
      description
      status
      requestor
      requestorHash
      acceptor
      acceptorHash
      hash
    }
  }
}    
`);
