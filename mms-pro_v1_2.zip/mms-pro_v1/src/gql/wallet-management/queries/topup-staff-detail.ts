import { gql } from '@apollo/client';

export const loadWalletCardByTopupBatchIdCommand = gql(`
query LoadWalletCardByTopupBatchId($input: LoadWalletCardByTopupBatchIdDto!) {
  loadWalletCardByTopupBatchId(input: $input) {
    walletCard {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      queue
      walletId
      cardName
      cardNo
      amount
      reference {
        cardType
        paymentMethod
        referenceHash
      }
      status
      hash
      walletCardActivity {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        queue
        walletId
        cardNo
        amount
        reference {
          cardType
          paymentMethod
          referenceHash
        }
        status
        hash
        log {
          tag
          lostBy
          lostTime
          lostHash
          inuseBy
          inuseTime
          inuseHash
        }
      }
            walletCardAssignment {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        walletId
        staffId
        attach
      }
    }
    count
  }
}
`);

export const loadWalletByServiceCommand = gql(`
   query LoadWalletByService($input: LoadWalletByServiceDto!) {
  loadWalletByService(input: $input) {
    wallet {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      queue
      walletCategoryId
      ownerId
      amount
      reference {
        group
        referenceHash
      }
      hash
      walletCategory {
        _id
        uniqueId
        uid
        isActive
        createdAt
        updatedAt
        walletCategoryRoleId
        name
      }
      walletProfileInfo {
        firstName
        lastName
      }
    }
    count
  }
}
`);

export const loadTopupBatchDetailByIdCommand = gql(`
   query LoadTopupBatchDetailById($input: LoadTopupBatchDetailByIdDto!) {
  loadTopupBatchDetailById(input: $input) {
    topupBatch {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      target
      transactionId
      walletId
      amount
      description
      status
      reference {
        createdBy {
          ownerId
          datetime
          signed
        }
        confirmBy {
          ownerId
          datetime
          signed
        }
        deniedBy {
          ownerId
          datetime
          signed
        }
      }
      group
      hash
    }
    topupBatchDetail {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      groupName
      topupBatchId
      walletId
      ownerId
      reference {
        paymentMethod
      }
      amount
      status
      hash
      cardNo
      cardType
    }
    count
  }
}
`);

export const createCardTopupBatchDetailCommand = gql(`
mutation CreateCardTopupBatchDetail($input: CreateCardTopupBatchDetailDto!) {
  createCardTopupBatchDetail(input: $input) {
    topupBatch {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      target
      transactionId
      walletId
      amount
      description
      status
      reference {
        createdBy {
          ownerId
          datetime
          signed
        }
        confirmBy {
          ownerId
          datetime
          signed
        }
        deniedBy {
          ownerId
          datetime
          signed
        }
      }
      group
      hash
    }
    topupBatchDetail {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      groupName
      topupBatchId
      walletId
      ownerId
      reference {
        paymentMethod
      }
      amount
      status
      hash
      cardNo
      cardType
    }
  }
}  
`);

export const deleteCardTopupBatchDetailCommand = gql(`
mutation DeleteCardTopupBatchDetail($input: DeleteCardTopupBatchDetailDto!) {
  deleteCardTopupBatchDetail(input: $input) {
    topupBatch {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      target
      transactionId
      walletId
      amount
      description
      status
      reference {
        createdBy {
          ownerId
          datetime
          signed
        }
        confirmBy {
          ownerId
          datetime
          signed
        }
        deniedBy {
          ownerId
          datetime
          signed
        }
      }
      group
      hash
    }
    topupBatchDetail {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      groupName
      topupBatchId
      walletId
      ownerId
      reference {
        paymentMethod
      }
      amount
      status
      hash
      cardNo
      cardType
    }
  }
}  
`);
