import { gql } from '@apollo/client';

export const loadTopupBatchCommand = gql(`
    query LoadTopupBatch($input: LoadTopupBatchDto!) {
  loadTopupBatch(input: $input) {
    topupBatch {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      target
      transactionId
      walletId
      amount
      description
      status
      reference {
        createdBy {
          ownerId
          datetime
          signed
        }
        confirmBy {
          ownerId
          datetime
          signed
        }
        deniedBy {
          ownerId
          datetime
          signed
        }
      }
      group
      hash
    }
    count
  }
}
`);
export const createTopupBatchCommand = gql(`
    mutation CreateTopupBatch($input: CreateTopupBatchDto!) {
  createTopupBatch(input: $input) {
    topupBatch {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      target
      transactionId
      walletId
      amount
      description
      status
      reference {
        createdBy {
          ownerId
          datetime
          signed
        }
        confirmBy {
          ownerId
          datetime
          signed
        }
        deniedBy {
          ownerId
          datetime
          signed
        }
      }
      group
      hash
    }
  }
}
`);
export const updateTopupBatchCommand = gql(`
    mutation UpdateTopupBatch($input: UpdateTopupBatchDto!) {
  updateTopupBatch(input: $input) {
    topupBatch {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      target
      transactionId
      walletId
      amount
      description
      status
      reference {
        createdBy {
          ownerId
          datetime
          signed
        }
        confirmBy {
          ownerId
          datetime
          signed
        }
        deniedBy {
          ownerId
          datetime
          signed
        }
      }
      group
      hash
    }
  }
}
`);
export const deleteTopupBatchCommand = gql(`
     mutation DeleteTopupBatch($input: DeleteTopupBatchDto!) {
  deleteTopupBatch(input: $input) {
    topupBatch {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      target
      transactionId
      walletId
      amount
      description
      status
      reference {
        createdBy {
          ownerId
          datetime
          signed
        }
        confirmBy {
          ownerId
          datetime
          signed
        }
        deniedBy {
          ownerId
          datetime
          signed
        }
      }
      group
      hash
    }
  }
}
`);
export const restoreDeleteTopupBatchCommand = gql(`
    mutation RestoreDeleteTopupBatch($input: RestoreDeleteTopupBatchDto!) {
  restoreDeleteTopupBatch(input: $input) {
    topupBatch {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      target
      transactionId
      walletId
      amount
      description
      status
      reference {
        createdBy {
          ownerId
          datetime
          signed
        }
        confirmBy {
          ownerId
          datetime
          signed
        }
        deniedBy {
          ownerId
          datetime
          signed
        }
      }
      group
      hash
    }
  }
}
`);
export const deniedCreateTopupBatchCommand = gql(`
        mutation DeniedCreateTopupBatch($input: DeniedCreateTopupBatchDto!) {
  deniedCreateTopupBatch(input: $input) {
    topupBatch {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      target
      transactionId
      walletId
      amount
      description
      status
      reference {
        createdBy {
          ownerId
          datetime
          signed
        }
        confirmBy {
          ownerId
          datetime
          signed
        }
        deniedBy {
          ownerId
          datetime
          signed
        }
      }
      group
      hash
    }
  }
}
`);
export const confirmCreateTopupBatchCommand = gql(`
    mutation ConfirmCreateTopupBatch($input: ConfirmCreateTopupBatchDto!) {
  confirmCreateTopupBatch(input: $input) {
    topupBatch {
      _id
      uniqueId
      uid
      isActive
      createdAt
      updatedAt
      target
      transactionId
      walletId
      amount
      description
      status
      reference {
        createdBy {
          ownerId
          datetime
          signed
        }
        confirmBy {
          ownerId
          datetime
          signed
        }
        deniedBy {
          ownerId
          datetime
          signed
        }
      }
      group
      hash
    }
  }
}
`);
