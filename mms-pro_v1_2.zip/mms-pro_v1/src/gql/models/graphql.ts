/* eslint-disable */
import { TypedDocumentNode as DocumentNode } from '@graphql-typed-document-node/core';
export type Maybe<T> = T | null;
export type InputMaybe<T> = Maybe<T>;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
export type MakeEmpty<T extends { [key: string]: unknown }, K extends keyof T> = { [_ in K]?: never };
export type Incremental<T> = T | { [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: { input: string; output: string; }
  String: { input: string; output: string; }
  Boolean: { input: boolean; output: boolean; }
  Int: { input: number; output: number; }
  Float: { input: number; output: number; }
};

export type AddAccessToUserBuByAdminDto = {
  serviceAccountId?: InputMaybe<Scalars['String']['input']>;
  userId?: InputMaybe<Scalars['String']['input']>;
};

export type AddAccessToUserBuByAdminDtoResponse = {
  __typename?: 'AddAccessToUserBUByAdminDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type AdminConfigType = {
  __typename?: 'AdminConfigType';
  assignBy?: Maybe<Scalars['String']['output']>;
  assignDate?: Maybe<Scalars['String']['output']>;
  assignId?: Maybe<Scalars['String']['output']>;
  level?: Maybe<Scalars['String']['output']>;
};

export type AdminInfoType = {
  __typename?: 'AdminInfoType';
  _id?: Maybe<Scalars['String']['output']>;
  config?: Maybe<AdminConfigType>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  password?: Maybe<Scalars['String']['output']>;
  phoneNumber?: Maybe<Scalars['String']['output']>;
  platform?: Maybe<Scalars['String']['output']>;
  prefix?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  username?: Maybe<Scalars['String']['output']>;
};

export type AdminProfileImageInput = {
  cover?: InputMaybe<Scalars['String']['input']>;
  profile?: InputMaybe<Scalars['String']['input']>;
};

export type AdminProfileImageType = {
  __typename?: 'AdminProfileImageType';
  cover?: Maybe<Scalars['String']['output']>;
  profile?: Maybe<Scalars['String']['output']>;
};

export type AdminProfileType = {
  __typename?: 'AdminProfileType';
  _id?: Maybe<Scalars['String']['output']>;
  address?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  district?: Maybe<Scalars['String']['output']>;
  firstName?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  image?: Maybe<AdminProfileImageType>;
  isActive?: Maybe<Scalars['String']['output']>;
  lastName?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  postcode?: Maybe<Scalars['String']['output']>;
  province?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  village?: Maybe<Scalars['String']['output']>;
};

export type AdminSignatureType = {
  __typename?: 'AdminSignatureType';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  privateKey?: Maybe<Scalars['String']['output']>;
  publicKey?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type AdminSigninDto = {
  password: Scalars['String']['input'];
  username: Scalars['String']['input'];
};

export type AdminSigninDtoResponse = {
  __typename?: 'AdminSigninDtoResponse';
  authorization: Scalars['String']['output'];
};

export type AdminSignupDto = {
  firstName: Scalars['String']['input'];
  lastName: Scalars['String']['input'];
  password: Scalars['String']['input'];
  super?: InputMaybe<Scalars['String']['input']>;
  username: Scalars['String']['input'];
};

export type AdminSignupDtoResponse = {
  __typename?: 'AdminSignupDtoResponse';
  admin?: Maybe<AdminType>;
};

export type AdminType = {
  __typename?: 'AdminType';
  admin?: Maybe<AdminInfoType>;
  adminProfile?: Maybe<AdminProfileType>;
  adminSignature?: Maybe<AdminSignatureType>;
};

export type AdminValidateTokenDtoResponse = {
  __typename?: 'AdminValidateTokenDtoResponse';
  admin?: Maybe<AdminType>;
};

export type AuthorizationDtoResponse = {
  __typename?: 'AuthorizationDtoResponse';
  _id?: Maybe<Scalars['String']['output']>;
  employee?: Maybe<EmployeeType>;
};

export type ChangeServiceAccountPasswordDto = {
  newPassword: Scalars['String']['input'];
  prePassword: Scalars['String']['input'];
};

export type ChangeServiceAccountPasswordResponseDto = {
  __typename?: 'ChangeServiceAccountPasswordResponseDto';
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ChangeServiceAccountUsernameByAdminDto = {
  newUsername: Scalars['String']['input'];
  serviceAccountId: Scalars['String']['input'];
};

export type ChangeServiceAccountUsernameByAdminDtoResponse = {
  __typename?: 'ChangeServiceAccountUsernameByAdminDtoResponse';
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ChangeServiceAccountUsernameDto = {
  newUsername: Scalars['String']['input'];
  password: Scalars['String']['input'];
  preUsername: Scalars['String']['input'];
};

export type ChangeServiceAccountUsernameDtoResponse = {
  __typename?: 'ChangeServiceAccountUsernameDtoResponse';
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type CheckExistUserByUsernameDto = {
  username?: InputMaybe<Scalars['String']['input']>;
};

export type CheckExistUserByUsernameDtoResponse = {
  __typename?: 'CheckExistUserByUsernameDtoResponse';
  user?: Maybe<UserType>;
};

export type CompanyType = {
  __typename?: 'CompanyType';
  _id?: Maybe<Scalars['String']['output']>;
  companyCode?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  enName?: Maybe<Scalars['String']['output']>;
  laName?: Maybe<Scalars['String']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ConditionInput = {
  field?: InputMaybe<Scalars['String']['input']>;
  value?: InputMaybe<Scalars['String']['input']>;
};

export type ConfirmCreateUserOtpDto = {
  otp: Scalars['String']['input'];
  phoneNumber: Scalars['String']['input'];
};

export type ConfirmCreateUserOtpDtoResponse = {
  __typename?: 'ConfirmCreateUserOTPDtoResponse';
  authorization?: Maybe<Scalars['String']['output']>;
  key?: Maybe<Scalars['String']['output']>;
};

export type CreateAreaOwnershipAgentInput = {
  endedAt?: InputMaybe<Scalars['String']['input']>;
  fileUrl?: InputMaybe<Scalars['String']['input']>;
  note?: InputMaybe<Scalars['String']['input']>;
  startedAt?: InputMaybe<Scalars['String']['input']>;
};

export type CreateAreaOwnershipInput = {
  address?: InputMaybe<Scalars['String']['input']>;
  fileUrl?: InputMaybe<Scalars['String']['input']>;
  firstName?: InputMaybe<Scalars['String']['input']>;
  lastName?: InputMaybe<Scalars['String']['input']>;
  phoneNumber?: InputMaybe<Scalars['String']['input']>;
};

export type CreateCustomerDto = {
  address?: InputMaybe<Scalars['String']['input']>;
  contact?: InputMaybe<CustomerContactInput>;
  customId?: InputMaybe<Scalars['String']['input']>;
  district?: InputMaybe<Scalars['String']['input']>;
  fileUrl?: InputMaybe<Scalars['String']['input']>;
  firstName?: InputMaybe<Scalars['String']['input']>;
  gender?: InputMaybe<Scalars['String']['input']>;
  lastName?: InputMaybe<Scalars['String']['input']>;
  nationality?: InputMaybe<Scalars['String']['input']>;
  phoneNumber?: InputMaybe<Scalars['String']['input']>;
  province?: InputMaybe<Scalars['String']['input']>;
  village?: InputMaybe<Scalars['String']['input']>;
};

export type CreateCustomerDtoResponse = {
  __typename?: 'CreateCustomerDtoResponse';
  customer?: Maybe<CustomerType>;
};

export type CreateElectricDto = {
  amount?: InputMaybe<Scalars['Int']['input']>;
};

export type CreateElectricDtoResponse = {
  __typename?: 'CreateElectricDtoResponse';
  electric?: Maybe<Array<ElectricType>>;
};

export type CreateFixedAmountDto = {
  amount?: InputMaybe<Scalars['Float']['input']>;
  method?: InputMaybe<Scalars['String']['input']>;
};

export type CreateFixedAmountDtoResponse = {
  __typename?: 'CreateFixedAmountDtoResponse';
  fixedAmount?: Maybe<FixedAmountType>;
};

export type CreateLeasingBatchElectricDetailDto = {
  items?: InputMaybe<Array<InputMaybe<CreateLeasingBatchElectricDetailItemDto>>>;
  leasingBatchElectricId?: InputMaybe<Scalars['String']['input']>;
};

export type CreateLeasingBatchElectricDetailDtoResponse = {
  __typename?: 'CreateLeasingBatchElectricDetailDtoResponse';
  leasingBatchElectricDetail?: Maybe<Array<Maybe<LeasingBatchElectricDetailType>>>;
};

export type CreateLeasingBatchElectricDetailItemDto = {
  amount?: InputMaybe<Scalars['Float']['input']>;
  currency?: InputMaybe<Scalars['String']['input']>;
  electricityConversionFee?: InputMaybe<Scalars['Float']['input']>;
  fixedAmountId?: InputMaybe<Scalars['String']['input']>;
  lastNumber?: InputMaybe<Scalars['Float']['input']>;
  leasingElectricId?: InputMaybe<Scalars['String']['input']>;
  leasingIndexId?: InputMaybe<Scalars['String']['input']>;
};

export type CreateLeasingBatchElectricDto = {
  name?: InputMaybe<Scalars['String']['input']>;
  note?: InputMaybe<Scalars['String']['input']>;
};

export type CreateLeasingBatchElectricDtoResponse = {
  __typename?: 'CreateLeasingBatchElectricDtoResponse';
  leasingBatchElectric?: Maybe<LeasingBatchElectricType>;
};

export type CreateLeasingBatchWaterDetailDto = {
  items?: InputMaybe<Array<InputMaybe<CreateLeasingBatchWaterDetailItemDto>>>;
  leasingBatchWaterId?: InputMaybe<Scalars['String']['input']>;
};

export type CreateLeasingBatchWaterDetailDtoResponse = {
  __typename?: 'CreateLeasingBatchWaterDetailDtoResponse';
  leasingBatchWaterDetail?: Maybe<Array<Maybe<LeasingBatchWaterDetailType>>>;
};

export type CreateLeasingBatchWaterDetailItemDto = {
  amount?: InputMaybe<Scalars['Float']['input']>;
  currency?: InputMaybe<Scalars['String']['input']>;
  fixedAmountId?: InputMaybe<Scalars['String']['input']>;
  lastNumber?: InputMaybe<Scalars['Float']['input']>;
  leasingIndexId?: InputMaybe<Scalars['String']['input']>;
  leasingWaterId?: InputMaybe<Scalars['String']['input']>;
  maintenanceAmount?: InputMaybe<Scalars['Float']['input']>;
  maintenanceFixedAmountId?: InputMaybe<Scalars['String']['input']>;
};

export type CreateLeasingBatchWaterDto = {
  name?: InputMaybe<Scalars['String']['input']>;
  note?: InputMaybe<Scalars['String']['input']>;
};

export type CreateLeasingBatchWaterDtoResponse = {
  __typename?: 'CreateLeasingBatchWaterDtoResponse';
  leasingBatchWater?: Maybe<LeasingBatchWaterType>;
};

export type CreateLeasingEwInvoiceDto = {
  name?: InputMaybe<Scalars['String']['input']>;
};

export type CreateLeasingEwInvoiceDtoResponse = {
  __typename?: 'CreateLeasingEWInvoiceDtoResponse';
  leasingEWInvoice?: Maybe<Array<Maybe<LeasingEwInvoiceType>>>;
};

export type CreateLeasingElectricDto = {
  electricId?: InputMaybe<Scalars['String']['input']>;
  electricityConversionFee?: InputMaybe<Scalars['Float']['input']>;
  fixedAmountId?: InputMaybe<Scalars['String']['input']>;
  lastNumber?: InputMaybe<Scalars['Int']['input']>;
  leasingIndexId?: InputMaybe<Scalars['String']['input']>;
};

export type CreateLeasingElectricDtoResponse = {
  __typename?: 'CreateLeasingElectricDtoResponse';
  leasingElectric?: Maybe<LeasingElectricType>;
};

export type CreateLeasingIndexDto = {
  contractCategory?: InputMaybe<Scalars['String']['input']>;
  contractNo?: InputMaybe<Scalars['String']['input']>;
  customerId?: InputMaybe<Scalars['String']['input']>;
  endedAt?: InputMaybe<Scalars['String']['input']>;
  endedPayAt?: InputMaybe<Scalars['String']['input']>;
  fileUrl?: InputMaybe<Scalars['String']['input']>;
  installment?: InputMaybe<Array<InputMaybe<CreateLeasingInstallmentInput>>>;
  order?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  paymentMethod?: InputMaybe<Scalars['String']['input']>;
  shopCategoryId?: InputMaybe<Scalars['String']['input']>;
  shopName?: InputMaybe<Scalars['String']['input']>;
  startedAt?: InputMaybe<Scalars['String']['input']>;
  sum?: InputMaybe<CreateLeasingSumDto>;
};

export type CreateLeasingIndexDtoResponse = {
  __typename?: 'CreateLeasingIndexDtoResponse';
  leasingIndex?: Maybe<LeasingIndexType>;
};

export type CreateLeasingInstallmentInput = {
  _id?: InputMaybe<Scalars['String']['input']>;
  amount?: InputMaybe<Scalars['Float']['input']>;
  currency?: InputMaybe<Scalars['String']['input']>;
  name?: InputMaybe<Scalars['String']['input']>;
  paidAt?: InputMaybe<Scalars['String']['input']>;
};

export type CreateLeasingSumDto = {
  amount?: InputMaybe<Scalars['Float']['input']>;
  centralAmount?: InputMaybe<Scalars['Float']['input']>;
  depositAmount?: InputMaybe<Scalars['Float']['input']>;
  depositCurrency?: InputMaybe<Scalars['String']['input']>;
  discountAmount?: InputMaybe<Scalars['Float']['input']>;
  discountCentralAmount?: InputMaybe<Scalars['Float']['input']>;
  sumAmount?: InputMaybe<Scalars['Float']['input']>;
};

export type CreateLeasingWaterDto = {
  fixedAmountId?: InputMaybe<Scalars['String']['input']>;
  lastNumber?: InputMaybe<Scalars['Float']['input']>;
  leasingIndexId?: InputMaybe<Scalars['String']['input']>;
  maintenanceFixedAmountId?: InputMaybe<Scalars['String']['input']>;
  waterId?: InputMaybe<Scalars['String']['input']>;
};

export type CreateLeasingWaterDtoResponse = {
  __typename?: 'CreateLeasingWaterDtoResponse';
  leasingWater?: Maybe<LeasingWaterType>;
};

export type CreateMmsUserDto = {
  buId?: InputMaybe<Scalars['String']['input']>;
  empId?: InputMaybe<Scalars['String']['input']>;
  permission?: InputMaybe<Array<InputMaybe<UserPermissionInputType>>>;
  roleName?: InputMaybe<Scalars['String']['input']>;
};

export type CreateMmsUserDtoResponse = {
  __typename?: 'CreateMMSUserDtoResponse';
  user?: Maybe<MmsUserType>;
};

export type CreateRoomAreaCategoryDto = {
  name?: InputMaybe<Scalars['String']['input']>;
};

export type CreateRoomAreaCategoryDtoResponse = {
  __typename?: 'CreateRoomAreaCategoryDtoResponse';
  roomAreaCategory?: Maybe<RoomAreaCategoryType>;
};

export type CreateRoomAreaDto = {
  agentHoldStatus?: InputMaybe<Scalars['String']['input']>;
  agentObject?: InputMaybe<CreateAreaOwnershipAgentInput>;
  amount?: InputMaybe<Scalars['Float']['input']>;
  buyerObject?: InputMaybe<CreateAreaOwnershipInput>;
  centralAmount?: InputMaybe<Scalars['Float']['input']>;
  currency?: InputMaybe<Scalars['String']['input']>;
  holdStatus?: InputMaybe<Scalars['String']['input']>;
  long?: InputMaybe<Scalars['Float']['input']>;
  moreArea?: InputMaybe<Scalars['Float']['input']>;
  name?: InputMaybe<Scalars['String']['input']>;
  roomAreaCategoryId?: InputMaybe<Scalars['String']['input']>;
  totalAmount?: InputMaybe<Scalars['Float']['input']>;
  totalArea?: InputMaybe<Scalars['Float']['input']>;
  totalAreaAmount?: InputMaybe<Scalars['Float']['input']>;
  totalAreaCentralAmount?: InputMaybe<Scalars['Float']['input']>;
  wide?: InputMaybe<Scalars['Float']['input']>;
  zoneId?: InputMaybe<Scalars['String']['input']>;
};

export type CreateRoomAreaDtoResponse = {
  __typename?: 'CreateRoomAreaDtoResponse';
  roomArea?: Maybe<RoomAreaType>;
};

export type CreateShopCategoryDto = {
  name?: InputMaybe<Scalars['String']['input']>;
};

export type CreateShopCategoryDtoResponse = {
  __typename?: 'CreateShopCategoryDtoResponse';
  shopCategory?: Maybe<ShopCategoryType>;
};

export type CreateUserOtpDto = {
  expiredAt: Scalars['Int']['input'];
  otp: Scalars['String']['input'];
  phoneNumber: Scalars['String']['input'];
};

export type CreateUserOtpDtoResponse = {
  __typename?: 'CreateUserOTPDtoResponse';
  isComplete?: Maybe<Scalars['Boolean']['output']>;
};

export type CreateWaterDto = {
  amount?: InputMaybe<Scalars['Int']['input']>;
};

export type CreateWaterDtoResponse = {
  __typename?: 'CreateWaterDtoResponse';
  water?: Maybe<Array<WaterType>>;
};

export type CreateZoneDto = {
  name?: InputMaybe<Scalars['String']['input']>;
};

export type CreateZoneDtoResponse = {
  __typename?: 'CreateZoneDtoResponse';
  zone?: Maybe<ZoneType>;
};

export type CustomerContactInput = {
  address?: InputMaybe<Scalars['String']['input']>;
  district?: InputMaybe<Scalars['String']['input']>;
  firstName?: InputMaybe<Scalars['String']['input']>;
  lastName?: InputMaybe<Scalars['String']['input']>;
  phoneNumber?: InputMaybe<Scalars['String']['input']>;
  province?: InputMaybe<Scalars['String']['input']>;
  village?: InputMaybe<Scalars['String']['input']>;
};

export type CustomerContactType = {
  __typename?: 'CustomerContactType';
  address?: Maybe<Scalars['String']['output']>;
  district?: Maybe<Scalars['String']['output']>;
  firstName?: Maybe<Scalars['String']['output']>;
  lastName?: Maybe<Scalars['String']['output']>;
  phoneNumber?: Maybe<Scalars['String']['output']>;
  province?: Maybe<Scalars['String']['output']>;
  village?: Maybe<Scalars['String']['output']>;
};

export type CustomerType = {
  __typename?: 'CustomerType';
  _id?: Maybe<Scalars['String']['output']>;
  address?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  contact?: Maybe<CustomerContactType>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  customId?: Maybe<Scalars['String']['output']>;
  district?: Maybe<Scalars['String']['output']>;
  fileUrl?: Maybe<Scalars['String']['output']>;
  firstName?: Maybe<Scalars['String']['output']>;
  gender?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  lastName?: Maybe<Scalars['String']['output']>;
  nationality?: Maybe<Scalars['String']['output']>;
  phoneNumber?: Maybe<Scalars['String']['output']>;
  province?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
  village?: Maybe<Scalars['String']['output']>;
};

export type DateFilterInput = {
  endDate?: InputMaybe<Scalars['String']['input']>;
  startDate?: InputMaybe<Scalars['String']['input']>;
};

export type DeleteAdminDtoResponse = {
  __typename?: 'DeleteAdminDtoResponse';
  admin?: Maybe<AdminType>;
};

export type DeleteCustomerDto = {
  _id: Scalars['String']['input'];
};

export type DeleteCustomerDtoResponse = {
  __typename?: 'DeleteCustomerDtoResponse';
  customer?: Maybe<CustomerType>;
};

export type DeleteElectricDto = {
  _id: Scalars['String']['input'];
};

export type DeleteElectricDtoResponse = {
  __typename?: 'DeleteElectricDtoResponse';
  electric?: Maybe<ElectricType>;
};

export type DeleteFixedAmountDto = {
  _id: Scalars['String']['input'];
};

export type DeleteFixedAmountDtoResponse = {
  __typename?: 'DeleteFixedAmountDtoResponse';
  fixedAmount?: Maybe<FixedAmountType>;
};

export type DeleteLeasingBatchElectricDetailDto = {
  items?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  leasingBatchElectricId?: InputMaybe<Scalars['String']['input']>;
};

export type DeleteLeasingBatchElectricDetailDtoResponse = {
  __typename?: 'DeleteLeasingBatchElectricDetailDtoResponse';
  leasingBatchElectricDetail?: Maybe<Array<Maybe<LeasingBatchElectricDetailType>>>;
};

export type DeleteLeasingBatchElectricDto = {
  _id: Scalars['String']['input'];
};

export type DeleteLeasingBatchElectricDtoResponse = {
  __typename?: 'DeleteLeasingBatchElectricDtoResponse';
  leasingBatchElectric?: Maybe<LeasingBatchElectricType>;
};

export type DeleteLeasingBatchWaterDetailDto = {
  items?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  leasingBatchWaterId?: InputMaybe<Scalars['String']['input']>;
};

export type DeleteLeasingBatchWaterDetailDtoResponse = {
  __typename?: 'DeleteLeasingBatchWaterDetailDtoResponse';
  leasingBatchWaterDetail?: Maybe<Array<Maybe<LeasingBatchWaterDetailType>>>;
};

export type DeleteLeasingBatchWaterDto = {
  _id: Scalars['String']['input'];
};

export type DeleteLeasingBatchWaterDtoResponse = {
  __typename?: 'DeleteLeasingBatchWaterDtoResponse';
  leasingBatchWater?: Maybe<LeasingBatchWaterType>;
};

export type DeleteLeasingElectricDto = {
  _id: Scalars['String']['input'];
};

export type DeleteLeasingElectricDtoResponse = {
  __typename?: 'DeleteLeasingElectricDtoResponse';
  leasingElectric?: Maybe<LeasingElectricType>;
};

export type DeleteLeasingIndexDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
  note?: InputMaybe<Scalars['String']['input']>;
};

export type DeleteLeasingIndexDtoResponse = {
  __typename?: 'DeleteLeasingIndexDtoResponse';
  leasingIndex?: Maybe<LeasingIndexType>;
};

export type DeleteLeasingWaterDto = {
  _id: Scalars['String']['input'];
};

export type DeleteLeasingWaterDtoResponse = {
  __typename?: 'DeleteLeasingWaterDtoResponse';
  leasingWater?: Maybe<LeasingWaterType>;
};

export type DeleteMmsUserDto = {
  _id: Scalars['String']['input'];
};

export type DeleteMmsUserDtoResponse = {
  __typename?: 'DeleteMMSUserDtoResponse';
  user?: Maybe<MmsUserType>;
};

export type DeleteRoomAreaCategoryDto = {
  _id: Scalars['String']['input'];
};

export type DeleteRoomAreaCategoryDtoResponse = {
  __typename?: 'DeleteRoomAreaCategoryDtoResponse';
  roomAreaCategory?: Maybe<RoomAreaCategoryType>;
};

export type DeleteRoomAreaDto = {
  _id: Scalars['String']['input'];
};

export type DeleteRoomAreaDtoResponse = {
  __typename?: 'DeleteRoomAreaDtoResponse';
  roomArea?: Maybe<RoomAreaType>;
};

export type DeleteServiceAccountByAdminDto = {
  serviceAccountId?: InputMaybe<Scalars['String']['input']>;
};

export type DeleteServiceAccountDtoResponse = {
  __typename?: 'DeleteServiceAccountDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type DeleteShopCategoryDto = {
  _id: Scalars['String']['input'];
};

export type DeleteShopCategoryDtoResponse = {
  __typename?: 'DeleteShopCategoryDtoResponse';
  shopCategory?: Maybe<ShopCategoryType>;
};

export type DeleteUserByAdminDto = {
  userId: Scalars['String']['input'];
};

export type DeleteUserByAdminDtoResponse = {
  __typename?: 'DeleteUserByAdminDtoResponse';
  user?: Maybe<UserType>;
};

export type DeleteUserDtoResponse = {
  __typename?: 'DeleteUserDtoResponse';
  user?: Maybe<UserType>;
};

export type DeleteWaterDto = {
  _id: Scalars['String']['input'];
};

export type DeleteWaterDtoResponse = {
  __typename?: 'DeleteWaterDtoResponse';
  water?: Maybe<WaterType>;
};

export type DeleteZoneDto = {
  _id: Scalars['String']['input'];
};

export type DeleteZoneDtoResponse = {
  __typename?: 'DeleteZoneDtoResponse';
  zone?: Maybe<ZoneType>;
};

export type DepartmentType = {
  __typename?: 'DepartmentType';
  _id?: Maybe<Scalars['String']['output']>;
  companyId?: Maybe<CompanyType>;
  createdAt?: Maybe<Scalars['String']['output']>;
  depCode?: Maybe<Scalars['String']['output']>;
  enName?: Maybe<Scalars['String']['output']>;
  laName?: Maybe<Scalars['String']['output']>;
  levelId?: Maybe<LevelType>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ElectricType = {
  __typename?: 'ElectricType';
  _id?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type EmployeeType = {
  __typename?: 'EmployeeType';
  _id?: Maybe<Scalars['String']['output']>;
  companyId?: Maybe<CompanyType>;
  createdAt?: Maybe<Scalars['String']['output']>;
  depId?: Maybe<DepartmentType>;
  dob?: Maybe<Scalars['String']['output']>;
  email?: Maybe<Scalars['String']['output']>;
  empID?: Maybe<Scalars['String']['output']>;
  empNumber?: Maybe<Scalars['Int']['output']>;
  fNameEn?: Maybe<Scalars['String']['output']>;
  fNameLa?: Maybe<Scalars['String']['output']>;
  genderID?: Maybe<Scalars['String']['output']>;
  lNameEn?: Maybe<Scalars['String']['output']>;
  lNameLa?: Maybe<Scalars['String']['output']>;
  levelId?: Maybe<LevelType>;
  nickNameEn?: Maybe<Scalars['String']['output']>;
  nickNameLa?: Maybe<Scalars['String']['output']>;
  phone?: Maybe<Scalars['String']['output']>;
  positionId?: Maybe<PositionType>;
  roleId?: Maybe<Scalars['String']['output']>;
  sectorId?: Maybe<SectorType>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  userName?: Maybe<Scalars['String']['output']>;
  workingStart?: Maybe<Scalars['String']['output']>;
};

export type FixedAmountType = {
  __typename?: 'FixedAmountType';
  _id?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  method?: Maybe<Scalars['String']['output']>;
  selection?: Maybe<Scalars['Boolean']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type InNumberInput = {
  field?: InputMaybe<Scalars['String']['input']>;
  value?: InputMaybe<Array<Scalars['Int']['input']>>;
};

export type InStringInput = {
  field?: InputMaybe<Scalars['String']['input']>;
  value?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type LeasingBatchElectricDetailType = {
  __typename?: 'LeasingBatchElectricDetailType';
  _id?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  currency?: Maybe<Scalars['String']['output']>;
  currentNumber?: Maybe<Scalars['Float']['output']>;
  customer?: Maybe<CustomerType>;
  electric?: Maybe<ElectricType>;
  electricId?: Maybe<Scalars['String']['output']>;
  electricityConversionFee?: Maybe<Scalars['Float']['output']>;
  fixedAmount?: Maybe<FixedAmountType>;
  fixedAmountId?: Maybe<Scalars['String']['output']>;
  invoiceNo?: Maybe<Scalars['String']['output']>;
  invoiceReferenceId?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  lastNumber?: Maybe<Scalars['Float']['output']>;
  leasingBatchElectricId?: Maybe<Scalars['String']['output']>;
  leasingElectricId?: Maybe<Scalars['String']['output']>;
  leasingIndex?: Maybe<LeasingIndexType>;
  leasingIndexId?: Maybe<Scalars['String']['output']>;
  receiptNo?: Maybe<Scalars['String']['output']>;
  receiptReferenceId?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  sumAmount?: Maybe<Scalars['Float']['output']>;
  sumUnitAmount?: Maybe<Scalars['Float']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  unitAmount?: Maybe<Scalars['Float']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type LeasingBatchElectricReferenceType = {
  __typename?: 'LeasingBatchElectricReferenceType';
  _id?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  leasingBatchElectricDetail?: Maybe<LeasingBatchElectricDetailType>;
  status?: Maybe<Scalars['String']['output']>;
};

export type LeasingBatchElectricType = {
  __typename?: 'LeasingBatchElectricType';
  _id?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  invoiceStatus?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  note?: Maybe<Scalars['String']['output']>;
  receiptStatus?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type LeasingBatchWaterDetailType = {
  __typename?: 'LeasingBatchWaterDetailType';
  _id?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  currency?: Maybe<Scalars['String']['output']>;
  currentNumber?: Maybe<Scalars['Float']['output']>;
  customer?: Maybe<CustomerType>;
  fixedAmount?: Maybe<FixedAmountType>;
  fixedAmountId?: Maybe<Scalars['String']['output']>;
  invoiceNo?: Maybe<Scalars['String']['output']>;
  invoiceReferenceId?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  lastNumber?: Maybe<Scalars['Float']['output']>;
  leasingBatchWaterId?: Maybe<Scalars['String']['output']>;
  leasingIndex?: Maybe<LeasingIndexType>;
  leasingIndexId?: Maybe<Scalars['String']['output']>;
  leasingWaterId?: Maybe<Scalars['String']['output']>;
  maintenanceAmount?: Maybe<Scalars['Float']['output']>;
  maintenanceFixedAmount?: Maybe<FixedAmountType>;
  maintenanceFixedAmountId?: Maybe<Scalars['String']['output']>;
  receiptNo?: Maybe<Scalars['String']['output']>;
  receiptReferenceId?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  sumAmount?: Maybe<Scalars['Float']['output']>;
  sumUnitAmount?: Maybe<Scalars['Float']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  unitAmount?: Maybe<Scalars['Float']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
  water?: Maybe<WaterType>;
  waterId?: Maybe<Scalars['String']['output']>;
};

export type LeasingBatchWaterReferenceType = {
  __typename?: 'LeasingBatchWaterReferenceType';
  _id?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  leasingBatchWaterDetail?: Maybe<LeasingBatchWaterDetailType>;
  status?: Maybe<Scalars['String']['output']>;
};

export type LeasingBatchWaterType = {
  __typename?: 'LeasingBatchWaterType';
  _id?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  invoiceStatus?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  note?: Maybe<Scalars['String']['output']>;
  receiptStatus?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type LeasingDateTimeType = {
  __typename?: 'LeasingDateTimeType';
  _id?: Maybe<Scalars['String']['output']>;
  actionApproveUpdateLeasingActivedAt?: Maybe<Scalars['String']['output']>;
  actionApproveUpdateLeasingActivedBy?: Maybe<Scalars['String']['output']>;
  actionApprovedAt?: Maybe<Scalars['String']['output']>;
  actionApprovedBy?: Maybe<Scalars['String']['output']>;
  actionAutoExpiredAt?: Maybe<Scalars['String']['output']>;
  actionAutoExpiredBy?: Maybe<Scalars['String']['output']>;
  actionCancelledAt?: Maybe<Scalars['String']['output']>;
  actionCancelledBy?: Maybe<Scalars['String']['output']>;
  actionDeletedAt?: Maybe<Scalars['String']['output']>;
  actionDeletedBy?: Maybe<Scalars['String']['output']>;
  actionEndedAt?: Maybe<Scalars['String']['output']>;
  actionEndedBy?: Maybe<Scalars['String']['output']>;
  actionRejectUpdateLeasingActivedAt?: Maybe<Scalars['String']['output']>;
  actionRejectUpdateLeasingActivedBy?: Maybe<Scalars['String']['output']>;
  actionRejectedAt?: Maybe<Scalars['String']['output']>;
  actionRejectedBy?: Maybe<Scalars['String']['output']>;
  actionRejectedCancelAt?: Maybe<Scalars['String']['output']>;
  actionRejectedCancelBy?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  endedAt?: Maybe<Scalars['String']['output']>;
  endedPayAt?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  leasingIndexId?: Maybe<Scalars['String']['output']>;
  requestApprovedAt?: Maybe<Scalars['String']['output']>;
  requestApprovedBy?: Maybe<Scalars['String']['output']>;
  requestCancelledAt?: Maybe<Scalars['String']['output']>;
  requestCancelledBy?: Maybe<Scalars['String']['output']>;
  requestCancelledFile?: Maybe<Scalars['String']['output']>;
  requestCancelledNote?: Maybe<Scalars['String']['output']>;
  requestEndCancelledAt?: Maybe<Scalars['String']['output']>;
  requestUpdateLeasingActivedAt?: Maybe<Scalars['String']['output']>;
  requestUpdateLeasingActivedBy?: Maybe<Scalars['String']['output']>;
  requestUpdateLeasingNote?: Maybe<Scalars['String']['output']>;
  startedAt?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type LeasingEwInvoiceSumReferenceType = {
  __typename?: 'LeasingEWInvoiceSumReferenceType';
  count?: Maybe<Scalars['Int']['output']>;
  countApprovedAndInvoice?: Maybe<Scalars['Int']['output']>;
  countApprovedAndNoInvoice?: Maybe<Scalars['Int']['output']>;
  countPending?: Maybe<Scalars['Int']['output']>;
  sum?: Maybe<Scalars['Float']['output']>;
  sumApprovedAndInvoice?: Maybe<Scalars['Float']['output']>;
  sumApprovedAndNoInvoice?: Maybe<Scalars['Float']['output']>;
  sumPending?: Maybe<Scalars['Float']['output']>;
};

export type LeasingEwInvoiceType = {
  __typename?: 'LeasingEWInvoiceType';
  _id?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  invoiceNo?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  leasingBatchElectricReference?: Maybe<Array<Maybe<LeasingBatchElectricReferenceType>>>;
  leasingBatchElectricSumReference?: Maybe<LeasingEwInvoiceSumReferenceType>;
  leasingBatchWaterReference?: Maybe<Array<Maybe<LeasingBatchWaterReferenceType>>>;
  leasingBatchWaterSumReference?: Maybe<LeasingEwInvoiceSumReferenceType>;
  leasingIndex?: Maybe<LeasingIndexType>;
  leasingIndexId?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  receiptReferenceId?: Maybe<Scalars['String']['output']>;
  totalCount?: Maybe<Scalars['Int']['output']>;
  totalSum?: Maybe<Scalars['Float']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type LeasingElectricType = {
  __typename?: 'LeasingElectricType';
  _id?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  electric?: Maybe<ElectricType>;
  electricId?: Maybe<Scalars['String']['output']>;
  electricityConversionFee?: Maybe<Scalars['Float']['output']>;
  fixedAmount?: Maybe<FixedAmountType>;
  fixedAmountId?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  lastNumber?: Maybe<Scalars['Float']['output']>;
  leasingIndex?: Maybe<LeasingIndexType>;
  leasingIndexId?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type LeasingIndexChangeLogType = {
  __typename?: 'LeasingIndexChangeLogType';
  _id?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  contractCategory?: Maybe<Scalars['String']['output']>;
  contractNo?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  customer?: Maybe<CustomerType>;
  customerId?: Maybe<Scalars['String']['output']>;
  fileUrl?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  paymentMethod?: Maybe<Scalars['String']['output']>;
  shopCategory?: Maybe<ShopCategoryType>;
  shopCategoryId?: Maybe<Scalars['String']['output']>;
  shopName?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type LeasingIndexType = {
  __typename?: 'LeasingIndexType';
  _id?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  contractCategory?: Maybe<Scalars['String']['output']>;
  contractNo?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  customer?: Maybe<CustomerType>;
  customerId?: Maybe<Scalars['String']['output']>;
  fileUrl?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  leasingDateTime?: Maybe<LeasingDateTimeType>;
  leasingInstallment?: Maybe<Array<Maybe<LeasingInstallmentType>>>;
  leasingOrder?: Maybe<Array<Maybe<LeasingOrderType>>>;
  leasingSum?: Maybe<LeasingSumType>;
  paymentMethod?: Maybe<Scalars['String']['output']>;
  shopCategoryId?: Maybe<Scalars['String']['output']>;
  shopName?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type LeasingInstallmentType = {
  __typename?: 'LeasingInstallmentType';
  _id?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  currency?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  leasingIndexId?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  paidAt?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type LeasingOrderType = {
  __typename?: 'LeasingOrderType';
  _id?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  centralAmount?: Maybe<Scalars['Float']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  currency?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  leasingIndexId?: Maybe<Scalars['String']['output']>;
  leasingSumId?: Maybe<Scalars['String']['output']>;
  long?: Maybe<Scalars['Float']['output']>;
  moreArea?: Maybe<Scalars['Float']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  roomArea?: Maybe<RoomAreaType>;
  roomAreaId?: Maybe<Scalars['String']['output']>;
  totalAmount?: Maybe<Scalars['Float']['output']>;
  totalArea?: Maybe<Scalars['Float']['output']>;
  totalAreaAmount?: Maybe<Scalars['Float']['output']>;
  totalAreaCentralAmount?: Maybe<Scalars['Float']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
  wide?: Maybe<Scalars['Float']['output']>;
};

export type LeasingSumType = {
  __typename?: 'LeasingSumType';
  _id?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  centralAmount?: Maybe<Scalars['Float']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  currency?: Maybe<Scalars['String']['output']>;
  depositAmount?: Maybe<Scalars['Float']['output']>;
  depositCurrency?: Maybe<Scalars['String']['output']>;
  depositStatus?: Maybe<Scalars['String']['output']>;
  discountAmount?: Maybe<Scalars['Float']['output']>;
  discountCentralAmount?: Maybe<Scalars['Float']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  leasingIndexId?: Maybe<Scalars['String']['output']>;
  returnDepositedAt?: Maybe<Scalars['String']['output']>;
  returnDepositedBy?: Maybe<Scalars['String']['output']>;
  sumAmount?: Maybe<Scalars['Float']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type LeasingWaterType = {
  __typename?: 'LeasingWaterType';
  _id?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  fixedAmount?: Maybe<FixedAmountType>;
  fixedAmountId?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  lastNumber?: Maybe<Scalars['Float']['output']>;
  leasingIndex?: Maybe<LeasingIndexType>;
  leasingIndexId?: Maybe<Scalars['String']['output']>;
  maintenanceFixedAmount?: Maybe<FixedAmountType>;
  maintenanceFixedAmountId?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
  water?: Maybe<WaterType>;
  waterId?: Maybe<Scalars['String']['output']>;
};

export type LevelType = {
  __typename?: 'LevelType';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  enName?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  laName?: Maybe<Scalars['String']['output']>;
  levelCode?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type LoadAdminByIdDto = {
  adminId: Scalars['String']['input'];
};

export type LoadAdminByIdDtoResponse = {
  __typename?: 'LoadAdminByIdDtoResponse';
  admin?: Maybe<AdminType>;
};

export type LoadAdminDetailByTokenDtoResponse = {
  __typename?: 'LoadAdminDetailByTokenDtoResponse';
  admin?: Maybe<AdminType>;
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type LoadAdminDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
};

export type LoadAdminDtoResponse = {
  __typename?: 'LoadAdminDtoResponse';
  admin?: Maybe<Array<AdminType>>;
  count?: Maybe<Scalars['Int']['output']>;
};

export type LoadAllCompanyDtoResponse = {
  __typename?: 'LoadAllCompanyDtoResponse';
  items?: Maybe<Array<Maybe<CompanyType>>>;
};

export type LoadAllEmployeeDtoResponse = {
  __typename?: 'LoadAllEmployeeDtoResponse';
  items?: Maybe<Array<Maybe<EmployeeType>>>;
  total?: Maybe<Scalars['Int']['output']>;
};

export type LoadCompanyByIdDto = {
  _id: Scalars['String']['input'];
};

export type LoadCompanyByIdDtoResponse = {
  __typename?: 'LoadCompanyByIdDtoResponse';
  _id?: Maybe<Scalars['String']['output']>;
  companyCode?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  enName?: Maybe<Scalars['String']['output']>;
  laName?: Maybe<Scalars['String']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type LoadCustomerDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
};

export type LoadCustomerDtoResponse = {
  __typename?: 'LoadCustomerDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  customer?: Maybe<Array<Maybe<CustomerType>>>;
};

export type LoadDraftLeasingBatchElectricDetailDto = {
  leasingBatchElectricId?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
};

export type LoadDraftLeasingBatchElectricDetailDtoResponse = {
  __typename?: 'LoadDraftLeasingBatchElectricDetailDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  items?: Maybe<Array<Maybe<LoadDraftLeasingBatchElectricDetailItemType>>>;
};

export type LoadDraftLeasingBatchElectricDetailItemType = {
  __typename?: 'LoadDraftLeasingBatchElectricDetailItemType';
  currency?: Maybe<Scalars['String']['output']>;
  electric?: Maybe<ElectricType>;
  electricityConversionFee?: Maybe<Scalars['Float']['output']>;
  fixedAmount?: Maybe<FixedAmountType>;
  lastNumber?: Maybe<Scalars['Float']['output']>;
  leasingElectricId?: Maybe<Scalars['String']['output']>;
  leasingIndex?: Maybe<LeasingIndexType>;
  leasingIndexId?: Maybe<Scalars['String']['output']>;
};

export type LoadDraftLeasingBatchWaterDetailDto = {
  leasingBatchWaterId?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
};

export type LoadDraftLeasingBatchWaterDetailDtoResponse = {
  __typename?: 'LoadDraftLeasingBatchWaterDetailDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  items?: Maybe<Array<Maybe<LoadDraftLeasingBatchWaterDetailItemType>>>;
};

export type LoadDraftLeasingBatchWaterDetailItemType = {
  __typename?: 'LoadDraftLeasingBatchWaterDetailItemType';
  currency?: Maybe<Scalars['String']['output']>;
  fixedAmount?: Maybe<FixedAmountType>;
  lastNumber?: Maybe<Scalars['Float']['output']>;
  leasingIndex?: Maybe<LeasingIndexType>;
  leasingIndexId?: Maybe<Scalars['String']['output']>;
  leasingWaterId?: Maybe<Scalars['String']['output']>;
  maintenanceFixedAmount?: Maybe<FixedAmountType>;
  water?: Maybe<WaterType>;
};

export type LoadElectricDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
  status?: InputMaybe<Scalars['String']['input']>;
};

export type LoadElectricDtoResponse = {
  __typename?: 'LoadElectricDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  electric?: Maybe<Array<Maybe<ElectricType>>>;
};

export type LoadElectricLastInfoFromInvoiceByIdDto = {
  _id: Scalars['String']['input'];
};

export type LoadElectricLastInfoFromInvoiceByIdDtoResponse = {
  __typename?: 'LoadElectricLastInfoFromInvoiceByIdDtoResponse';
  amount?: Maybe<Scalars['Int']['output']>;
  electricityConversionFee?: Maybe<Scalars['Int']['output']>;
  lastNumber?: Maybe<Scalars['Int']['output']>;
};

export type LoadEmployeeByIdDto = {
  _id: Scalars['String']['input'];
};

export type LoadEmployeeByIdDtoResponse = {
  __typename?: 'LoadEmployeeByIdDtoResponse';
  _id?: Maybe<Scalars['String']['output']>;
  companyId?: Maybe<CompanyType>;
  createdAt?: Maybe<Scalars['String']['output']>;
  depId?: Maybe<DepartmentType>;
  dob?: Maybe<Scalars['String']['output']>;
  email?: Maybe<Scalars['String']['output']>;
  empID?: Maybe<Scalars['String']['output']>;
  empNumber?: Maybe<Scalars['Int']['output']>;
  fNameEn?: Maybe<Scalars['String']['output']>;
  fNameLa?: Maybe<Scalars['String']['output']>;
  genderID?: Maybe<Scalars['String']['output']>;
  lNameEn?: Maybe<Scalars['String']['output']>;
  lNameLa?: Maybe<Scalars['String']['output']>;
  levelId?: Maybe<LevelType>;
  nickNameEn?: Maybe<Scalars['String']['output']>;
  nickNameLa?: Maybe<Scalars['String']['output']>;
  phone?: Maybe<Scalars['String']['output']>;
  positionId?: Maybe<PositionType>;
  roleId?: Maybe<Scalars['String']['output']>;
  sectorId?: Maybe<SectorType>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  userName?: Maybe<Scalars['String']['output']>;
  workingStart?: Maybe<Scalars['String']['output']>;
};

export type LoadFixedAmountDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  method?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  page?: InputMaybe<Scalars['Int']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
};

export type LoadFixedAmountDtoResponse = {
  __typename?: 'LoadFixedAmountDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  fixedAmount?: Maybe<Array<Maybe<FixedAmountType>>>;
};

export type LoadLeasingBatchElectricDetailDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  leasingBatchElectricId?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
};

export type LoadLeasingBatchElectricDetailDtoResponse = {
  __typename?: 'LoadLeasingBatchElectricDetailDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  leasingBatchElectricDetail?: Maybe<Array<Maybe<LeasingBatchElectricDetailType>>>;
};

export type LoadLeasingBatchElectricDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
  status?: InputMaybe<Scalars['String']['input']>;
};

export type LoadLeasingBatchElectricDtoResponse = {
  __typename?: 'LoadLeasingBatchElectricDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  leasingBatchElectric?: Maybe<Array<Maybe<LeasingBatchElectricType>>>;
};

export type LoadLeasingBatchWaterDetailDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  leasingBatchWaterId?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
};

export type LoadLeasingBatchWaterDetailDtoResponse = {
  __typename?: 'LoadLeasingBatchWaterDetailDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  leasingBatchWaterDetail?: Maybe<Array<Maybe<LeasingBatchWaterDetailType>>>;
};

export type LoadLeasingBatchWaterDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
  status?: InputMaybe<Scalars['String']['input']>;
};

export type LoadLeasingBatchWaterDtoResponse = {
  __typename?: 'LoadLeasingBatchWaterDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  leasingBatchWater?: Maybe<Array<Maybe<LeasingBatchWaterType>>>;
};

export type LoadLeasingEwInvoiceDto = {
  keyword?: InputMaybe<Scalars['String']['input']>;
  name?: InputMaybe<Scalars['String']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
  status?: InputMaybe<Scalars['String']['input']>;
};

export type LoadLeasingEwInvoiceDtoResponse = {
  __typename?: 'LoadLeasingEWInvoiceDtoResponse';
  company?: Maybe<CompanyType>;
  leasingEWInvoice?: Maybe<Array<Maybe<LeasingEwInvoiceType>>>;
};

export type LoadLeasingElectricDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
};

export type LoadLeasingElectricDtoResponse = {
  __typename?: 'LoadLeasingElectricDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  leasingElectric?: Maybe<Array<Maybe<LeasingElectricType>>>;
};

export type LoadLeasingIndexDetailByIdDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
};

export type LoadLeasingIndexDetailByIdDtoResponse = {
  __typename?: 'LoadLeasingIndexDetailByIdDtoResponse';
  customer?: Maybe<CustomerType>;
  leasingIndex?: Maybe<LeasingIndexType>;
  leasingOrder?: Maybe<Array<Maybe<LeasingOrderType>>>;
  leasingSum?: Maybe<LeasingSumType>;
  shopCategory?: Maybe<ShopCategoryType>;
};

export type LoadLeasingIndexDto = {
  contractCategory?: InputMaybe<Scalars['String']['input']>;
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  shopCategoryId?: InputMaybe<Scalars['String']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
  status?: InputMaybe<Scalars['String']['input']>;
};

export type LoadLeasingIndexDtoResponse = {
  __typename?: 'LoadLeasingIndexDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  leasingIndex?: Maybe<Array<Maybe<LeasingIndexType>>>;
};

export type LoadLeasingIndexRejectLogByIdDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
};

export type LoadLeasingIndexRejectLogByIdDtoResponse = {
  __typename?: 'LoadLeasingIndexRejectLogByIdDtoResponse';
  leasingIndexChangeLog?: Maybe<LeasingIndexChangeLogType>;
};

export type LoadLeasingIndexWillBeExpiredSoonDto = {
  between?: InputMaybe<LoadReportBetweenInput>;
  contractCategory?: InputMaybe<Scalars['String']['input']>;
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  shopCategoryId?: InputMaybe<Scalars['String']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
};

export type LoadLeasingIndexWillBeExpiredSoonDtoResponse = {
  __typename?: 'LoadLeasingIndexWillBeExpiredSoonDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  leasingIndex?: Maybe<Array<Maybe<LeasingIndexType>>>;
};

export type LoadLeasingWaterDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
};

export type LoadLeasingWaterDtoResponse = {
  __typename?: 'LoadLeasingWaterDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  leasingWater?: Maybe<Array<Maybe<LeasingWaterType>>>;
};

export type LoadMmsUserDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
};

export type LoadMmsUserDtoResponse = {
  __typename?: 'LoadMMSUserDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  user?: Maybe<Array<Maybe<MmsUserType>>>;
};

export type LoadMmsUserRoleDtoResponse = {
  __typename?: 'LoadMMSUserRoleDtoResponse';
  user?: Maybe<MmsUserType>;
};

export type LoadOnlyServiceAccountIdFromBuIdByAdminDto = {
  buId: Scalars['String']['input'];
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
};

export type LoadOnlyServiceAccountIdFromBuIdByAdminDtoResponse = {
  __typename?: 'LoadOnlyServiceAccountIdFromBUIdByAdminDtoResponse';
  count?: Maybe<Scalars['Float']['output']>;
  serviceAccount?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
};

export type LoadReportBetweenInput = {
  end?: InputMaybe<Scalars['String']['input']>;
  start?: InputMaybe<Scalars['String']['input']>;
};

export type LoadRoomAreaCategoryDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
};

export type LoadRoomAreaCategoryDtoResponse = {
  __typename?: 'LoadRoomAreaCategoryDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  roomAreaCategory?: Maybe<Array<Maybe<RoomAreaCategoryType>>>;
};

export type LoadRoomAreaDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  roomAreaCategoryId?: InputMaybe<Scalars['String']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
  status?: InputMaybe<Scalars['String']['input']>;
  zoneId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadRoomAreaDtoResponse = {
  __typename?: 'LoadRoomAreaDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  roomArea?: Maybe<Array<Maybe<RoomAreaType>>>;
};

export type LoadServiceAccountByAdminDto = {
  buId?: InputMaybe<Scalars['String']['input']>;
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
};

export type LoadServiceAccountByAdminDtoResponse = {
  __typename?: 'LoadServiceAccountByAdminDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  serviceAccount?: Maybe<Array<Maybe<ServiceAccountType>>>;
};

export type LoadServiceAccountByIdDto = {
  serviceAccountId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadServiceAccountByIdDtoResponse = {
  __typename?: 'LoadServiceAccountByIdDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type LoadServiceAccountDetailByTokenDtoResponse = {
  __typename?: 'LoadServiceAccountDetailByTokenDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type LoadServiceAccountDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
};

export type LoadServiceAccountDtoResponse = {
  __typename?: 'LoadServiceAccountDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  serviceAccount?: Maybe<Array<Maybe<ServiceAccountType>>>;
};

export type LoadServiceAccountSignatureArrayByIdDto = {
  serviceAccountId: Array<Scalars['String']['input']>;
};

export type LoadServiceAccountSignatureArrayByIdDtoResponse = {
  __typename?: 'LoadServiceAccountSignatureArrayByIdDtoResponse';
  serviceAccountSignature?: Maybe<Array<ServiceAccountSignatureType>>;
};

export type LoadServiceAccountSignatureByIdDto = {
  serviceAccountId?: InputMaybe<Scalars['String']['input']>;
};

export type LoadServiceAccountSignatureByIdDtoResponse = {
  __typename?: 'LoadServiceAccountSignatureByIdDtoResponse';
  serviceAccountSignature?: Maybe<ServiceAccountSignatureType>;
};

export type LoadShopCategoryDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
};

export type LoadShopCategoryDtoResponse = {
  __typename?: 'LoadShopCategoryDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  shopCategory?: Maybe<Array<Maybe<ShopCategoryType>>>;
};

export type LoadUserByIdDto = {
  userId: Scalars['String']['input'];
};

export type LoadUserByIdDtoResponse = {
  __typename?: 'LoadUserByIdDtoResponse';
  user?: Maybe<UserType>;
};

export type LoadUserDetailByTokenDtoResponse = {
  __typename?: 'LoadUserDetailByTokenDtoResponse';
  user?: Maybe<UserType>;
};

export type LoadUserDtoResponse = {
  __typename?: 'LoadUserDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  user?: Maybe<Array<UserType>>;
};

export type LoadUserSignatureArrayByIdDto = {
  userId: Array<Scalars['String']['input']>;
};

export type LoadUserSignatureArrayByIdDtoResponse = {
  __typename?: 'LoadUserSignatureArrayByIdDtoResponse';
  userSignature?: Maybe<Array<UserSignatureType>>;
};

export type LoadUserSignatureByIdDto = {
  userId: Scalars['String']['input'];
};

export type LoadUserSignatureByIdDtoResponse = {
  __typename?: 'LoadUserSignatureByIdDtoResponse';
  userSignature?: Maybe<UserSignatureType>;
};

export type LoadWaterDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
  status?: InputMaybe<Scalars['String']['input']>;
};

export type LoadWaterDtoResponse = {
  __typename?: 'LoadWaterDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  water?: Maybe<Array<Maybe<WaterType>>>;
};

export type LoadZoneDto = {
  isActive?: InputMaybe<Scalars['String']['input']>;
  keyword?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
  sortDirection?: InputMaybe<Scalars['String']['input']>;
  sortField?: InputMaybe<Scalars['String']['input']>;
};

export type LoadZoneDtoResponse = {
  __typename?: 'LoadZoneDtoResponse';
  count?: Maybe<Scalars['Int']['output']>;
  zone?: Maybe<Array<Maybe<ZoneType>>>;
};

export type LoginDto = {
  password: Scalars['String']['input'];
  userName: Scalars['String']['input'];
};

export type LoginDtoResponse = {
  __typename?: 'LoginDtoResponse';
  _id?: Maybe<Scalars['String']['output']>;
  refreshToken?: Maybe<Scalars['String']['output']>;
  token?: Maybe<Scalars['String']['output']>;
};

export type MmsUserPermissionType = {
  __typename?: 'MMSUserPermissionType';
  action?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  feature?: Maybe<Scalars['String']['output']>;
};

export type MmsUserType = {
  __typename?: 'MMSUserType';
  _id?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  empId?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  permission?: Maybe<Array<MmsUserPermissionType>>;
  roleName?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type Mutation = {
  __typename?: 'Mutation';
  addAccessToUserBUByAdmin: AddAccessToUserBuByAdminDtoResponse;
  adminSignup: AdminSignupDtoResponse;
  changeServiceAccountPassword: ChangeServiceAccountPasswordResponseDto;
  changeServiceAccountUsername: ChangeServiceAccountUsernameDtoResponse;
  changeServiceAccountUsernameByAdmin: ChangeServiceAccountUsernameByAdminDtoResponse;
  confirmCreateUserOTP: ConfirmCreateUserOtpDtoResponse;
  createCustomer: CreateCustomerDtoResponse;
  createElectric: CreateElectricDtoResponse;
  createFixedAmount: CreateFixedAmountDtoResponse;
  createLeasingBatchElectric: CreateLeasingBatchElectricDtoResponse;
  createLeasingBatchElectricDetail: CreateLeasingBatchElectricDetailDtoResponse;
  createLeasingBatchWater: CreateLeasingBatchWaterDtoResponse;
  createLeasingBatchWaterDetail: CreateLeasingBatchWaterDetailDtoResponse;
  createLeasingEWInvoice: CreateLeasingEwInvoiceDtoResponse;
  createLeasingElectric: CreateLeasingElectricDtoResponse;
  createLeasingIndex: CreateLeasingIndexDtoResponse;
  createLeasingWater: CreateLeasingWaterDtoResponse;
  createRoomArea: CreateRoomAreaDtoResponse;
  createRoomAreaCategory: CreateRoomAreaCategoryDtoResponse;
  createShopCategory: CreateShopCategoryDtoResponse;
  createUser: CreateMmsUserDtoResponse;
  createUserOTP: CreateUserOtpDtoResponse;
  createWater: CreateWaterDtoResponse;
  createZone: CreateZoneDtoResponse;
  deleteAdmin: DeleteAdminDtoResponse;
  deleteCustomer: DeleteCustomerDtoResponse;
  deleteElectric: DeleteElectricDtoResponse;
  deleteFixedAmount: DeleteFixedAmountDtoResponse;
  deleteLeasingBatchElectric: DeleteLeasingBatchElectricDtoResponse;
  deleteLeasingBatchElectricDetail: DeleteLeasingBatchElectricDetailDtoResponse;
  deleteLeasingBatchWater: DeleteLeasingBatchWaterDtoResponse;
  deleteLeasingBatchWaterDetail: DeleteLeasingBatchWaterDetailDtoResponse;
  deleteLeasingElectric: DeleteLeasingElectricDtoResponse;
  deleteLeasingIndex: DeleteLeasingIndexDtoResponse;
  deleteLeasingWater: DeleteLeasingWaterDtoResponse;
  deleteRoomArea: DeleteRoomAreaDtoResponse;
  deleteRoomAreaCategory: DeleteRoomAreaCategoryDtoResponse;
  deleteServiceAccount: DeleteServiceAccountDtoResponse;
  deleteServiceAccountByAdmin: DeleteServiceAccountDtoResponse;
  deleteShopCategory: DeleteShopCategoryDtoResponse;
  deleteUser: DeleteMmsUserDtoResponse;
  deleteUserByAdmin: DeleteUserByAdminDtoResponse;
  deleteWater: DeleteWaterDtoResponse;
  deleteZone: DeleteZoneDtoResponse;
  resetServiceAccountPassword: ResetServiceAccountPasswordResponseDto;
  restoreDeleteAdmin: RestoreDeleteAdminDtoResponse;
  restoreDeleteCustomer: RestoreDeleteCustomerDtoResponse;
  restoreDeleteElectric: RestoreDeleteElectricDtoResponse;
  restoreDeleteFixedAmount: RestoreDeleteFixedAmountDtoResponse;
  restoreDeleteRoomArea: RestoreDeleteRoomAreaDtoResponse;
  restoreDeleteRoomAreaCategory: RestoreDeleteRoomAreaCategoryDtoResponse;
  restoreDeleteServiceAccount: RestoreDeleteServiceAccountDtoResponse;
  restoreDeleteServiceAccountByAdmin: RestoreDeleteServiceAccountDtoResponse;
  restoreDeleteShopCategory: RestoreDeleteShopCategoryDtoResponse;
  restoreDeleteUser: RestoreDeleteMmsUserDtoResponse;
  restoreDeleteUserByAdmin: RestoreDeleteUserByAdminDtoResponse;
  restoreDeleteWater: RestoreDeleteWaterDtoResponse;
  restoreDeleteZone: RestoreDeleteZoneDtoResponse;
  serviceAccountSignup: ServiceAccountSignupDtoResponse;
  updateAcceptEditActivedLeasingIndex: UpdateAcceptEditActivedLeasingIndexDtoResponse;
  updateAcceptLeasingIndex: UpdateAcceptLeasingIndexDtoResponse;
  updateActivedLeasingIndex: UpdateActivedLeasingIndexDtoResponse;
  updateAdminProfile: UpdateAdminProfileDtoResponse;
  updateCancelLeasingIndex: UpdateCancelLeasingIndexDtoResponse;
  updateConfirmLeasingBatchElectric: UpdateConfirmLeasingBatchElectricDtoResponse;
  updateConfirmLeasingBatchWater: UpdateConfirmLeasingBatchWaterDtoResponse;
  updateCustomer: UpdateCustomerDtoResponse;
  updateElectric: UpdateElectricDtoResponse;
  updateEndLeasingIndex: UpdateEndLeasingIndexDtoResponse;
  updateFixedAmount: UpdateFixedAmountDtoResponse;
  updateFixedAmountSelection: UpdateFixedAmountSelectionDtoResponse;
  updateLeasingBatchElectric: UpdateLeasingBatchElectricDtoResponse;
  updateLeasingBatchElectricDetail: UpdateLeasingBatchElectricDetailDtoResponse;
  updateLeasingBatchWater: UpdateLeasingBatchWaterDtoResponse;
  updateLeasingBatchWaterDetail: UpdateLeasingBatchWaterDetailDtoResponse;
  updateLeasingElectric: UpdateLeasingElectricDtoResponse;
  updateLeasingIndex: UpdateLeasingIndexDtoResponse;
  updateLeasingWater: UpdateLeasingWaterDtoResponse;
  updateRejectCancelLeasingIndex: UpdateRejectCancelLeasingIndexDtoResponse;
  updateRejectEditActivedLeasingIndex: UpdateRejectEditActivedLeasingIndexDtoResponse;
  updateRejectLeasingBatchElectric: UpdateRejectLeasingBatchElectricDtoResponse;
  updateRejectLeasingBatchWater: UpdateRejectLeasingBatchWaterDtoResponse;
  updateRejectLeasingIndex: UpdateRejectLeasingIndexDtoResponse;
  updateRoomArea: UpdateRoomAreaDtoResponse;
  updateRoomAreaCategory: UpdateRoomAreaCategoryDtoResponse;
  updateServiceAccountProfile: UpdateServiceAccountProfileDtoResponse;
  updateServiceAccountProfileByAdmin: UpdateServiceAccountProfileByAdminDtoResponse;
  updateShopCategory: UpdateShopCategoryDtoResponse;
  updateSubmitLeasingBatchElectric: UpdateSubmitLeasingBatchElectricDtoResponse;
  updateSubmitLeasingBatchWater: UpdateSubmitLeasingBatchWaterDtoResponse;
  updateUser: UpdateMmsUserDtoResponse;
  updateUserProfile: UpdateUserProfileDtoResponse;
  updateUserProfileByAdmin: UpdateUserProfileByAdminDtoResponse;
  updateWater: UpdateWaterDtoResponse;
  updateZone: UpdateZoneDtoResponse;
  upgradePersonalEmployeeByAdmin: UpgradePersonalEmployeeByAdminDtoResponse;
  userBUSignup: UserBuSignupDtoResponse;
  userSignup: UserSignupDtoResponse;
};


export type MutationAddAccessToUserBuByAdminArgs = {
  input: AddAccessToUserBuByAdminDto;
};


export type MutationAdminSignupArgs = {
  input: AdminSignupDto;
};


export type MutationChangeServiceAccountPasswordArgs = {
  input: ChangeServiceAccountPasswordDto;
};


export type MutationChangeServiceAccountUsernameArgs = {
  input: ChangeServiceAccountUsernameDto;
};


export type MutationChangeServiceAccountUsernameByAdminArgs = {
  input: ChangeServiceAccountUsernameByAdminDto;
};


export type MutationConfirmCreateUserOtpArgs = {
  input: ConfirmCreateUserOtpDto;
};


export type MutationCreateCustomerArgs = {
  input: CreateCustomerDto;
};


export type MutationCreateElectricArgs = {
  input: CreateElectricDto;
};


export type MutationCreateFixedAmountArgs = {
  input: CreateFixedAmountDto;
};


export type MutationCreateLeasingBatchElectricArgs = {
  input: CreateLeasingBatchElectricDto;
};


export type MutationCreateLeasingBatchElectricDetailArgs = {
  input: CreateLeasingBatchElectricDetailDto;
};


export type MutationCreateLeasingBatchWaterArgs = {
  input: CreateLeasingBatchWaterDto;
};


export type MutationCreateLeasingBatchWaterDetailArgs = {
  input: CreateLeasingBatchWaterDetailDto;
};


export type MutationCreateLeasingEwInvoiceArgs = {
  input: CreateLeasingEwInvoiceDto;
};


export type MutationCreateLeasingElectricArgs = {
  input: CreateLeasingElectricDto;
};


export type MutationCreateLeasingIndexArgs = {
  input: CreateLeasingIndexDto;
};


export type MutationCreateLeasingWaterArgs = {
  input: CreateLeasingWaterDto;
};


export type MutationCreateRoomAreaArgs = {
  input: CreateRoomAreaDto;
};


export type MutationCreateRoomAreaCategoryArgs = {
  input: CreateRoomAreaCategoryDto;
};


export type MutationCreateShopCategoryArgs = {
  input: CreateShopCategoryDto;
};


export type MutationCreateUserArgs = {
  input: CreateMmsUserDto;
};


export type MutationCreateUserOtpArgs = {
  input: CreateUserOtpDto;
};


export type MutationCreateWaterArgs = {
  input: CreateWaterDto;
};


export type MutationCreateZoneArgs = {
  input: CreateZoneDto;
};


export type MutationDeleteCustomerArgs = {
  input: DeleteCustomerDto;
};


export type MutationDeleteElectricArgs = {
  input: DeleteElectricDto;
};


export type MutationDeleteFixedAmountArgs = {
  input: DeleteFixedAmountDto;
};


export type MutationDeleteLeasingBatchElectricArgs = {
  input: DeleteLeasingBatchElectricDto;
};


export type MutationDeleteLeasingBatchElectricDetailArgs = {
  input: DeleteLeasingBatchElectricDetailDto;
};


export type MutationDeleteLeasingBatchWaterArgs = {
  input: DeleteLeasingBatchWaterDto;
};


export type MutationDeleteLeasingBatchWaterDetailArgs = {
  input: DeleteLeasingBatchWaterDetailDto;
};


export type MutationDeleteLeasingElectricArgs = {
  input: DeleteLeasingElectricDto;
};


export type MutationDeleteLeasingIndexArgs = {
  input: DeleteLeasingIndexDto;
};


export type MutationDeleteLeasingWaterArgs = {
  input: DeleteLeasingWaterDto;
};


export type MutationDeleteRoomAreaArgs = {
  input: DeleteRoomAreaDto;
};


export type MutationDeleteRoomAreaCategoryArgs = {
  input: DeleteRoomAreaCategoryDto;
};


export type MutationDeleteServiceAccountByAdminArgs = {
  input: DeleteServiceAccountByAdminDto;
};


export type MutationDeleteShopCategoryArgs = {
  input: DeleteShopCategoryDto;
};


export type MutationDeleteUserArgs = {
  input: DeleteMmsUserDto;
};


export type MutationDeleteUserByAdminArgs = {
  input: DeleteUserByAdminDto;
};


export type MutationDeleteWaterArgs = {
  input: DeleteWaterDto;
};


export type MutationDeleteZoneArgs = {
  input: DeleteZoneDto;
};


export type MutationResetServiceAccountPasswordArgs = {
  input: ResetServiceAccountPasswordDto;
};


export type MutationRestoreDeleteCustomerArgs = {
  input: RestoreDeleteCustomerDto;
};


export type MutationRestoreDeleteElectricArgs = {
  input: RestoreDeleteElectricDto;
};


export type MutationRestoreDeleteFixedAmountArgs = {
  input: RestoreDeleteFixedAmountDto;
};


export type MutationRestoreDeleteRoomAreaArgs = {
  input: RestoreDeleteRoomAreaDto;
};


export type MutationRestoreDeleteRoomAreaCategoryArgs = {
  input: RestoreDeleteRoomAreaCategoryDto;
};


export type MutationRestoreDeleteServiceAccountByAdminArgs = {
  input: RestoreDeleteServiceAccountByAdminDto;
};


export type MutationRestoreDeleteShopCategoryArgs = {
  input: RestoreDeleteShopCategoryDto;
};


export type MutationRestoreDeleteUserArgs = {
  input: RestoreDeleteMmsUserDto;
};


export type MutationRestoreDeleteUserByAdminArgs = {
  input: RestoreDeleteUserByAdminDto;
};


export type MutationRestoreDeleteWaterArgs = {
  input: RestoreDeleteWaterDto;
};


export type MutationRestoreDeleteZoneArgs = {
  input: RestoreDeleteZoneDto;
};


export type MutationServiceAccountSignupArgs = {
  input: ServiceAccountSignupDto;
};


export type MutationUpdateAcceptEditActivedLeasingIndexArgs = {
  input: UpdateAcceptEditActivedLeasingIndexDto;
};


export type MutationUpdateAcceptLeasingIndexArgs = {
  input: UpdateAcceptLeasingIndexDto;
};


export type MutationUpdateActivedLeasingIndexArgs = {
  input: UpdateActivedLeasingIndexDto;
};


export type MutationUpdateAdminProfileArgs = {
  input: UpdateAdminProfileDto;
};


export type MutationUpdateCancelLeasingIndexArgs = {
  input: UpdateCancelLeasingIndexDto;
};


export type MutationUpdateConfirmLeasingBatchElectricArgs = {
  input: UpdateConfirmLeasingBatchElectricDto;
};


export type MutationUpdateConfirmLeasingBatchWaterArgs = {
  input: UpdateConfirmLeasingBatchWaterDto;
};


export type MutationUpdateCustomerArgs = {
  input: UpdateCustomerDto;
};


export type MutationUpdateElectricArgs = {
  input: UpdateElectricDto;
};


export type MutationUpdateEndLeasingIndexArgs = {
  input: UpdateEndLeasingIndexDto;
};


export type MutationUpdateFixedAmountArgs = {
  input: UpdateFixedAmountDto;
};


export type MutationUpdateFixedAmountSelectionArgs = {
  input: UpdateFixedAmountSelectionDto;
};


export type MutationUpdateLeasingBatchElectricArgs = {
  input: UpdateLeasingBatchElectricDto;
};


export type MutationUpdateLeasingBatchElectricDetailArgs = {
  input: UpdateLeasingBatchElectricDetailDto;
};


export type MutationUpdateLeasingBatchWaterArgs = {
  input: UpdateLeasingBatchWaterDto;
};


export type MutationUpdateLeasingBatchWaterDetailArgs = {
  input: UpdateLeasingBatchWaterDetailDto;
};


export type MutationUpdateLeasingElectricArgs = {
  input: UpdateLeasingElectricDto;
};


export type MutationUpdateLeasingIndexArgs = {
  input: UpdateLeasingIndexDto;
};


export type MutationUpdateLeasingWaterArgs = {
  input: UpdateLeasingWaterDto;
};


export type MutationUpdateRejectCancelLeasingIndexArgs = {
  input: UpdateRejectCancelLeasingIndexDto;
};


export type MutationUpdateRejectEditActivedLeasingIndexArgs = {
  input: UpdateRejectEditActivedLeasingIndexDto;
};


export type MutationUpdateRejectLeasingBatchElectricArgs = {
  input: UpdateRejectLeasingBatchElectricDto;
};


export type MutationUpdateRejectLeasingBatchWaterArgs = {
  input: UpdateRejectLeasingBatchWaterDto;
};


export type MutationUpdateRejectLeasingIndexArgs = {
  input: UpdateRejectLeasingIndexDto;
};


export type MutationUpdateRoomAreaArgs = {
  input: UpdateRoomAreaDto;
};


export type MutationUpdateRoomAreaCategoryArgs = {
  input: UpdateRoomAreaCategoryDto;
};


export type MutationUpdateServiceAccountProfileArgs = {
  input: UpdateServiceAccountProfileDto;
};


export type MutationUpdateServiceAccountProfileByAdminArgs = {
  input: UpdateServiceAccountProfileByAdminDto;
};


export type MutationUpdateShopCategoryArgs = {
  input: UpdateShopCategoryDto;
};


export type MutationUpdateSubmitLeasingBatchElectricArgs = {
  input: UpdateSubmitLeasingBatchElectricDto;
};


export type MutationUpdateSubmitLeasingBatchWaterArgs = {
  input: UpdateSubmitLeasingBatchWaterDto;
};


export type MutationUpdateUserArgs = {
  input: UpdateMmsUserDto;
};


export type MutationUpdateUserProfileArgs = {
  input: UpdateUserProfileDto;
};


export type MutationUpdateUserProfileByAdminArgs = {
  input: UpdateUserProfileByAdminDto;
};


export type MutationUpdateWaterArgs = {
  input: UpdateWaterDto;
};


export type MutationUpdateZoneArgs = {
  input: UpdateZoneDto;
};


export type MutationUpgradePersonalEmployeeByAdminArgs = {
  input: UpgradePersonalEmployeeByAdminDto;
};


export type MutationUserBuSignupArgs = {
  input: UserBuSignupDto;
};


export type MutationUserSignupArgs = {
  input: UserSignupDto;
};

export type PaginateInput = {
  limit?: InputMaybe<Scalars['Int']['input']>;
  page?: InputMaybe<Scalars['Int']['input']>;
};

export type PositionType = {
  __typename?: 'PositionType';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  enName?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['Boolean']['output']>;
  laName?: Maybe<Scalars['String']['output']>;
  levelId?: Maybe<LevelType>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type Query = {
  __typename?: 'Query';
  adminSignin: AdminSigninDtoResponse;
  adminValidateToken: AdminValidateTokenDtoResponse;
  authorization: AuthorizationDtoResponse;
  checkExistUserByUsername: CheckExistUserByUsernameDtoResponse;
  companyLoadAll: LoadAllCompanyDtoResponse;
  companyLoadById?: Maybe<LoadCompanyByIdDtoResponse>;
  employeeLoadAll: LoadAllEmployeeDtoResponse;
  employeeLoadById?: Maybe<LoadEmployeeByIdDtoResponse>;
  loadAdmin: LoadAdminDtoResponse;
  loadAdminById: LoadAdminByIdDtoResponse;
  loadAdminDetailByToken: LoadAdminDetailByTokenDtoResponse;
  loadCustomer: LoadCustomerDtoResponse;
  loadDraftLeasingBatchElectricDetail: LoadDraftLeasingBatchElectricDetailDtoResponse;
  loadDraftLeasingBatchWaterDetail: LoadDraftLeasingBatchWaterDetailDtoResponse;
  loadElectric: LoadElectricDtoResponse;
  loadElectricLastInfoFromInvoiceById: LoadElectricLastInfoFromInvoiceByIdDtoResponse;
  loadFixedAmount: LoadFixedAmountDtoResponse;
  loadLeasingBatchElectric: LoadLeasingBatchElectricDtoResponse;
  loadLeasingBatchElectricDetail: LoadLeasingBatchElectricDetailDtoResponse;
  loadLeasingBatchWater: LoadLeasingBatchWaterDtoResponse;
  loadLeasingBatchWaterDetail: LoadLeasingBatchWaterDetailDtoResponse;
  loadLeasingEWInvoice: LoadLeasingEwInvoiceDtoResponse;
  loadLeasingElectric: LoadLeasingElectricDtoResponse;
  loadLeasingIndex: LoadLeasingIndexDtoResponse;
  loadLeasingIndexDetailById: LoadLeasingIndexDetailByIdDtoResponse;
  loadLeasingIndexRejectLogById: LoadLeasingIndexRejectLogByIdDtoResponse;
  loadLeasingIndexWillBeExpiredSoon: LoadLeasingIndexWillBeExpiredSoonDtoResponse;
  loadLeasingWater: LoadLeasingWaterDtoResponse;
  loadOnlyServiceAccountIdFromBUIdByAdmin: LoadOnlyServiceAccountIdFromBuIdByAdminDtoResponse;
  loadRoomArea: LoadRoomAreaDtoResponse;
  loadRoomAreaCategory: LoadRoomAreaCategoryDtoResponse;
  loadServiceAccount: LoadServiceAccountDtoResponse;
  loadServiceAccountByAdmin: LoadServiceAccountByAdminDtoResponse;
  loadServiceAccountById: LoadServiceAccountByIdDtoResponse;
  loadServiceAccountDetailByToken: LoadServiceAccountDetailByTokenDtoResponse;
  loadServiceAccountSignatureArrayById: LoadServiceAccountSignatureArrayByIdDtoResponse;
  loadServiceAccountSignatureById: LoadServiceAccountSignatureByIdDtoResponse;
  loadShopCategory: LoadShopCategoryDtoResponse;
  loadUser: LoadMmsUserDtoResponse;
  loadUserById: LoadUserByIdDtoResponse;
  loadUserDetailByToken: LoadUserDetailByTokenDtoResponse;
  loadUserRole: LoadMmsUserRoleDtoResponse;
  loadUserSignatureArrayById: LoadUserSignatureArrayByIdDtoResponse;
  loadUserSignatureById: LoadUserSignatureByIdDtoResponse;
  loadWater: LoadWaterDtoResponse;
  loadZone: LoadZoneDtoResponse;
  login: LoginDtoResponse;
  searchServiceAccount: SearchServiceAccountResponseDto;
  serviceAccountSignin: ServiceAccountSigninDtoResponse;
  serviceAccountValidateToken: ServiceAccountValidateTokenDtoResponse;
  userBUSignin: UserBuSigninDtoResponse;
  userSignin: UserSigninDtoResponse;
  userValidateToken: UserValidateTokenDtoResponse;
};


export type QueryAdminSigninArgs = {
  input: AdminSigninDto;
};


export type QueryCheckExistUserByUsernameArgs = {
  input: CheckExistUserByUsernameDto;
};


export type QueryCompanyLoadAllArgs = {
  query: QueryProps;
};


export type QueryCompanyLoadByIdArgs = {
  input: LoadCompanyByIdDto;
};


export type QueryEmployeeLoadAllArgs = {
  query: QueryProps;
};


export type QueryEmployeeLoadByIdArgs = {
  input: LoadEmployeeByIdDto;
};


export type QueryLoadAdminArgs = {
  input: LoadAdminDto;
};


export type QueryLoadAdminByIdArgs = {
  input: LoadAdminByIdDto;
};


export type QueryLoadCustomerArgs = {
  input: LoadCustomerDto;
};


export type QueryLoadDraftLeasingBatchElectricDetailArgs = {
  input: LoadDraftLeasingBatchElectricDetailDto;
};


export type QueryLoadDraftLeasingBatchWaterDetailArgs = {
  input: LoadDraftLeasingBatchWaterDetailDto;
};


export type QueryLoadElectricArgs = {
  input: LoadElectricDto;
};


export type QueryLoadElectricLastInfoFromInvoiceByIdArgs = {
  input: LoadElectricLastInfoFromInvoiceByIdDto;
};


export type QueryLoadFixedAmountArgs = {
  input: LoadFixedAmountDto;
};


export type QueryLoadLeasingBatchElectricArgs = {
  input: LoadLeasingBatchElectricDto;
};


export type QueryLoadLeasingBatchElectricDetailArgs = {
  input: LoadLeasingBatchElectricDetailDto;
};


export type QueryLoadLeasingBatchWaterArgs = {
  input: LoadLeasingBatchWaterDto;
};


export type QueryLoadLeasingBatchWaterDetailArgs = {
  input: LoadLeasingBatchWaterDetailDto;
};


export type QueryLoadLeasingEwInvoiceArgs = {
  input: LoadLeasingEwInvoiceDto;
};


export type QueryLoadLeasingElectricArgs = {
  input: LoadLeasingElectricDto;
};


export type QueryLoadLeasingIndexArgs = {
  input: LoadLeasingIndexDto;
};


export type QueryLoadLeasingIndexDetailByIdArgs = {
  input: LoadLeasingIndexDetailByIdDto;
};


export type QueryLoadLeasingIndexRejectLogByIdArgs = {
  input: LoadLeasingIndexRejectLogByIdDto;
};


export type QueryLoadLeasingIndexWillBeExpiredSoonArgs = {
  input: LoadLeasingIndexWillBeExpiredSoonDto;
};


export type QueryLoadLeasingWaterArgs = {
  input: LoadLeasingWaterDto;
};


export type QueryLoadOnlyServiceAccountIdFromBuIdByAdminArgs = {
  input: LoadOnlyServiceAccountIdFromBuIdByAdminDto;
};


export type QueryLoadRoomAreaArgs = {
  input: LoadRoomAreaDto;
};


export type QueryLoadRoomAreaCategoryArgs = {
  input: LoadRoomAreaCategoryDto;
};


export type QueryLoadServiceAccountArgs = {
  input: LoadServiceAccountDto;
};


export type QueryLoadServiceAccountByAdminArgs = {
  input: LoadServiceAccountByAdminDto;
};


export type QueryLoadServiceAccountByIdArgs = {
  input: LoadServiceAccountByIdDto;
};


export type QueryLoadServiceAccountSignatureArrayByIdArgs = {
  input: LoadServiceAccountSignatureArrayByIdDto;
};


export type QueryLoadServiceAccountSignatureByIdArgs = {
  input: LoadServiceAccountSignatureByIdDto;
};


export type QueryLoadShopCategoryArgs = {
  input: LoadShopCategoryDto;
};


export type QueryLoadUserArgs = {
  input: LoadMmsUserDto;
};


export type QueryLoadUserByIdArgs = {
  input: LoadUserByIdDto;
};


export type QueryLoadUserSignatureArrayByIdArgs = {
  input: LoadUserSignatureArrayByIdDto;
};


export type QueryLoadUserSignatureByIdArgs = {
  input: LoadUserSignatureByIdDto;
};


export type QueryLoadWaterArgs = {
  input: LoadWaterDto;
};


export type QueryLoadZoneArgs = {
  input: LoadZoneDto;
};


export type QueryLoginArgs = {
  input: LoginDto;
};


export type QuerySearchServiceAccountArgs = {
  input: SearchServiceAccountDto;
};


export type QueryServiceAccountSigninArgs = {
  input: ServiceAccountSigninDto;
};


export type QueryUserBuSigninArgs = {
  input: UserBuSigninDto;
};


export type QueryUserSigninArgs = {
  input: UserSigninDto;
};

export type QueryProps = {
  condition?: InputMaybe<Array<ConditionInput>>;
  dateFilter?: InputMaybe<DateFilterInput>;
  inNumber?: InputMaybe<Array<InNumberInput>>;
  inString?: InputMaybe<Array<InStringInput>>;
  joins?: InputMaybe<Array<Scalars['String']['input']>>;
  paginate?: InputMaybe<PaginateInput>;
  search?: InputMaybe<SearchInput>;
  select?: InputMaybe<Array<Scalars['String']['input']>>;
  sort?: InputMaybe<Scalars['Int']['input']>;
};

export type ResetServiceAccountPasswordDto = {
  newPassword: Scalars['String']['input'];
  serviceAccountId: Scalars['String']['input'];
};

export type ResetServiceAccountPasswordResponseDto = {
  __typename?: 'ResetServiceAccountPasswordResponseDto';
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type RestoreDeleteAdminDtoResponse = {
  __typename?: 'RestoreDeleteAdminDtoResponse';
  admin?: Maybe<AdminType>;
};

export type RestoreDeleteCustomerDto = {
  _id: Scalars['String']['input'];
};

export type RestoreDeleteCustomerDtoResponse = {
  __typename?: 'RestoreDeleteCustomerDtoResponse';
  customer?: Maybe<CustomerType>;
};

export type RestoreDeleteElectricDto = {
  _id: Scalars['String']['input'];
};

export type RestoreDeleteElectricDtoResponse = {
  __typename?: 'RestoreDeleteElectricDtoResponse';
  electric?: Maybe<ElectricType>;
};

export type RestoreDeleteFixedAmountDto = {
  _id: Scalars['String']['input'];
};

export type RestoreDeleteFixedAmountDtoResponse = {
  __typename?: 'RestoreDeleteFixedAmountDtoResponse';
  fixedAmount?: Maybe<FixedAmountType>;
};

export type RestoreDeleteMmsUserDto = {
  _id: Scalars['String']['input'];
};

export type RestoreDeleteMmsUserDtoResponse = {
  __typename?: 'RestoreDeleteMMSUserDtoResponse';
  user?: Maybe<MmsUserType>;
};

export type RestoreDeleteRoomAreaCategoryDto = {
  _id: Scalars['String']['input'];
};

export type RestoreDeleteRoomAreaCategoryDtoResponse = {
  __typename?: 'RestoreDeleteRoomAreaCategoryDtoResponse';
  roomAreaCategory?: Maybe<RoomAreaCategoryType>;
};

export type RestoreDeleteRoomAreaDto = {
  _id: Scalars['String']['input'];
};

export type RestoreDeleteRoomAreaDtoResponse = {
  __typename?: 'RestoreDeleteRoomAreaDtoResponse';
  roomArea?: Maybe<RoomAreaType>;
};

export type RestoreDeleteServiceAccountByAdminDto = {
  serviceAccountId?: InputMaybe<Scalars['String']['input']>;
};

export type RestoreDeleteServiceAccountDtoResponse = {
  __typename?: 'RestoreDeleteServiceAccountDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type RestoreDeleteShopCategoryDto = {
  _id: Scalars['String']['input'];
};

export type RestoreDeleteShopCategoryDtoResponse = {
  __typename?: 'RestoreDeleteShopCategoryDtoResponse';
  shopCategory?: Maybe<ShopCategoryType>;
};

export type RestoreDeleteUserByAdminDto = {
  userId: Scalars['String']['input'];
};

export type RestoreDeleteUserByAdminDtoResponse = {
  __typename?: 'RestoreDeleteUserByAdminDtoResponse';
  user?: Maybe<UserType>;
};

export type RestoreDeleteUserDtoResponse = {
  __typename?: 'RestoreDeleteUserDtoResponse';
  user?: Maybe<UserType>;
};

export type RestoreDeleteWaterDto = {
  _id: Scalars['String']['input'];
};

export type RestoreDeleteWaterDtoResponse = {
  __typename?: 'RestoreDeleteWaterDtoResponse';
  water?: Maybe<WaterType>;
};

export type RestoreDeleteZoneDto = {
  _id: Scalars['String']['input'];
};

export type RestoreDeleteZoneDtoResponse = {
  __typename?: 'RestoreDeleteZoneDtoResponse';
  zone?: Maybe<ZoneType>;
};

export type RoomAreaCategoryType = {
  __typename?: 'RoomAreaCategoryType';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type RoomAreaOwnershipAgentType = {
  __typename?: 'RoomAreaOwnershipAgentType';
  _id?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  endedAt?: Maybe<Scalars['String']['output']>;
  fileUrl?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  note?: Maybe<Scalars['String']['output']>;
  roomAreaId?: Maybe<Scalars['String']['output']>;
  roomAreaOwnershipId?: Maybe<Scalars['String']['output']>;
  startedAt?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type RoomAreaOwnershipType = {
  __typename?: 'RoomAreaOwnershipType';
  _id?: Maybe<Scalars['String']['output']>;
  address?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  fileUrl?: Maybe<Scalars['String']['output']>;
  firstName?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  lastName?: Maybe<Scalars['String']['output']>;
  phoneNumber?: Maybe<Scalars['String']['output']>;
  roomAreaId?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type RoomAreaType = {
  __typename?: 'RoomAreaType';
  _id?: Maybe<Scalars['String']['output']>;
  agentHoldStatus?: Maybe<Scalars['String']['output']>;
  amount?: Maybe<Scalars['Float']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  centralAmount?: Maybe<Scalars['Float']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  currency?: Maybe<Scalars['String']['output']>;
  holdStatus?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  long?: Maybe<Scalars['Float']['output']>;
  moreArea?: Maybe<Scalars['Float']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  roomAreaCategory?: Maybe<RoomAreaCategoryType>;
  roomAreaCategoryId?: Maybe<Scalars['String']['output']>;
  roomAreaOwnership?: Maybe<RoomAreaOwnershipType>;
  roomAreaOwnershipAgent?: Maybe<RoomAreaOwnershipAgentType>;
  status?: Maybe<Scalars['String']['output']>;
  totalAmount?: Maybe<Scalars['Float']['output']>;
  totalArea?: Maybe<Scalars['Float']['output']>;
  totalAreaAmount?: Maybe<Scalars['Float']['output']>;
  totalAreaCentralAmount?: Maybe<Scalars['Float']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
  wide?: Maybe<Scalars['Float']['output']>;
  zone?: Maybe<ZoneType>;
  zoneId?: Maybe<Scalars['String']['output']>;
};

export type SearchInput = {
  q?: InputMaybe<Scalars['String']['input']>;
  searchField?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type SearchServiceAccountDto = {
  keyword: Scalars['String']['input'];
  limit: Scalars['Int']['input'];
  page: Scalars['Int']['input'];
};

export type SearchServiceAccountResponseDto = {
  __typename?: 'SearchServiceAccountResponseDto';
  count?: Maybe<Scalars['Float']['output']>;
  serviceAccount?: Maybe<Array<Maybe<ServiceAccountType>>>;
};

export type SectorType = {
  __typename?: 'SectorType';
  _id?: Maybe<Scalars['String']['output']>;
  companyId?: Maybe<CompanyType>;
  createdAt?: Maybe<Scalars['String']['output']>;
  depId?: Maybe<DepartmentType>;
  enName?: Maybe<Scalars['String']['output']>;
  laName?: Maybe<Scalars['String']['output']>;
  levelId?: Maybe<LevelType>;
  sectorCode?: Maybe<Scalars['String']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountConfigType = {
  __typename?: 'ServiceAccountConfigType';
  assignBy?: Maybe<Scalars['String']['output']>;
  assignDate?: Maybe<Scalars['String']['output']>;
  assignId?: Maybe<Scalars['String']['output']>;
  level?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountInfoForWalletType = {
  __typename?: 'ServiceAccountInfoForWalletType';
  _id?: Maybe<Scalars['String']['output']>;
  config?: Maybe<ServiceAccountConfigType>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  password?: Maybe<Scalars['String']['output']>;
  phoneNumber?: Maybe<Scalars['String']['output']>;
  platform?: Maybe<Scalars['String']['output']>;
  prefix?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Float']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  username?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountInfoType = {
  __typename?: 'ServiceAccountInfoType';
  _id?: Maybe<Scalars['String']['output']>;
  config?: Maybe<ServiceAccountConfigType>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  password?: Maybe<Scalars['String']['output']>;
  phoneNumber?: Maybe<Scalars['String']['output']>;
  platform?: Maybe<Scalars['String']['output']>;
  prefix?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Float']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  username?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountProfileImageInput = {
  cover?: InputMaybe<Scalars['String']['input']>;
  profile?: InputMaybe<Scalars['String']['input']>;
};

export type ServiceAccountProfileImageType = {
  __typename?: 'ServiceAccountProfileImageType';
  cover?: Maybe<Scalars['String']['output']>;
  profile?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountProfileType = {
  __typename?: 'ServiceAccountProfileType';
  _id?: Maybe<Scalars['String']['output']>;
  address?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  district?: Maybe<Scalars['String']['output']>;
  firstName?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  image?: Maybe<ServiceAccountProfileImageType>;
  isActive?: Maybe<Scalars['String']['output']>;
  lastName?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  postcode?: Maybe<Scalars['String']['output']>;
  province?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Float']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  village?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountSignatureType = {
  __typename?: 'ServiceAccountSignatureType';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  privateKey?: Maybe<Scalars['String']['output']>;
  publicKey?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Float']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountSigninDto = {
  password?: InputMaybe<Scalars['String']['input']>;
  username?: InputMaybe<Scalars['String']['input']>;
};

export type ServiceAccountSigninDtoResponse = {
  __typename?: 'ServiceAccountSigninDtoResponse';
  authorization: Scalars['String']['output'];
  business?: Maybe<Scalars['String']['output']>;
};

export type ServiceAccountSignupDto = {
  buId?: InputMaybe<Scalars['String']['input']>;
  firstName?: InputMaybe<Scalars['String']['input']>;
  lastName?: InputMaybe<Scalars['String']['input']>;
  level?: InputMaybe<Scalars['String']['input']>;
  password?: InputMaybe<Scalars['String']['input']>;
  username?: InputMaybe<Scalars['String']['input']>;
};

export type ServiceAccountSignupDtoResponse = {
  __typename?: 'ServiceAccountSignupDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type ServiceAccountType = {
  __typename?: 'ServiceAccountType';
  serviceAccount?: Maybe<ServiceAccountInfoType>;
  serviceAccountProfile?: Maybe<ServiceAccountProfileType>;
};

export type ServiceAccountValidateTokenDtoResponse = {
  __typename?: 'ServiceAccountValidateTokenDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type ShopCategoryType = {
  __typename?: 'ShopCategoryType';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type UpdateAcceptEditActivedLeasingIndexDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateAcceptEditActivedLeasingIndexDtoResponse = {
  __typename?: 'UpdateAcceptEditActivedLeasingIndexDtoResponse';
  leasingIndex?: Maybe<LeasingIndexType>;
};

export type UpdateAcceptLeasingIndexDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateAcceptLeasingIndexDtoResponse = {
  __typename?: 'UpdateAcceptLeasingIndexDtoResponse';
  leasingIndex?: Maybe<LeasingIndexType>;
};

export type UpdateActivedLeasingIndexDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
  contractCategory?: InputMaybe<Scalars['String']['input']>;
  contractNo?: InputMaybe<Scalars['String']['input']>;
  customerId?: InputMaybe<Scalars['String']['input']>;
  endedAt?: InputMaybe<Scalars['String']['input']>;
  endedPayAt?: InputMaybe<Scalars['String']['input']>;
  fileUrl?: InputMaybe<Scalars['String']['input']>;
  note?: InputMaybe<Scalars['String']['input']>;
  shopCategoryId?: InputMaybe<Scalars['String']['input']>;
  shopName?: InputMaybe<Scalars['String']['input']>;
  startedAt?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateActivedLeasingIndexDtoResponse = {
  __typename?: 'UpdateActivedLeasingIndexDtoResponse';
  leasingIndex?: Maybe<LeasingIndexType>;
};

export type UpdateAdminProfileDto = {
  address?: InputMaybe<Scalars['String']['input']>;
  district?: InputMaybe<Scalars['String']['input']>;
  firstName: Scalars['String']['input'];
  image?: InputMaybe<AdminProfileImageInput>;
  lastName: Scalars['String']['input'];
  postcode?: InputMaybe<Scalars['String']['input']>;
  province?: InputMaybe<Scalars['String']['input']>;
  village?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateAdminProfileDtoResponse = {
  __typename?: 'UpdateAdminProfileDtoResponse';
  admin?: Maybe<AdminType>;
};

export type UpdateCancelLeasingIndexDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
  cancelledAt?: InputMaybe<Scalars['String']['input']>;
  fileUrl?: InputMaybe<Scalars['String']['input']>;
  note?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateCancelLeasingIndexDtoResponse = {
  __typename?: 'UpdateCancelLeasingIndexDtoResponse';
  leasingIndex?: Maybe<LeasingIndexType>;
};

export type UpdateConfirmLeasingBatchElectricDto = {
  _id: Scalars['String']['input'];
};

export type UpdateConfirmLeasingBatchElectricDtoResponse = {
  __typename?: 'UpdateConfirmLeasingBatchElectricDtoResponse';
  leasingBatchElectric?: Maybe<LeasingBatchElectricType>;
};

export type UpdateConfirmLeasingBatchWaterDto = {
  _id: Scalars['String']['input'];
};

export type UpdateConfirmLeasingBatchWaterDtoResponse = {
  __typename?: 'UpdateConfirmLeasingBatchWaterDtoResponse';
  leasingBatchWater?: Maybe<LeasingBatchWaterType>;
};

export type UpdateCustomerDto = {
  _id: Scalars['String']['input'];
  address?: InputMaybe<Scalars['String']['input']>;
  contact?: InputMaybe<CustomerContactInput>;
  customId?: InputMaybe<Scalars['String']['input']>;
  deleteContact?: InputMaybe<Scalars['Boolean']['input']>;
  district?: InputMaybe<Scalars['String']['input']>;
  fileUrl?: InputMaybe<Scalars['String']['input']>;
  firstName?: InputMaybe<Scalars['String']['input']>;
  gender?: InputMaybe<Scalars['String']['input']>;
  lastName?: InputMaybe<Scalars['String']['input']>;
  nationality?: InputMaybe<Scalars['String']['input']>;
  phoneNumber?: InputMaybe<Scalars['String']['input']>;
  province?: InputMaybe<Scalars['String']['input']>;
  village?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateCustomerDtoResponse = {
  __typename?: 'UpdateCustomerDtoResponse';
  customer?: Maybe<CustomerType>;
};

export type UpdateElectricDto = {
  _id: Scalars['String']['input'];
  name?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateElectricDtoResponse = {
  __typename?: 'UpdateElectricDtoResponse';
  electric?: Maybe<ElectricType>;
};

export type UpdateEndLeasingIndexDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateEndLeasingIndexDtoResponse = {
  __typename?: 'UpdateEndLeasingIndexDtoResponse';
  leasingIndex?: Maybe<LeasingIndexType>;
};

export type UpdateFixedAmountDto = {
  _id: Scalars['String']['input'];
  amount?: InputMaybe<Scalars['Float']['input']>;
};

export type UpdateFixedAmountDtoResponse = {
  __typename?: 'UpdateFixedAmountDtoResponse';
  fixedAmount?: Maybe<FixedAmountType>;
};

export type UpdateFixedAmountSelectionDto = {
  _id: Scalars['String']['input'];
};

export type UpdateFixedAmountSelectionDtoResponse = {
  __typename?: 'UpdateFixedAmountSelectionDtoResponse';
  fixedAmount?: Maybe<FixedAmountType>;
};

export type UpdateLeasingBatchElectricDetailDto = {
  items?: InputMaybe<Array<InputMaybe<UpdateLeasingBatchElectricDetailItemDto>>>;
  leasingBatchElectricId?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateLeasingBatchElectricDetailDtoResponse = {
  __typename?: 'UpdateLeasingBatchElectricDetailDtoResponse';
  leasingBatchElectricDetail?: Maybe<Array<Maybe<LeasingBatchElectricDetailType>>>;
};

export type UpdateLeasingBatchElectricDetailItemDto = {
  _id: Scalars['String']['input'];
  amount?: InputMaybe<Scalars['Float']['input']>;
  currency?: InputMaybe<Scalars['String']['input']>;
  currentNumber?: InputMaybe<Scalars['Float']['input']>;
  electricityConversionFee?: InputMaybe<Scalars['Float']['input']>;
  fixedAmountId?: InputMaybe<Scalars['String']['input']>;
  lastNumber?: InputMaybe<Scalars['Float']['input']>;
  sumAmount?: InputMaybe<Scalars['Float']['input']>;
  sumUnitAmount?: InputMaybe<Scalars['Float']['input']>;
  unitAmount?: InputMaybe<Scalars['Float']['input']>;
};

export type UpdateLeasingBatchElectricDto = {
  _id: Scalars['String']['input'];
  name?: InputMaybe<Scalars['String']['input']>;
  note?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateLeasingBatchElectricDtoResponse = {
  __typename?: 'UpdateLeasingBatchElectricDtoResponse';
  leasingBatchElectric?: Maybe<LeasingBatchElectricType>;
};

export type UpdateLeasingBatchWaterDetailDto = {
  items?: InputMaybe<Array<InputMaybe<UpdateLeasingBatchWaterDetailItemDto>>>;
  leasingBatchWaterId?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateLeasingBatchWaterDetailDtoResponse = {
  __typename?: 'UpdateLeasingBatchWaterDetailDtoResponse';
  leasingBatchWaterDetail?: Maybe<Array<Maybe<LeasingBatchWaterDetailType>>>;
};

export type UpdateLeasingBatchWaterDetailItemDto = {
  _id: Scalars['String']['input'];
  amount?: InputMaybe<Scalars['Float']['input']>;
  currency?: InputMaybe<Scalars['String']['input']>;
  currentNumber?: InputMaybe<Scalars['Float']['input']>;
  fixedAmountId?: InputMaybe<Scalars['String']['input']>;
  lastNumber?: InputMaybe<Scalars['Float']['input']>;
  maintenanceAmount?: InputMaybe<Scalars['Float']['input']>;
  maintenanceFixedAmountId?: InputMaybe<Scalars['String']['input']>;
  sumAmount?: InputMaybe<Scalars['Float']['input']>;
  sumUnitAmount?: InputMaybe<Scalars['Float']['input']>;
  unitAmount?: InputMaybe<Scalars['Float']['input']>;
};

export type UpdateLeasingBatchWaterDto = {
  _id: Scalars['String']['input'];
  name?: InputMaybe<Scalars['String']['input']>;
  note?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateLeasingBatchWaterDtoResponse = {
  __typename?: 'UpdateLeasingBatchWaterDtoResponse';
  leasingBatchWater?: Maybe<LeasingBatchWaterType>;
};

export type UpdateLeasingElectricDto = {
  _id: Scalars['String']['input'];
  electricId?: InputMaybe<Scalars['String']['input']>;
  electricityConversionFee?: InputMaybe<Scalars['Float']['input']>;
  fixedAmountId?: InputMaybe<Scalars['String']['input']>;
  lastNumber?: InputMaybe<Scalars['Int']['input']>;
  leasingIndexId?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateLeasingElectricDtoResponse = {
  __typename?: 'UpdateLeasingElectricDtoResponse';
  leasingElectric?: Maybe<LeasingElectricType>;
};

export type UpdateLeasingIndexDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
  contractCategory?: InputMaybe<Scalars['String']['input']>;
  contractNo?: InputMaybe<Scalars['String']['input']>;
  customerId?: InputMaybe<Scalars['String']['input']>;
  endedAt?: InputMaybe<Scalars['String']['input']>;
  endedPayAt?: InputMaybe<Scalars['String']['input']>;
  fileUrl?: InputMaybe<Scalars['String']['input']>;
  installment?: InputMaybe<Array<InputMaybe<CreateLeasingInstallmentInput>>>;
  order?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  paymentMethod?: InputMaybe<Scalars['String']['input']>;
  shopCategoryId?: InputMaybe<Scalars['String']['input']>;
  shopName?: InputMaybe<Scalars['String']['input']>;
  startedAt?: InputMaybe<Scalars['String']['input']>;
  sum?: InputMaybe<CreateLeasingSumDto>;
};

export type UpdateLeasingIndexDtoResponse = {
  __typename?: 'UpdateLeasingIndexDtoResponse';
  leasingIndex?: Maybe<LeasingIndexType>;
};

export type UpdateLeasingWaterDto = {
  _id: Scalars['String']['input'];
  fixedAmountId?: InputMaybe<Scalars['String']['input']>;
  lastNumber?: InputMaybe<Scalars['Float']['input']>;
  leasingIndexId?: InputMaybe<Scalars['String']['input']>;
  maintenanceFixedAmountId?: InputMaybe<Scalars['String']['input']>;
  waterId?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateLeasingWaterDtoResponse = {
  __typename?: 'UpdateLeasingWaterDtoResponse';
  leasingWater?: Maybe<LeasingWaterType>;
};

export type UpdateMmsUserDto = {
  _id: Scalars['String']['input'];
  buId?: InputMaybe<Scalars['String']['input']>;
  empId?: InputMaybe<Scalars['String']['input']>;
  permission?: InputMaybe<Array<InputMaybe<UserPermissionInputType>>>;
  roleName?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateMmsUserDtoResponse = {
  __typename?: 'UpdateMMSUserDtoResponse';
  user?: Maybe<MmsUserType>;
};

export type UpdateRejectCancelLeasingIndexDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateRejectCancelLeasingIndexDtoResponse = {
  __typename?: 'UpdateRejectCancelLeasingIndexDtoResponse';
  leasingIndex?: Maybe<LeasingIndexType>;
};

export type UpdateRejectEditActivedLeasingIndexDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateRejectEditActivedLeasingIndexDtoResponse = {
  __typename?: 'UpdateRejectEditActivedLeasingIndexDtoResponse';
  leasingIndex?: Maybe<LeasingIndexType>;
};

export type UpdateRejectLeasingBatchElectricDto = {
  _id: Scalars['String']['input'];
};

export type UpdateRejectLeasingBatchElectricDtoResponse = {
  __typename?: 'UpdateRejectLeasingBatchElectricDtoResponse';
  leasingBatchElectric?: Maybe<LeasingBatchElectricType>;
};

export type UpdateRejectLeasingBatchWaterDto = {
  _id: Scalars['String']['input'];
};

export type UpdateRejectLeasingBatchWaterDtoResponse = {
  __typename?: 'UpdateRejectLeasingBatchWaterDtoResponse';
  leasingBatchWater?: Maybe<LeasingBatchWaterType>;
};

export type UpdateRejectLeasingIndexDto = {
  _id?: InputMaybe<Scalars['String']['input']>;
  note?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateRejectLeasingIndexDtoResponse = {
  __typename?: 'UpdateRejectLeasingIndexDtoResponse';
  leasingIndex?: Maybe<LeasingIndexType>;
};

export type UpdateRoomAreaCategoryDto = {
  _id: Scalars['String']['input'];
  name?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateRoomAreaCategoryDtoResponse = {
  __typename?: 'UpdateRoomAreaCategoryDtoResponse';
  roomAreaCategory?: Maybe<RoomAreaCategoryType>;
};

export type UpdateRoomAreaDto = {
  _id: Scalars['String']['input'];
  agentHoldStatus?: InputMaybe<Scalars['String']['input']>;
  agentObject?: InputMaybe<CreateAreaOwnershipAgentInput>;
  amount?: InputMaybe<Scalars['Float']['input']>;
  buyerObject?: InputMaybe<CreateAreaOwnershipInput>;
  centralAmount?: InputMaybe<Scalars['Float']['input']>;
  currency?: InputMaybe<Scalars['String']['input']>;
  holdStatus?: InputMaybe<Scalars['String']['input']>;
  long?: InputMaybe<Scalars['Float']['input']>;
  moreArea?: InputMaybe<Scalars['Float']['input']>;
  name?: InputMaybe<Scalars['String']['input']>;
  roomAreaCategoryId?: InputMaybe<Scalars['String']['input']>;
  totalAmount?: InputMaybe<Scalars['Float']['input']>;
  totalArea?: InputMaybe<Scalars['Float']['input']>;
  totalAreaAmount?: InputMaybe<Scalars['Float']['input']>;
  totalAreaCentralAmount?: InputMaybe<Scalars['Float']['input']>;
  wide?: InputMaybe<Scalars['Float']['input']>;
  zoneId?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateRoomAreaDtoResponse = {
  __typename?: 'UpdateRoomAreaDtoResponse';
  roomArea?: Maybe<RoomAreaType>;
};

export type UpdateServiceAccountProfileByAdminDto = {
  address?: InputMaybe<Scalars['String']['input']>;
  district?: InputMaybe<Scalars['String']['input']>;
  firstName: Scalars['String']['input'];
  image?: InputMaybe<ServiceAccountProfileImageInput>;
  lastName?: InputMaybe<Scalars['String']['input']>;
  postcode?: InputMaybe<Scalars['String']['input']>;
  province?: InputMaybe<Scalars['String']['input']>;
  serviceAccountId: Scalars['String']['input'];
  village?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateServiceAccountProfileByAdminDtoResponse = {
  __typename?: 'UpdateServiceAccountProfileByAdminDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type UpdateServiceAccountProfileDto = {
  address?: InputMaybe<Scalars['String']['input']>;
  district?: InputMaybe<Scalars['String']['input']>;
  firstName?: InputMaybe<Scalars['String']['input']>;
  image?: InputMaybe<ServiceAccountProfileImageInput>;
  lastName?: InputMaybe<Scalars['String']['input']>;
  postcode?: InputMaybe<Scalars['String']['input']>;
  province?: InputMaybe<Scalars['String']['input']>;
  village?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateServiceAccountProfileDtoResponse = {
  __typename?: 'UpdateServiceAccountProfileDtoResponse';
  serviceAccount?: Maybe<ServiceAccountType>;
};

export type UpdateShopCategoryDto = {
  _id: Scalars['String']['input'];
  name?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateShopCategoryDtoResponse = {
  __typename?: 'UpdateShopCategoryDtoResponse';
  shopCategory?: Maybe<ShopCategoryType>;
};

export type UpdateSubmitLeasingBatchElectricDto = {
  _id: Scalars['String']['input'];
};

export type UpdateSubmitLeasingBatchElectricDtoResponse = {
  __typename?: 'UpdateSubmitLeasingBatchElectricDtoResponse';
  leasingBatchElectric?: Maybe<LeasingBatchElectricType>;
};

export type UpdateSubmitLeasingBatchWaterDto = {
  _id: Scalars['String']['input'];
};

export type UpdateSubmitLeasingBatchWaterDtoResponse = {
  __typename?: 'UpdateSubmitLeasingBatchWaterDtoResponse';
  leasingBatchWater?: Maybe<LeasingBatchWaterType>;
};

export type UpdateUserProfileByAdminDto = {
  address?: InputMaybe<Scalars['String']['input']>;
  district?: InputMaybe<Scalars['String']['input']>;
  firstName?: InputMaybe<Scalars['String']['input']>;
  image?: InputMaybe<UserProfileImageInput>;
  lastName?: InputMaybe<Scalars['String']['input']>;
  postcode?: InputMaybe<Scalars['String']['input']>;
  province?: InputMaybe<Scalars['String']['input']>;
  userId: Scalars['String']['input'];
  village?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateUserProfileByAdminDtoResponse = {
  __typename?: 'UpdateUserProfileByAdminDtoResponse';
  user?: Maybe<UserType>;
};

export type UpdateUserProfileDto = {
  address?: InputMaybe<Scalars['String']['input']>;
  district?: InputMaybe<Scalars['String']['input']>;
  firstName: Scalars['String']['input'];
  image?: InputMaybe<UserProfileImageInput>;
  lastName: Scalars['String']['input'];
  postcode?: InputMaybe<Scalars['String']['input']>;
  province?: InputMaybe<Scalars['String']['input']>;
  village?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateUserProfileDtoResponse = {
  __typename?: 'UpdateUserProfileDtoResponse';
  user?: Maybe<UserType>;
};

export type UpdateWaterDto = {
  _id: Scalars['String']['input'];
  name?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateWaterDtoResponse = {
  __typename?: 'UpdateWaterDtoResponse';
  water?: Maybe<WaterType>;
};

export type UpdateZoneDto = {
  _id: Scalars['String']['input'];
  name?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateZoneDtoResponse = {
  __typename?: 'UpdateZoneDtoResponse';
  zone?: Maybe<ZoneType>;
};

export type UpgradePersonalEmployeeByAdminDto = {
  userId: Scalars['String']['input'];
};

export type UpgradePersonalEmployeeByAdminDtoResponse = {
  __typename?: 'UpgradePersonalEmployeeByAdminDtoResponse';
  user?: Maybe<UserType>;
};

export type UserBuSigninDto = {
  password: Scalars['String']['input'];
  username: Scalars['String']['input'];
};

export type UserBuSigninDtoResponse = {
  __typename?: 'UserBUSigninDtoResponse';
  authorization: Scalars['String']['output'];
};

export type UserBuSignupDto = {
  firstName: Scalars['String']['input'];
  lastName: Scalars['String']['input'];
  level: Scalars['String']['input'];
  password: Scalars['String']['input'];
  username: Scalars['String']['input'];
};

export type UserBuSignupDtoResponse = {
  __typename?: 'UserBUSignupDtoResponse';
  user?: Maybe<UserType>;
};

export type UserConfigType = {
  __typename?: 'UserConfigType';
  assignBy?: Maybe<Scalars['String']['output']>;
  assignDate?: Maybe<Scalars['String']['output']>;
  assignId?: Maybe<Scalars['String']['output']>;
  level?: Maybe<Scalars['String']['output']>;
};

export type UserInfoType = {
  __typename?: 'UserInfoType';
  _id?: Maybe<Scalars['String']['output']>;
  config?: Maybe<UserConfigType>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  password?: Maybe<Scalars['String']['output']>;
  phoneNumber?: Maybe<Scalars['String']['output']>;
  platform?: Maybe<Scalars['String']['output']>;
  prefix?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  username?: Maybe<Scalars['String']['output']>;
};

export type UserPermissionInputType = {
  action?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  feature?: InputMaybe<Scalars['String']['input']>;
};

export type UserProfileImageInput = {
  cover?: InputMaybe<Scalars['String']['input']>;
  profile?: InputMaybe<Scalars['String']['input']>;
};

export type UserProfileImageType = {
  __typename?: 'UserProfileImageType';
  cover?: Maybe<Scalars['String']['output']>;
  profile?: Maybe<Scalars['String']['output']>;
};

export type UserProfileType = {
  __typename?: 'UserProfileType';
  _id?: Maybe<Scalars['String']['output']>;
  address?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  district?: Maybe<Scalars['String']['output']>;
  firstName?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  image?: Maybe<UserProfileImageType>;
  isActive?: Maybe<Scalars['String']['output']>;
  lastName?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  postcode?: Maybe<Scalars['String']['output']>;
  province?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  village?: Maybe<Scalars['String']['output']>;
};

export type UserSignatureType = {
  __typename?: 'UserSignatureType';
  _id?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  ownerId?: Maybe<Scalars['String']['output']>;
  privateKey?: Maybe<Scalars['String']['output']>;
  publicKey?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  user?: Maybe<UserInfoType>;
};

export type UserSigninDto = {
  password: Scalars['String']['input'];
  phoneNumber: Scalars['String']['input'];
};

export type UserSigninDtoResponse = {
  __typename?: 'UserSigninDtoResponse';
  authorization: Scalars['String']['output'];
};

export type UserSignupDto = {
  firstName: Scalars['String']['input'];
  lastName: Scalars['String']['input'];
  password: Scalars['String']['input'];
  phoneNumber: Scalars['String']['input'];
};

export type UserSignupDtoResponse = {
  __typename?: 'UserSignupDtoResponse';
  user?: Maybe<UserType>;
};

export type UserType = {
  __typename?: 'UserType';
  user?: Maybe<UserInfoType>;
  userProfile?: Maybe<UserProfileType>;
  userSignature?: Maybe<UserSignatureType>;
};

export type UserValidateTokenDtoResponse = {
  __typename?: 'UserValidateTokenDtoResponse';
  user?: Maybe<UserType>;
};

export type WaterType = {
  __typename?: 'WaterType';
  _id?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type ZoneType = {
  __typename?: 'ZoneType';
  _id?: Maybe<Scalars['String']['output']>;
  buId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['String']['output']>;
  createdBy?: Maybe<Scalars['String']['output']>;
  isActive?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  uid?: Maybe<Scalars['String']['output']>;
  uniqueId?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['String']['output']>;
  updatedBy?: Maybe<Scalars['String']['output']>;
};

export type LoadRoomAreaQueryVariables = Exact<{
  input: LoadRoomAreaDto;
}>;


export type LoadRoomAreaQuery = { __typename?: 'Query', loadRoomArea: { __typename?: 'LoadRoomAreaDtoResponse', count?: number | null, roomArea?: Array<{ __typename?: 'RoomAreaType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null, createdBy?: string | null, updatedBy?: string | null, buId?: string | null, zoneId?: string | null, roomAreaCategoryId?: string | null, name?: string | null, wide?: number | null, long?: number | null, moreArea?: number | null, totalArea?: number | null, amount?: number | null, centralAmount?: number | null, totalAmount?: number | null, totalAreaAmount?: number | null, totalAreaCentralAmount?: number | null, currency?: string | null, holdStatus?: string | null, agentHoldStatus?: string | null, status?: string | null, zone?: { __typename?: 'ZoneType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, buId?: string | null, name?: string | null } | null, roomAreaCategory?: { __typename?: 'RoomAreaCategoryType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, name?: string | null } | null, roomAreaOwnership?: { __typename?: 'RoomAreaOwnershipType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null, buId?: string | null, roomAreaId?: string | null, firstName?: string | null, lastName?: string | null, phoneNumber?: string | null, address?: string | null, fileUrl?: string | null, status?: string | null } | null, roomAreaOwnershipAgent?: { __typename?: 'RoomAreaOwnershipAgentType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null, buId?: string | null, roomAreaId?: string | null, roomAreaOwnershipId?: string | null, status?: string | null, startedAt?: string | null, endedAt?: string | null, note?: string | null, fileUrl?: string | null } | null } | null> | null } };

export type CreateRoomAreaMutationVariables = Exact<{
  input: CreateRoomAreaDto;
}>;


export type CreateRoomAreaMutation = { __typename?: 'Mutation', createRoomArea: { __typename?: 'CreateRoomAreaDtoResponse', roomArea?: { __typename?: 'RoomAreaType', _id?: string | null, uniqueId?: number | null, uid?: string | null, name?: string | null, wide?: number | null, long?: number | null, moreArea?: number | null, totalArea?: number | null, amount?: number | null, centralAmount?: number | null, totalAmount?: number | null, totalAreaAmount?: number | null, totalAreaCentralAmount?: number | null, currency?: string | null, zoneId?: string | null, roomAreaCategoryId?: string | null, status?: string | null, holdStatus?: string | null, agentHoldStatus?: string | null, buId?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null, zone?: { __typename?: 'ZoneType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, buId?: string | null, name?: string | null } | null, roomAreaCategory?: { __typename?: 'RoomAreaCategoryType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, name?: string | null } | null, roomAreaOwnership?: { __typename?: 'RoomAreaOwnershipType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null, buId?: string | null, roomAreaId?: string | null, firstName?: string | null, lastName?: string | null, phoneNumber?: string | null, address?: string | null, fileUrl?: string | null, status?: string | null } | null, roomAreaOwnershipAgent?: { __typename?: 'RoomAreaOwnershipAgentType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null, buId?: string | null, roomAreaId?: string | null, roomAreaOwnershipId?: string | null, status?: string | null, startedAt?: string | null, endedAt?: string | null, note?: string | null, fileUrl?: string | null } | null } | null } };

export type UpdateRoomAreaMutationVariables = Exact<{
  input: UpdateRoomAreaDto;
}>;


export type UpdateRoomAreaMutation = { __typename?: 'Mutation', updateRoomArea: { __typename?: 'UpdateRoomAreaDtoResponse', roomArea?: { __typename?: 'RoomAreaType', _id?: string | null, uniqueId?: number | null, uid?: string | null, name?: string | null, wide?: number | null, long?: number | null, moreArea?: number | null, totalArea?: number | null, amount?: number | null, centralAmount?: number | null, totalAmount?: number | null, totalAreaAmount?: number | null, totalAreaCentralAmount?: number | null, currency?: string | null, zoneId?: string | null, roomAreaCategoryId?: string | null, status?: string | null, holdStatus?: string | null, agentHoldStatus?: string | null, buId?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null, zone?: { __typename?: 'ZoneType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, buId?: string | null, name?: string | null } | null, roomAreaCategory?: { __typename?: 'RoomAreaCategoryType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, name?: string | null } | null, roomAreaOwnership?: { __typename?: 'RoomAreaOwnershipType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null, buId?: string | null, roomAreaId?: string | null, firstName?: string | null, lastName?: string | null, phoneNumber?: string | null, address?: string | null, fileUrl?: string | null, status?: string | null } | null, roomAreaOwnershipAgent?: { __typename?: 'RoomAreaOwnershipAgentType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null, buId?: string | null, roomAreaId?: string | null, roomAreaOwnershipId?: string | null, status?: string | null, startedAt?: string | null, endedAt?: string | null, note?: string | null, fileUrl?: string | null } | null } | null } };

export type DeleteRoomAreaMutationVariables = Exact<{
  input: DeleteRoomAreaDto;
}>;


export type DeleteRoomAreaMutation = { __typename?: 'Mutation', deleteRoomArea: { __typename?: 'DeleteRoomAreaDtoResponse', roomArea?: { __typename?: 'RoomAreaType', _id?: string | null, uniqueId?: number | null, uid?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null } };

export type RestoreDeleteRoomAreaMutationVariables = Exact<{
  input: RestoreDeleteRoomAreaDto;
}>;


export type RestoreDeleteRoomAreaMutation = { __typename?: 'Mutation', restoreDeleteRoomArea: { __typename?: 'RestoreDeleteRoomAreaDtoResponse', roomArea?: { __typename?: 'RoomAreaType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null, createdBy?: string | null, updatedBy?: string | null, buId?: string | null, zoneId?: string | null, roomAreaCategoryId?: string | null, name?: string | null, wide?: number | null, long?: number | null, moreArea?: number | null, totalArea?: number | null, amount?: number | null, centralAmount?: number | null, totalAmount?: number | null, totalAreaAmount?: number | null, totalAreaCentralAmount?: number | null, currency?: string | null, holdStatus?: string | null, agentHoldStatus?: string | null, status?: string | null, zone?: { __typename?: 'ZoneType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, buId?: string | null, name?: string | null } | null, roomAreaCategory?: { __typename?: 'RoomAreaCategoryType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, name?: string | null } | null, roomAreaOwnership?: { __typename?: 'RoomAreaOwnershipType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null, buId?: string | null, roomAreaId?: string | null, firstName?: string | null, lastName?: string | null, phoneNumber?: string | null, address?: string | null, fileUrl?: string | null, status?: string | null } | null, roomAreaOwnershipAgent?: { __typename?: 'RoomAreaOwnershipAgentType', _id?: string | null, uniqueId?: number | null, uid?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null, buId?: string | null, roomAreaId?: string | null, roomAreaOwnershipId?: string | null, status?: string | null, startedAt?: string | null, endedAt?: string | null, note?: string | null, fileUrl?: string | null } | null } | null } };

export type LoadRoomAreaCategoryQueryVariables = Exact<{
  input: LoadRoomAreaCategoryDto;
}>;


export type LoadRoomAreaCategoryQuery = { __typename?: 'Query', loadRoomAreaCategory: { __typename?: 'LoadRoomAreaCategoryDtoResponse', count?: number | null, roomAreaCategory?: Array<{ __typename?: 'RoomAreaCategoryType', _id?: string | null, uniqueId?: number | null, uid?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null> | null } };

export type CreateRoomAreaCategoryMutationVariables = Exact<{
  input: CreateRoomAreaCategoryDto;
}>;


export type CreateRoomAreaCategoryMutation = { __typename?: 'Mutation', createRoomAreaCategory: { __typename?: 'CreateRoomAreaCategoryDtoResponse', roomAreaCategory?: { __typename?: 'RoomAreaCategoryType', _id?: string | null, uniqueId?: number | null, uid?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null } };

export type UpdateRoomAreaCategoryMutationVariables = Exact<{
  input: UpdateRoomAreaCategoryDto;
}>;


export type UpdateRoomAreaCategoryMutation = { __typename?: 'Mutation', updateRoomAreaCategory: { __typename?: 'UpdateRoomAreaCategoryDtoResponse', roomAreaCategory?: { __typename?: 'RoomAreaCategoryType', _id?: string | null, uniqueId?: number | null, uid?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null } };

export type DeleteRoomAreaCategoryMutationVariables = Exact<{
  input: DeleteRoomAreaCategoryDto;
}>;


export type DeleteRoomAreaCategoryMutation = { __typename?: 'Mutation', deleteRoomAreaCategory: { __typename?: 'DeleteRoomAreaCategoryDtoResponse', roomAreaCategory?: { __typename?: 'RoomAreaCategoryType', _id?: string | null, uniqueId?: number | null, uid?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null } };

export type RestoreDeleteRoomAreaCategoryMutationVariables = Exact<{
  input: RestoreDeleteRoomAreaCategoryDto;
}>;


export type RestoreDeleteRoomAreaCategoryMutation = { __typename?: 'Mutation', restoreDeleteRoomAreaCategory: { __typename?: 'RestoreDeleteRoomAreaCategoryDtoResponse', roomAreaCategory?: { __typename?: 'RoomAreaCategoryType', _id?: string | null, uniqueId?: number | null, uid?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null } };

export type LoadShopCategoryQueryVariables = Exact<{
  input: LoadShopCategoryDto;
}>;


export type LoadShopCategoryQuery = { __typename?: 'Query', loadShopCategory: { __typename?: 'LoadShopCategoryDtoResponse', count?: number | null, shopCategory?: Array<{ __typename?: 'ShopCategoryType', _id?: string | null, uniqueId?: number | null, uid?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null> | null } };

export type CreateShopCategoryMutationVariables = Exact<{
  input: CreateShopCategoryDto;
}>;


export type CreateShopCategoryMutation = { __typename?: 'Mutation', createShopCategory: { __typename?: 'CreateShopCategoryDtoResponse', shopCategory?: { __typename?: 'ShopCategoryType', _id?: string | null, uniqueId?: number | null, uid?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null } };

export type UpdateShopCategoryMutationVariables = Exact<{
  input: UpdateShopCategoryDto;
}>;


export type UpdateShopCategoryMutation = { __typename?: 'Mutation', updateShopCategory: { __typename?: 'UpdateShopCategoryDtoResponse', shopCategory?: { __typename?: 'ShopCategoryType', _id?: string | null, uniqueId?: number | null, uid?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null } };

export type DeleteShopCategoryMutationVariables = Exact<{
  input: DeleteShopCategoryDto;
}>;


export type DeleteShopCategoryMutation = { __typename?: 'Mutation', deleteShopCategory: { __typename?: 'DeleteShopCategoryDtoResponse', shopCategory?: { __typename?: 'ShopCategoryType', _id?: string | null, uniqueId?: number | null, uid?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null } };

export type RestoreDeleteShopCategoryMutationVariables = Exact<{
  input: RestoreDeleteShopCategoryDto;
}>;


export type RestoreDeleteShopCategoryMutation = { __typename?: 'Mutation', restoreDeleteShopCategory: { __typename?: 'RestoreDeleteShopCategoryDtoResponse', shopCategory?: { __typename?: 'ShopCategoryType', _id?: string | null, uniqueId?: number | null, uid?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null } };

export type LoadZoneQueryVariables = Exact<{
  input: LoadZoneDto;
}>;


export type LoadZoneQuery = { __typename?: 'Query', loadZone: { __typename?: 'LoadZoneDtoResponse', count?: number | null, zone?: Array<{ __typename?: 'ZoneType', _id?: string | null, uniqueId?: number | null, uid?: string | null, buId?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null> | null } };

export type CreateZoneMutationVariables = Exact<{
  input: CreateZoneDto;
}>;


export type CreateZoneMutation = { __typename?: 'Mutation', createZone: { __typename?: 'CreateZoneDtoResponse', zone?: { __typename?: 'ZoneType', _id?: string | null, uniqueId?: number | null, uid?: string | null, buId?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null } };

export type UpdateZoneMutationVariables = Exact<{
  input: UpdateZoneDto;
}>;


export type UpdateZoneMutation = { __typename?: 'Mutation', updateZone: { __typename?: 'UpdateZoneDtoResponse', zone?: { __typename?: 'ZoneType', _id?: string | null, uniqueId?: number | null, uid?: string | null, buId?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null } };

export type DeleteZoneMutationVariables = Exact<{
  input: DeleteZoneDto;
}>;


export type DeleteZoneMutation = { __typename?: 'Mutation', deleteZone: { __typename?: 'DeleteZoneDtoResponse', zone?: { __typename?: 'ZoneType', _id?: string | null, uniqueId?: number | null, uid?: string | null, name?: string | null, isActive?: string | null, updatedAt?: string | null } | null } };

export type RestoreDeleteZoneMutationVariables = Exact<{
  input: RestoreDeleteZoneDto;
}>;


export type RestoreDeleteZoneMutation = { __typename?: 'Mutation', restoreDeleteZone: { __typename?: 'RestoreDeleteZoneDtoResponse', zone?: { __typename?: 'ZoneType', _id?: string | null, uniqueId?: number | null, uid?: string | null, buId?: string | null, name?: string | null, isActive?: string | null, createdAt?: string | null, updatedAt?: string | null } | null } };


export const LoadRoomAreaDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"LoadRoomArea"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"LoadRoomAreaDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"loadRoomArea"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"count"}},{"kind":"Field","name":{"kind":"Name","value":"roomArea"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}},{"kind":"Field","name":{"kind":"Name","value":"createdBy"}},{"kind":"Field","name":{"kind":"Name","value":"updatedBy"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"zoneId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaCategoryId"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"wide"}},{"kind":"Field","name":{"kind":"Name","value":"long"}},{"kind":"Field","name":{"kind":"Name","value":"moreArea"}},{"kind":"Field","name":{"kind":"Name","value":"totalArea"}},{"kind":"Field","name":{"kind":"Name","value":"amount"}},{"kind":"Field","name":{"kind":"Name","value":"centralAmount"}},{"kind":"Field","name":{"kind":"Name","value":"totalAmount"}},{"kind":"Field","name":{"kind":"Name","value":"totalAreaAmount"}},{"kind":"Field","name":{"kind":"Name","value":"totalAreaCentralAmount"}},{"kind":"Field","name":{"kind":"Name","value":"currency"}},{"kind":"Field","name":{"kind":"Name","value":"holdStatus"}},{"kind":"Field","name":{"kind":"Name","value":"agentHoldStatus"}},{"kind":"Field","name":{"kind":"Name","value":"status"}},{"kind":"Field","name":{"kind":"Name","value":"zone"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"name"}}]}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaCategory"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"name"}}]}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaOwnership"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaId"}},{"kind":"Field","name":{"kind":"Name","value":"firstName"}},{"kind":"Field","name":{"kind":"Name","value":"lastName"}},{"kind":"Field","name":{"kind":"Name","value":"phoneNumber"}},{"kind":"Field","name":{"kind":"Name","value":"address"}},{"kind":"Field","name":{"kind":"Name","value":"fileUrl"}},{"kind":"Field","name":{"kind":"Name","value":"status"}}]}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaOwnershipAgent"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaOwnershipId"}},{"kind":"Field","name":{"kind":"Name","value":"status"}},{"kind":"Field","name":{"kind":"Name","value":"startedAt"}},{"kind":"Field","name":{"kind":"Name","value":"endedAt"}},{"kind":"Field","name":{"kind":"Name","value":"note"}},{"kind":"Field","name":{"kind":"Name","value":"fileUrl"}}]}}]}}]}}]}}]} as unknown as DocumentNode<LoadRoomAreaQuery, LoadRoomAreaQueryVariables>;
export const CreateRoomAreaDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"CreateRoomArea"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"CreateRoomAreaDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"createRoomArea"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"roomArea"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"wide"}},{"kind":"Field","name":{"kind":"Name","value":"long"}},{"kind":"Field","name":{"kind":"Name","value":"moreArea"}},{"kind":"Field","name":{"kind":"Name","value":"totalArea"}},{"kind":"Field","name":{"kind":"Name","value":"amount"}},{"kind":"Field","name":{"kind":"Name","value":"centralAmount"}},{"kind":"Field","name":{"kind":"Name","value":"totalAmount"}},{"kind":"Field","name":{"kind":"Name","value":"totalAreaAmount"}},{"kind":"Field","name":{"kind":"Name","value":"totalAreaCentralAmount"}},{"kind":"Field","name":{"kind":"Name","value":"currency"}},{"kind":"Field","name":{"kind":"Name","value":"zoneId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaCategoryId"}},{"kind":"Field","name":{"kind":"Name","value":"status"}},{"kind":"Field","name":{"kind":"Name","value":"holdStatus"}},{"kind":"Field","name":{"kind":"Name","value":"agentHoldStatus"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}},{"kind":"Field","name":{"kind":"Name","value":"zone"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"name"}}]}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaCategory"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"name"}}]}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaOwnership"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaId"}},{"kind":"Field","name":{"kind":"Name","value":"firstName"}},{"kind":"Field","name":{"kind":"Name","value":"lastName"}},{"kind":"Field","name":{"kind":"Name","value":"phoneNumber"}},{"kind":"Field","name":{"kind":"Name","value":"address"}},{"kind":"Field","name":{"kind":"Name","value":"fileUrl"}},{"kind":"Field","name":{"kind":"Name","value":"status"}}]}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaOwnershipAgent"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaOwnershipId"}},{"kind":"Field","name":{"kind":"Name","value":"status"}},{"kind":"Field","name":{"kind":"Name","value":"startedAt"}},{"kind":"Field","name":{"kind":"Name","value":"endedAt"}},{"kind":"Field","name":{"kind":"Name","value":"note"}},{"kind":"Field","name":{"kind":"Name","value":"fileUrl"}}]}}]}}]}}]}}]} as unknown as DocumentNode<CreateRoomAreaMutation, CreateRoomAreaMutationVariables>;
export const UpdateRoomAreaDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"UpdateRoomArea"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"UpdateRoomAreaDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"updateRoomArea"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"roomArea"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"wide"}},{"kind":"Field","name":{"kind":"Name","value":"long"}},{"kind":"Field","name":{"kind":"Name","value":"moreArea"}},{"kind":"Field","name":{"kind":"Name","value":"totalArea"}},{"kind":"Field","name":{"kind":"Name","value":"amount"}},{"kind":"Field","name":{"kind":"Name","value":"centralAmount"}},{"kind":"Field","name":{"kind":"Name","value":"totalAmount"}},{"kind":"Field","name":{"kind":"Name","value":"totalAreaAmount"}},{"kind":"Field","name":{"kind":"Name","value":"totalAreaCentralAmount"}},{"kind":"Field","name":{"kind":"Name","value":"currency"}},{"kind":"Field","name":{"kind":"Name","value":"zoneId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaCategoryId"}},{"kind":"Field","name":{"kind":"Name","value":"status"}},{"kind":"Field","name":{"kind":"Name","value":"holdStatus"}},{"kind":"Field","name":{"kind":"Name","value":"agentHoldStatus"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}},{"kind":"Field","name":{"kind":"Name","value":"zone"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"name"}}]}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaCategory"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"name"}}]}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaOwnership"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaId"}},{"kind":"Field","name":{"kind":"Name","value":"firstName"}},{"kind":"Field","name":{"kind":"Name","value":"lastName"}},{"kind":"Field","name":{"kind":"Name","value":"phoneNumber"}},{"kind":"Field","name":{"kind":"Name","value":"address"}},{"kind":"Field","name":{"kind":"Name","value":"fileUrl"}},{"kind":"Field","name":{"kind":"Name","value":"status"}}]}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaOwnershipAgent"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaOwnershipId"}},{"kind":"Field","name":{"kind":"Name","value":"status"}},{"kind":"Field","name":{"kind":"Name","value":"startedAt"}},{"kind":"Field","name":{"kind":"Name","value":"endedAt"}},{"kind":"Field","name":{"kind":"Name","value":"note"}},{"kind":"Field","name":{"kind":"Name","value":"fileUrl"}}]}}]}}]}}]}}]} as unknown as DocumentNode<UpdateRoomAreaMutation, UpdateRoomAreaMutationVariables>;
export const DeleteRoomAreaDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"DeleteRoomArea"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"DeleteRoomAreaDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"deleteRoomArea"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"roomArea"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<DeleteRoomAreaMutation, DeleteRoomAreaMutationVariables>;
export const RestoreDeleteRoomAreaDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"RestoreDeleteRoomArea"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"RestoreDeleteRoomAreaDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"restoreDeleteRoomArea"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"roomArea"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}},{"kind":"Field","name":{"kind":"Name","value":"createdBy"}},{"kind":"Field","name":{"kind":"Name","value":"updatedBy"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"zoneId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaCategoryId"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"wide"}},{"kind":"Field","name":{"kind":"Name","value":"long"}},{"kind":"Field","name":{"kind":"Name","value":"moreArea"}},{"kind":"Field","name":{"kind":"Name","value":"totalArea"}},{"kind":"Field","name":{"kind":"Name","value":"amount"}},{"kind":"Field","name":{"kind":"Name","value":"centralAmount"}},{"kind":"Field","name":{"kind":"Name","value":"totalAmount"}},{"kind":"Field","name":{"kind":"Name","value":"totalAreaAmount"}},{"kind":"Field","name":{"kind":"Name","value":"totalAreaCentralAmount"}},{"kind":"Field","name":{"kind":"Name","value":"currency"}},{"kind":"Field","name":{"kind":"Name","value":"holdStatus"}},{"kind":"Field","name":{"kind":"Name","value":"agentHoldStatus"}},{"kind":"Field","name":{"kind":"Name","value":"status"}},{"kind":"Field","name":{"kind":"Name","value":"zone"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"name"}}]}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaCategory"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"name"}}]}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaOwnership"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaId"}},{"kind":"Field","name":{"kind":"Name","value":"firstName"}},{"kind":"Field","name":{"kind":"Name","value":"lastName"}},{"kind":"Field","name":{"kind":"Name","value":"phoneNumber"}},{"kind":"Field","name":{"kind":"Name","value":"address"}},{"kind":"Field","name":{"kind":"Name","value":"fileUrl"}},{"kind":"Field","name":{"kind":"Name","value":"status"}}]}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaOwnershipAgent"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaId"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaOwnershipId"}},{"kind":"Field","name":{"kind":"Name","value":"status"}},{"kind":"Field","name":{"kind":"Name","value":"startedAt"}},{"kind":"Field","name":{"kind":"Name","value":"endedAt"}},{"kind":"Field","name":{"kind":"Name","value":"note"}},{"kind":"Field","name":{"kind":"Name","value":"fileUrl"}}]}}]}}]}}]}}]} as unknown as DocumentNode<RestoreDeleteRoomAreaMutation, RestoreDeleteRoomAreaMutationVariables>;
export const LoadRoomAreaCategoryDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"LoadRoomAreaCategory"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"LoadRoomAreaCategoryDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"loadRoomAreaCategory"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"count"}},{"kind":"Field","name":{"kind":"Name","value":"roomAreaCategory"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<LoadRoomAreaCategoryQuery, LoadRoomAreaCategoryQueryVariables>;
export const CreateRoomAreaCategoryDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"CreateRoomAreaCategory"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"CreateRoomAreaCategoryDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"createRoomAreaCategory"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"roomAreaCategory"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<CreateRoomAreaCategoryMutation, CreateRoomAreaCategoryMutationVariables>;
export const UpdateRoomAreaCategoryDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"UpdateRoomAreaCategory"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"UpdateRoomAreaCategoryDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"updateRoomAreaCategory"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"roomAreaCategory"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<UpdateRoomAreaCategoryMutation, UpdateRoomAreaCategoryMutationVariables>;
export const DeleteRoomAreaCategoryDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"DeleteRoomAreaCategory"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"DeleteRoomAreaCategoryDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"deleteRoomAreaCategory"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"roomAreaCategory"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<DeleteRoomAreaCategoryMutation, DeleteRoomAreaCategoryMutationVariables>;
export const RestoreDeleteRoomAreaCategoryDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"RestoreDeleteRoomAreaCategory"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"RestoreDeleteRoomAreaCategoryDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"restoreDeleteRoomAreaCategory"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"roomAreaCategory"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<RestoreDeleteRoomAreaCategoryMutation, RestoreDeleteRoomAreaCategoryMutationVariables>;
export const LoadShopCategoryDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"LoadShopCategory"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"LoadShopCategoryDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"loadShopCategory"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"count"}},{"kind":"Field","name":{"kind":"Name","value":"shopCategory"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<LoadShopCategoryQuery, LoadShopCategoryQueryVariables>;
export const CreateShopCategoryDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"CreateShopCategory"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"CreateShopCategoryDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"createShopCategory"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"shopCategory"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<CreateShopCategoryMutation, CreateShopCategoryMutationVariables>;
export const UpdateShopCategoryDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"UpdateShopCategory"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"UpdateShopCategoryDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"updateShopCategory"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"shopCategory"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<UpdateShopCategoryMutation, UpdateShopCategoryMutationVariables>;
export const DeleteShopCategoryDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"DeleteShopCategory"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"DeleteShopCategoryDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"deleteShopCategory"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"shopCategory"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<DeleteShopCategoryMutation, DeleteShopCategoryMutationVariables>;
export const RestoreDeleteShopCategoryDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"RestoreDeleteShopCategory"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"RestoreDeleteShopCategoryDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"restoreDeleteShopCategory"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"shopCategory"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<RestoreDeleteShopCategoryMutation, RestoreDeleteShopCategoryMutationVariables>;
export const LoadZoneDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"LoadZone"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"LoadZoneDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"loadZone"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"count"}},{"kind":"Field","name":{"kind":"Name","value":"zone"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<LoadZoneQuery, LoadZoneQueryVariables>;
export const CreateZoneDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"CreateZone"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"CreateZoneDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"createZone"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"zone"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<CreateZoneMutation, CreateZoneMutationVariables>;
export const UpdateZoneDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"UpdateZone"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"UpdateZoneDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"updateZone"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"zone"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<UpdateZoneMutation, UpdateZoneMutationVariables>;
export const DeleteZoneDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"DeleteZone"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"DeleteZoneDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"deleteZone"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"zone"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<DeleteZoneMutation, DeleteZoneMutationVariables>;
export const RestoreDeleteZoneDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"RestoreDeleteZone"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"RestoreDeleteZoneDto"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"restoreDeleteZone"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"zone"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}},{"kind":"Field","name":{"kind":"Name","value":"uniqueId"}},{"kind":"Field","name":{"kind":"Name","value":"uid"}},{"kind":"Field","name":{"kind":"Name","value":"buId"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"isActive"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"updatedAt"}}]}}]}}]}}]} as unknown as DocumentNode<RestoreDeleteZoneMutation, RestoreDeleteZoneMutationVariables>;