// 'use client';
// // Next Imports
// import { useParams } from 'next/navigation';

// // MUI Imports
// import { useTheme } from '@mui/material/styles';

// // Third-party Imports
// import PerfectScrollbar from 'react-perfect-scrollbar';

// // Type Imports
// import type { getDictionary } from '@/utils/getDictionary';
// import type { VerticalMenuContextProps } from '@menu/components/vertical-menu/Menu';

// // Component Imports
// import { Menu, SubMenu, MenuItem, MenuSection } from '@menu/vertical-menu';

// // import { GenerateVerticalMenu } from '@components/GenerateMenu'

// // Hook Imports
// import useVerticalNav from '@menu/hooks/useVerticalNav';

// // Styled Component Imports
// import StyledVerticalNavExpandIcon from '@menu/styles/vertical/StyledVerticalNavExpandIcon';

// // Style Imports
// import menuItemStyles from '@core/styles/vertical/menuItemStyles';
// import menuSectionStyles from '@core/styles/vertical/menuSectionStyles';
// import { useLazyQuery } from '@apollo/client';
// import { useRoleStore } from '@/views/role/store/roleStore';
// import React, { useEffect } from 'react';
// import { useSession } from 'next-auth/react';
// import SkeletonLoader from '@/components/loading/list/ListLoader';
// import { Typography } from '@mui/material';
// import { RoleMenu } from '@/gql/models/graphql';

// // Menu Data Imports
// // import menuData from '@/data/navigation/verticalMenuData'

// type RenderExpandIconProps = {
//   open?: boolean;
//   transitionDuration?: VerticalMenuContextProps['transitionDuration'];
// };

// type Props = {
//   dictionary: Awaited<ReturnType<typeof getDictionary>>;
//   scrollMenu: (container: any, isPerfectScrollbar: boolean) => void;
//   lang: string;
// };

// const RenderExpandIcon = ({
//   open,
//   transitionDuration,
// }: RenderExpandIconProps) => (
//   <StyledVerticalNavExpandIcon
//     open={open}
//     transitionDuration={transitionDuration}
//   >
//     <i className="tabler-chevron-right" />
//   </StyledVerticalNavExpandIcon>
// );

// const VerticalMenu = ({ dictionary, scrollMenu, lang }: Props) => {
//   // Hooks
//   const session = useSession();

//   const theme = useTheme();
//   const verticalNavOptions = useVerticalNav();
//   const params = useParams();
//   const { isBreakpointReached } = useVerticalNav();

//   // Vars
//   const { transitionDuration } = verticalNavOptions;
//   // const { lang: locale } = params;
//   const locale = (params?.lang as string) || lang;
//   const ScrollWrapper = isBreakpointReached ? 'div' : PerfectScrollbar;
//   // hook
//   const { queryRoleById, role, loading } = useRoleStore();

//   useEffect(() => {
//     if (session) {
//       const roleId = session.data?.user?.level + '';
//       if (roleId !== '') {
//         queryRoleById({
//           props: { queryRoles: '', dictionary: dictionary },
//           id: roleId,
//         });
//       }
//     }
//   }, [session, queryRoleById, dictionary]);

//   // Group items by `menuSection`
//   const menuBySection = role?.menus?.reduce(
//     (acc, item) => {
//       const section = item?.enSection || 'other';
//       acc[section] = [...(acc[section] || []), item];
//       return acc;
//     },
//     {} as Record<string, RoleMenu[]>
//   );

//   // Render the menu content
//   const renderMenuContent = () => (
//     <Menu
//       popoutMenuOffset={{ mainAxis: 23 }}
//       menuItemStyles={menuItemStyles(verticalNavOptions, theme)}
//       renderExpandIcon={({ open }) => (
//         <RenderExpandIcon open={open} transitionDuration={transitionDuration} />
//       )}
//       renderExpandedMenuItemIcon={{
//         icon: <i className="tabler-circle text-xs" />,
//       }}
//       menuSectionStyles={menuSectionStyles(verticalNavOptions, theme)}
//     >
//       {Object.entries(menuBySection ?? {}).map(([section, items]) => (
//         <React.Fragment key={section}>
//           {section === 'other' ? (
//             items.map((item) => (
//               <MenuItem
//                 key={item.href}
//                 href={`/${locale}${item.href}`}
//                 icon={<i className={item.icon ?? 'tabler-circle-dot-filled'} />}
//               >
//                 {lang.startsWith('la')
//                   ? item.laMenu ?? '*'
//                   : item.enMenu ?? '*'}
//               </MenuItem>
//             ))
//           ) : (
//             <>
//               {items?.map((item) =>
//                 item?.subMenu?.length ? (
//                   <>
//                     <SubMenu
//                       key={item.href}
//                       label={
//                         lang.startsWith('la')
//                           ? item.laSection ?? '*'
//                           : item.enSection ?? '*'
//                       }
//                       icon={
//                         <i
//                           className={item.icon ?? 'tabler-circle-dot-filled'}
//                         />
//                       }
//                     >
//                       {item.subMenu.map((subItem) => (
//                         <MenuItem
//                           key={subItem?.href ?? 'sub'}
//                           href={`/${locale}${subItem?.href}`}
//                         >
//                           {lang.startsWith('la')
//                             ? subItem?.laMenu ?? '*'
//                             : subItem?.enMenu ?? '*'}
//                         </MenuItem>
//                       ))}
//                     </SubMenu>
//                   </>
//                 ) : (
//                   <MenuItem
//                     key={item.href}
//                     href={`/${locale}${item.href}`}
//                     icon={
//                       <i className={item.icon ?? 'tabler-circle-dot-filled'} />
//                     }
//                   >
//                     {lang.startsWith('la')
//                       ? item?.laMenu ?? '*'
//                       : item?.enMenu ?? '*'}
//                   </MenuItem>
//                 )
//               )}
//             </>
//           )}
//         </React.Fragment>
//       ))}
//     </Menu>
//   );
//   if (loading) {
//     return <SkeletonLoader />;
//   } else {
//     return (
//       <ScrollWrapper
//         {...(isBreakpointReached
//           ? {
//               className: 'bs-full overflow-y-auto overflow-x-hidden',
//               onScroll: (container) => scrollMenu(container, false),
//             }
//           : {
//               options: { wheelPropagation: false, suppressScrollX: true },
//               onScrollY: (container) => scrollMenu(container, true),
//             })}
//       >
//         {role != null ? (
//           renderMenuContent()
//         ) : (
//           <Typography
//             textAlign={'center'}
//             alignSelf={'center'}
//             padding={'20px'}
//           >
//             {dictionary.noMenuDataAvailable}
//           </Typography>
//         )}
//       </ScrollWrapper>
//     );
//   }
// };

// export default VerticalMenu;
