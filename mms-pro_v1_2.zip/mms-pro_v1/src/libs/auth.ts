// Third-party Imports
import CredentialProvider from "next-auth/providers/credentials";
import GoogleProvider from "next-auth/providers/google";
import { PrismaAdapter } from "@auth/prisma-adapter";
import { PrismaClient } from "@prisma/client";
import type { LoginData, TokenData, NextAuthOptions, UserLoginData } from "next-auth";
import type { Adapter } from "next-auth/adapters";

const prisma = new PrismaClient();
// API Configuration with fallback
const urlLaoWorld = process.env.NEXT_PUBLIC_API_URL;



const loginQuery = `
  query Login($input: LoginDto!) {
    login(input: $input) {
      _id
      token
      refreshToken
    }
  }
`;

const loadUserRoleQuery = `
  query LoadUserRole {
    loadUserRole {
      user {
        permission {
          action
          feature
        }
        roleName
      }
    }
  }
`;

// Old queries - ไม่ใช้แล้ว
// const loadUserDetailQuery = `...`;
// const loginMutation = `...`;

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma) as Adapter,
  providers: [
    CredentialProvider({
      name: "Credentials",
      type: "credentials",
      credentials: {
        username: { label: "Username", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const { username, password } = credentials as {
          username: string;
          password: string;
        };
        // console.log(`---, username`, username);
        // console.log(`--- password`, password);
        // console.log(`API URL::`, urlLaoWorld);

        if (!urlLaoWorld) {
          throw new Error("API URL is not configured");
        }

        try {
          // Step 1: Login with new Login query
          let response = await fetch(urlLaoWorld, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              platform: "mms_svc",
            },
            body: JSON.stringify({
              query: loginQuery,
              variables: {
                input: {
                  userName: username,
                  password: password,
                },
              },
            }),
          });

          let result = await response.json();
          console.log(`:::: login`, result);

          // ตรวจสอบว่า login สำเร็จและได้ token
          if (!result.data?.login?.token)
            throw new Error("Invalid credentials");

          const { _id, token, refreshToken } = result.data.login;
          console.log(`Login successful:`, { _id, token, refreshToken });

          // Return user data with new token format
          return {
            id: _id || username,
            user: {
              prefix: username,
              username: username,
              fNameLa: "",
              lNameLa: "",
              fNameEn: "",
              lNameEn: "",
              level: "",
              business: null,
            },
            authorization: token,
            token: token,
            refreshToken: refreshToken,
            userId: _id,
          };
        } catch (e: any) {
          throw new Error(e.message);
        }
      },
    }),

    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID as string,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET as string,
    }),
  ],
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // ** 30 days
  },

  pages: {
    signIn: "/login",
  },

  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        var usrs: LoginData = user as LoginData;
        token.user = usrs.user;
        token.authorization = usrs.authorization;

        if (urlLaoWorld && usrs.authorization) {
          try {
            const roleRes = await fetch(urlLaoWorld, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                platform: "mms_svc",
                Authorization: `Bearer ${usrs.authorization}`,
              },
              body: JSON.stringify({
                query: loadUserRoleQuery,
              }),
            });

            const roleResult = await roleRes.json();
            const roleData = roleResult?.data?.loadUserRole?.user;

            if (roleData) {
              if (token.user) {
                (token.user as UserLoginData).roleName = roleData.roleName;
                (token.user as UserLoginData).permission = roleData.permission;
                console.log("::: User Role Fetched & Assigned :::", {
                  roleName: roleData.roleName,
                  permissionCount: roleData.permission?.length
                });
              }
            }
          } catch (error) {
            console.log("Error fetching user role:", error);
          }
        }
      }
      return token;
    },
    async session({ session, token }) {
      var tkn: TokenData = token as TokenData;
      session.user = tkn.user;
      session.authorization = tkn.authorization;
      return session;
    },
  },
};
