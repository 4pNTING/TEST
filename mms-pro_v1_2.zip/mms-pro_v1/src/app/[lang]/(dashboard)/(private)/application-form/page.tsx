// MUI Imports
import Grid from '@mui/material/Grid'

// Component Imports

// Server Action Imports
import { getServerMode } from '@core/utils/serverHelpers'

const ApplicationFormPage = () => {
    // Vars
    const serverMode = getServerMode()
    return (
        <Grid container spacing={6}>
            <Grid item xs={12}>
                <>KKKK</>
            </Grid>
        </Grid>
    )
}

export default ApplicationFormPage
