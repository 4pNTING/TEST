// MUI Imports
import Grid from '@mui/material/Grid'

// Server Action Imports
import { Locale } from '@/configs/i18n'
import { getDictionary } from '@/utils/getDictionary'
import ChangePassword from '@/views/change-password/view/ChangePassword'

const ChangePasswordPage = async ({ params }: { params: { lang: Locale } }) => {
    // Vars
    const dictionary = await getDictionary(params.lang)
    return (
        <Grid container spacing={6}>
            <Grid item xs={12}>
                <ChangePassword props={{ lang: params.lang, dictionary: dictionary }} />
            </Grid>
        </Grid>
    )
}

export default ChangePasswordPage
