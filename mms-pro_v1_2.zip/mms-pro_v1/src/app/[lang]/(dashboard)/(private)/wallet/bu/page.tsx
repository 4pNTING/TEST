export default function BUPage() {
  return null;
}
