import Grid from '@mui/material/Grid';
import { getDictionary } from '@/utils/getDictionary';
import type { Locale } from '@/configs/i18n';
import PageRender from '@/views/leasingElectric/list/electricList';

export default async function LeasingElectricPage({ params }: { params: { lang: Locale } }) {
  const dictionary = await getDictionary(params.lang);
  return (
    <Grid container spacing={6}>
      <Grid item xs={12}>
        <PageRender props={{ lang: params.lang, dictionary }} />
      </Grid> 
    </Grid>
  );
}
