// import { CustomerType } from './customerService';
// import { ProvinceApiService } from './provinceService';
// import { DistrictApiService } from './districtService';
// import { VillageApiService } from './villageService';

// /**
//  * Get full address string in Lao
//  */
// export const getFullAddressLao = async (customer: CustomerType): Promise<string> => {
//   const [province, district, village] = await Promise.all([
//     ProvinceApiService.getProvinceById(customer.provinceId),
//     DistrictApiService.getDistrictById(customer.districtId),
//     VillageApiService.getVillageById(customer.villageId)
//   ]);
  
//   const parts = [
//     village?.nameLao,
//     district?.nameLao,
//     province?.nameLao
//   ].filter(Boolean);
  
//   return parts.join(', ');
// };

// /**
//  * Get customer full name in Lao
//  */
// export const getCustomerFullNameLao = (customer: CustomerType): string => {
//   return `${customer.firstNameLao} ${customer.lastNameLao}`.trim();
// };

// /**
//  * Get age from birth date
//  */
// export const getAge = (birthDate: string): number => {
//   const birth = new Date(birthDate);
//   const today = new Date();
//   let age = today.getFullYear() - birth.getFullYear();
//   const monthDiff = today.getMonth() - birth.getMonth();
  
//   if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
//     age--;
//   }
  
//   return age;
// };

// /**
//  * Validate customer data before create/update
//  */
// export const validateCustomerData = (customerData: Partial<CustomerType>): string[] => {
//   const errors: string[] = [];
  
//   if (!customerData.mainId?.trim()) {
//     errors.push('Main ID is required');
//   }
  
//   if (!customerData.firstNameLao?.trim()) {
//     errors.push('First name in Lao is required');
//   }
  
//   if (!customerData.phoneNumber?.trim()) {
//     errors.push('Phone number is required');
//   }
  
//   // เพิ่ม validation อื่นๆ ตามต้องการ...
  
//   return errors;
// };