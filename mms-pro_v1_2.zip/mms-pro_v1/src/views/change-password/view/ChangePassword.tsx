'use client'

// React Imports
import { useState } from 'react'

// MUI Imports
import Card from '@mui/material/Card'
import CardHeader from '@mui/material/CardHeader'
import CardContent from '@mui/material/CardContent'
import Grid from '@mui/material/Grid'
import InputAdornment from '@mui/material/InputAdornment'
import IconButton from '@mui/material/IconButton'
import Typography from '@mui/material/Typography'
import Button from '@mui/material/Button'

//Component Imports
import CustomTextField from '@core/components/mui/TextField'
import { PageDefaultProps } from '@/types/pageDefaultTypes'
import { Controller, useForm } from 'react-hook-form'
import { FormChangePasswordType } from '../type/changePasswordTypes'
import { useChangePasswordStore } from '../store/changePasswordStore'
import { useMutation } from '@apollo/client'
// import { EMPLOYEE_CHANGE_PASSWORD } from '@/gql/queries/employee'
import { signOut } from 'next-auth/react'

const initialData = {
    currentPassword: "",
    newPassword: "",
    confirmNewPassword: "",
};


const ChangePasswordCard = ({ props }: { props: PageDefaultProps }) => {
    // const [mutateChangePassword] = useMutation(EMPLOYEE_CHANGE_PASSWORD);
    // Props
    const { changePassword, loading } = useChangePasswordStore();
    // 
    const { dictionary: dic } = props;
    // States
    const [isCurrentPasswordShown, setIsCurrentPasswordShown] = useState(false)
    const [isConfirmPasswordShown, setIsConfirmPasswordShown] = useState(false)
    const [isNewPasswordShown, setIsNewPasswordShown] = useState(false)

    // Status

    const {
        control,
        handleSubmit,
        getValues,
        reset,
        formState: { errors },
    } = useForm<FormChangePasswordType>({
        defaultValues: initialData,
        mode: "onChange",
        reValidateMode: "onChange",
    });

    const validatePassword = (value: string) => {
        const minLength = value.length >= 6;
        const hasNumber = /\d/.test(value);
        if (!minLength) {
            return dic.passwordMustSix;
        }
        if (!hasNumber) {
            return dic.passwordMustAtLeastOneNum;
        }
        return true;
    };

    const validatePasswordConfirm = (value: string) => {
        const newPassword = getValues("newPassword");
        if (value !== newPassword) {
            return dic.confirmPasswordsDoNotMatch;
        }

        return true;
    };


    const onSubmit = (data: FormChangePasswordType) => {
        // changePassword({ form: data, props: { mutateChangePassword: mutateChangePassword, dictionary: dic, onSuccess: () => signOut({ callbackUrl: '/login' }) } });
    };

    const validateHasSix = (value: string) => {
        const minLength = value.length >= 6;
        if (!minLength) {
            return false;
        }
        return true;
    };

    const validateHasOneNum = (value: string) => {
        const hasNumber = /\d/.test(value);
        if (!hasNumber) {
            return false;
        }
        return true;
    };


    const hasSix = validateHasSix(getValues("newPassword"))
    const hasOneNum = validateHasOneNum(getValues("newPassword"))

    return (
        <Card>
            <CardHeader
                avatar={
                    <i className={'tabler-lock-cog text-2xl'} />
                }
                title={dic.changeNewPassword}
                titleTypographyProps={{
                    marginTop: "5px",
                    fontSize: "18px",
                    fontWeight: 500,
                }}
            />
            <CardContent>
                <form onSubmit={handleSubmit(onSubmit)}>
                    <Grid container spacing={6}>
                        <Grid item xs={12} sm={6}>
                            <Controller
                                name={'currentPassword'}
                                control={control}
                                rules={{
                                    required: true,
                                }}
                                render={({ field, fieldState: { error } }) => (
                                    <CustomTextField
                                        {...field}
                                        fullWidth
                                        disabled={loading}
                                        label={dic.currentPassword}
                                        type={isCurrentPasswordShown ? "text" : "password"}
                                        placeholder="············"
                                        InputProps={{
                                            endAdornment: (
                                                <InputAdornment position="end">
                                                    <IconButton
                                                        edge="end"
                                                        onClick={() => setIsCurrentPasswordShown(!isCurrentPasswordShown)}
                                                        onMouseDown={(e) => e.preventDefault()}
                                                    >
                                                        <i
                                                            className={isCurrentPasswordShown ? "tabler-eye-off" : "tabler-eye"}
                                                        />
                                                    </IconButton>
                                                </InputAdornment>
                                            ),
                                        }}
                                        {...(errors.currentPassword && { error: true, helperText: dic.thisFieldIsRequiredExclamination })}
                                    />
                                )}
                            />
                        </Grid>
                    </Grid>
                    <Grid container className='mbs-0' spacing={6}>
                        <Grid item xs={12} sm={6}>
                            <Controller
                                name="newPassword"
                                control={control}
                                rules={{
                                    validate: validatePassword,
                                }}
                                render={({ field, fieldState: { error } }) => (
                                    <CustomTextField
                                        {...field}
                                        fullWidth
                                        disabled={loading}
                                        label={dic.newPassword}
                                        type={isNewPasswordShown ? "text" : "password"}
                                        placeholder="············"
                                        InputProps={{
                                            endAdornment: (
                                                <InputAdornment position="end">
                                                    <IconButton
                                                        edge="end"
                                                        onClick={() => setIsNewPasswordShown(!isNewPasswordShown)}
                                                        onMouseDown={(e) => e.preventDefault()}
                                                    >
                                                        <i
                                                            className={isNewPasswordShown ? "tabler-eye-off" : "tabler-eye"}
                                                        />
                                                    </IconButton>
                                                </InputAdornment>
                                            ),
                                        }}
                                        error={!!error}
                                        helperText={error?.message}
                                    />
                                )}
                            />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                            <Controller
                                name={'confirmNewPassword'}
                                control={control}
                                rules={{
                                    validate: validatePasswordConfirm,
                                }}
                                render={({ field, fieldState: { error } }) => (
                                    <CustomTextField
                                        {...field}
                                        fullWidth
                                        disabled={loading}
                                        label={dic.confirmNewPassword}
                                        type={isConfirmPasswordShown ? "text" : "password"}
                                        placeholder="············"
                                        InputProps={{
                                            endAdornment: (
                                                <InputAdornment position="end">
                                                    <IconButton
                                                        edge="end"
                                                        onClick={() => setIsConfirmPasswordShown(!isConfirmPasswordShown)}
                                                        onMouseDown={(e) => e.preventDefault()}
                                                    >
                                                        <i
                                                            className={isConfirmPasswordShown ? "tabler-eye-off" : "tabler-eye"}
                                                        />
                                                    </IconButton>
                                                </InputAdornment>
                                            ),
                                        }}
                                        error={!!error}
                                        helperText={error?.message}
                                    />
                                )}
                            />

                        </Grid>
                        <Grid item xs={12} className='flex flex-col gap-4'>
                            <Typography variant='h6'>{dic.passwordRequirements}:</Typography>
                            <div className='flex flex-col gap-4'>
                                <div className='flex items-center gap-2.5'>
                                    <i className={`tabler-${hasSix ? "circle-check-filled" : "circle-check"} text-base text-${hasSix ? "green" : "grey"}-500`} />
                                    <Typography className={`text-${hasSix ? "green" : "grey"}-500`}>
                                        {dic.minimum} 6 {dic.characters} - {dic.theMoreBetter}
                                    </Typography>
                                </div>
                                <div className='flex items-center gap-2.5'>
                                    <i className={`tabler-${hasOneNum ? "circle-check-filled" : "circle-check"} text-base text-${hasOneNum ? "green" : "grey"}-500`} />
                                    <Typography className={`text-${hasOneNum ? "green" : "grey"}-500`}>
                                        {dic.atLeastOneNumber}
                                    </Typography>
                                </div>
                            </div>
                        </Grid>
                        <Grid item xs={12} className='flex gap-4'>
                            <Button disabled={loading} type={'submit'}
                                startIcon={loading ? <i className="tabler-loader animate-spin text-1xl" /> : <i className={`tabler-${"check"} text-1xl`} />}
                                variant='contained'>{dic.saveChange}</Button>
                            <Button disabled={loading} onClick={() => reset(initialData)} startIcon={<i className='tabler-reload text-base' />} variant='tonal' color='secondary'>
                                {dic.reset}
                            </Button>
                        </Grid>
                    </Grid>
                </form>
            </CardContent>
        </Card>
    )
}

export default ChangePasswordCard
