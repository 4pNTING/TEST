import { getDictionary } from "@/utils/getDictionary";

export type FormChangePasswordType = {
    currentPassword: string,
    newPassword: string,
    confirmNewPassword: string,
}

export type ChangePasswordNetworkProps = {
    id?: string,
    queryChangePassword?: any,
    mutateChangePassword?: any
    startLoading?: boolean;
    dictionary: Awaited<ReturnType<typeof getDictionary>>,
    onSuccess?: Function;
    setToUpdate?: boolean,
}