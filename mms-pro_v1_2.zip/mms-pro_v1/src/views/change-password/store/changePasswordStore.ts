
import { graphErrorHelper } from '@/utils/getErrorMessage';
import { create } from 'zustand';
import { toast } from 'react-toastify';
import { ChangePasswordNetworkProps, FormChangePasswordType } from '../type/changePasswordTypes';


interface ChangePasswordState {
    loading: boolean;
    // 
    changePassword: ({ form, props }: { form: FormChangePasswordType | undefined, props: ChangePasswordNetworkProps }) => void;
}


// Create the Zustand store with the defined type
export const useChangePasswordStore = create<ChangePasswordState>((set, get) => ({
    loading: false,
    // 

    changePassword: async ({ form, props }: { form: FormChangePasswordType | undefined, props: ChangePasswordNetworkProps }) => {
        try {
            set({ loading: true });
            if (props?.mutateChangePassword === undefined) return toast.error(props.dictionary.missingGqlHook);


            const { data, error } = await props?.mutateChangePassword({
                variables: {
                    changePasswordInput: {
                        oldPassword: form?.currentPassword,
                        newPassword: form?.newPassword,
                        confirmPassword: form?.confirmNewPassword,
                    }
                }
            });

            if (data) {
                if (data?.changePassword !== null) {
                    toast.success(props.dictionary.changePasswordSuccess);
                    props.onSuccess && props.onSuccess();
                } else {
                    toast.error(props.dictionary.invalidCredentials);
                }
            } else {
                toast.error(graphErrorHelper(error));
            }

        } catch (e) {
            toast.error(graphErrorHelper(e));
        } finally {
            set({ loading: false });
        }
    }
}));