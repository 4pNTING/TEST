import { IEntityStatus, ICustomerGender, ICustomerNationality, ILeasingFileType } from "@/utils/base";
import { create } from "zustand";
import { useMutation } from "@apollo/client";
import { CreateNetworkProps, ListNetworkProps, CustomerType, CustomerInput, } from "../type/customerType";
import { MOCK_PROVINCES, MOCK_DISTRICTS, MOCK_VILLAGES, } from "@/data/mockup/locationData";
import { CREATE_CUSTOMER, UPDATE_CUSTOMER, DELETE_CUSTOMER, RESTORE_DELETE_CUSTOMER, } from "@/gql/queries/customer";
import { uploadOwnerFile } from "@/utils/fileUploadService";
import { ICustomerSortField } from "@/utils/enumSortField";

export const useCustomerMutations = () => {
  const [createCustomerMutation] = useMutation(CREATE_CUSTOMER);
  const [updateCustomerMutation] = useMutation(UPDATE_CUSTOMER);
  const [deleteCustomerMutation] = useMutation(DELETE_CUSTOMER);
  const [restoreCustomerMutation] = useMutation(RESTORE_DELETE_CUSTOMER);

  return { createCustomerMutation, updateCustomerMutation, deleteCustomerMutation, restoreCustomerMutation };
};

interface IState {
  removeListenerState: () => void;
  resetModalState: () => void;

  toggleCreateComponent: boolean;
  setToggleCreateComponent: (value: boolean) => void;

  toggleUpdateComponent: boolean;
  setToggleUpdateComponent: (value: boolean) => void;

  selectedItem: CustomerType | null;
  setSelectedItem: (item: CustomerType | null) => void;

  loading: boolean;
  setLoading: (value: boolean) => void;

  count: number;
  pageIndex: number;
  pageSize: number;
  isActive: string;
  selectedGender: string;
  selectedNationality: string;
  keyword: string;
  sortField: ICustomerSortField | null;
  sortOrder: 'ASC' | 'DESC' | null;

  setPagination: (pagination: {
    pageIndex: number;
    pageSize: number;
    isActive?: string;
    selectedGender?: string;
    selectedNationality?: string;
    keyword?: string;
    sortField?: ICustomerSortField | null;
    sortOrder?: 'ASC' | 'DESC' | null;
  }) => void;

  setSorting: (sortField: ICustomerSortField | null, sortOrder: 'ASC' | 'DESC' | null) => void;

  loadCustomerAPI: ({ props }: { props: ListNetworkProps }) => Promise<void>;
  searchCustomerAPI: ({ props, keyword }: { props: ListNetworkProps; keyword: string }) => Promise<void>;
  createCustomerAPI: ({ props }: { props: CreateNetworkProps }) => Promise<void>;
  updateCustomerAPI: ({ id, mutation, props }: { id: string; mutation: any; props: any }) => Promise<void>;
  deleteCustomerAPI: ({ id, mutation }: { id: string; mutation: any }) => Promise<void>;
  restoreCustomerAPI: ({ id, mutation }: { id: string; mutation: any }) => Promise<void>;

  customerList: CustomerType[];

  provinceList: any[];
  districtList: any[];
  villageList: any[];
  genderList: any[];
  nationList: any[];

  loadProvinceList: () => void;
  loadDistrictList: () => void;
  loadVillageList: () => void;
  loadGenderList: () => void;
  loadNationList: () => void;
}

export const useStore = create<IState>((set, get) => ({
  removeListenerState: () => {
    set({
      toggleCreateComponent: false,
      toggleUpdateComponent: false,
      selectedItem: null,
      pageIndex: 0,
      pageSize: 50,
      isActive: IEntityStatus.all,
    });
  },

  resetModalState: () => {
    set({
      toggleCreateComponent: false,
      toggleUpdateComponent: false,
      selectedItem: null,
    });
  },

  toggleCreateComponent: false,
  setToggleCreateComponent: (value: boolean) => {
    set({ toggleCreateComponent: value });
    if (!value) {
      document.body.classList.remove("overflow-hidden");
    }
  },

  toggleUpdateComponent: false,
  setToggleUpdateComponent: (value: boolean) => {
    set({ toggleUpdateComponent: value });
  },

  selectedItem: null,
  setSelectedItem: (item: CustomerType | null) => {
    set({ selectedItem: item });
  },

  loading: true,
  setLoading: (value: boolean) => {
    set({ loading: value });
  },

  count: 0,
  pageIndex: 0,
  pageSize: 50,
  isActive: IEntityStatus.all,
  selectedGender: "",
  selectedNationality: "",
  keyword: "",
  sortField: null,
  sortOrder: null,

  setPagination: (pagination) => {
    set({
      pageIndex: pagination.pageIndex,
      pageSize: pagination.pageSize,
      isActive: pagination.isActive || get().isActive,
      selectedGender: pagination.selectedGender !== undefined ? pagination.selectedGender : get().selectedGender,
      selectedNationality: pagination.selectedNationality !== undefined ? pagination.selectedNationality : get().selectedNationality,
      keyword: pagination.keyword !== undefined ? pagination.keyword : get().keyword,
      sortField: pagination.sortField !== undefined ? pagination.sortField : get().sortField,
      sortOrder: pagination.sortOrder !== undefined ? pagination.sortOrder : get().sortOrder,
    });
  },

  setSorting: (sortField, sortOrder) => {
    set({ sortField, sortOrder });
  },

  customerList: [],
  provinceList: [],
  districtList: [],
  villageList: [],
  genderList: [],
  nationList: [],

  loadProvinceList: () => {
    set({ provinceList: MOCK_PROVINCES as any });
  },

  loadDistrictList: () => {
    set({ districtList: MOCK_DISTRICTS as any });
  },

  loadVillageList: () => {
    set({ villageList: MOCK_VILLAGES as any });
  },

  loadGenderList: () => {
    const genderOptions = [
      { _id: ICustomerGender.male, laName: 'ຊາຍ', code: ICustomerGender.male },
      { _id: ICustomerGender.female, laName: 'ຍິງ', code: ICustomerGender.female },
    ];
    set({ genderList: genderOptions });
  },

  loadNationList: () => {
    const nationalityOptions = [
      { _id: ICustomerNationality.lao, laName: 'ລາວ', code: ICustomerNationality.lao },
      { _id: ICustomerNationality.chinese, laName: 'ຈີນ', code: ICustomerNationality.chinese },
      { _id: ICustomerNationality.thai, laName: 'ໄທ', code: ICustomerNationality.thai },
      { _id: ICustomerNationality.vietnamese, laName: 'ຫວຽດນາມ', code: ICustomerNationality.vietnamese },
      { _id: ICustomerNationality.thailao, laName: 'ໄທ-ລາວ', code: ICustomerNationality.thailao },
      { _id: ICustomerNationality.korea, laName: 'ເກົາຫຼີ', code: ICustomerNationality.korea },
      { _id: ICustomerNationality.none, laName: 'ອື່ນໆ', code: ICustomerNationality.none },
    ];
    set({ nationList: nationalityOptions });
  },

  loadCustomerAPI: async ({ props }: { props: ListNetworkProps }) => {
    try {
      set({ loading: true });

      const state = get();
      const { selectedGender, selectedNationality } = state;
      const page = props.page || (props.pageIndex !== undefined ? props.pageIndex + 1 : state.pageIndex + 1);
      const limit = props.limit || props.pageSize || state.pageSize;
      const isActive = props.isActive || state.isActive;
      const keyword = props.keyword !== undefined ? props.keyword : state.keyword;
      const sortField = props.sortField || state.sortField;
      const sortDirection = props.sortDirection || state.sortOrder;

      const variables: { input: CustomerInput } = {
        input: {
          page,
          limit,
        },
      };

      if (sortField) {
        variables.input.sortField = sortField;
      }
      if (sortDirection) {
        variables.input.sortDirection = sortDirection;
      }

      if (isActive && isActive !== IEntityStatus.all) {
        variables.input.isActive = isActive;
      }

      if (keyword && keyword.trim() !== '') {
        variables.input.keyword = keyword.trim();
      }

      const result = await props.query({
        variables,
      });


      if (result.data?.loadCustomer) {
        let customers = result.data.loadCustomer.customer || [];

        if (selectedGender) {
          customers = customers.filter((c: any) => c.gender === selectedGender);
        }

        if (selectedNationality) {
          customers = customers.filter((c: any) => c.nationality === selectedNationality);
        }

        const totalCount = result.data.loadCustomer.count || 0;

        set(() => ({
          customerList: customers,
          count: totalCount,
        }));
      } else {
        set(() => ({
          customerList: [],
          count: 0,
        }));
      }
    } catch (error: any) {
      set(() => ({ customerList: [], count: 0 }));
      throw error;
    } finally {
      set({ loading: false });
    }
  },

  searchCustomerAPI: async ({ props, keyword }) => {
    try {
      set({
        keyword: keyword,
        pageIndex: 0
      });
      await get().loadCustomerAPI({ props });
    } catch (error: any) {
      throw error;
    }
  },

  createCustomerAPI: async ({ props }: { props: CreateNetworkProps }) => {
    try {
      set({ loading: true });


      const { customerList, count } = get();
      let fileUrl: string | undefined | null = undefined;
      const customerFile = props.customerFile;
      if (customerFile) {
        if (customerFile.file) {
          const ownerId = `temp-${Date.now()}`;
          const uploadedUrl = await uploadOwnerFile({
            file: customerFile.file,
            ownerId,
            ownerType: ILeasingFileType.mmsCustomer,
          });
          fileUrl = uploadedUrl || undefined;
        } else if (customerFile.url) {
          fileUrl = customerFile.url;
        }
      }

      const input: CustomerInput = {
        firstName: props.firstName || null,
        lastName: props.lastName || null,
        phoneNumber: props.phoneNumber || null,
        gender: props.gender || null,
        nationality: props.nationality || null,
        province: props.province || null,
        district: props.district || null,
        village: props.village || null,
        fileUrl: fileUrl || null,
      };

      if (props.contact) {
        const contact = props.contact;
        input.contact = {
          firstName: contact.firstName || null,
          lastName: contact.lastName || null,
          phoneNumber: contact.phoneNumber || null,
          province: contact.province || null,
          district: contact.district || null,
          village: contact.village || null,
        };
      }

      const { data } = await props.mutation({
        variables: { input },
      });

      if (data?.createCustomer?.customer) {
        set(() => ({
          customerList: [data.createCustomer.customer, ...customerList],
          count: count + 1,
        }));
      }
    } catch (error: any) {
      throw error;
    } finally {
      set({ loading: false });
    }
  },

  updateCustomerAPI: async ({ id, mutation, props }: { id: string; mutation: any; props: any }) => {
    try {
      set({ loading: true });

      const { customerList } = get();

      let fileUrl: string | undefined | null = undefined;
      const customerFile = props.customerFile;

      if (customerFile) {
        if (customerFile.file) {
          const ownerId = `temp-${Date.now()}`;
          const uploadedUrl = await uploadOwnerFile({
            file: customerFile.file,
            ownerId,
            ownerType: ILeasingFileType.mmsCustomer,
          });
          fileUrl = uploadedUrl || undefined;
        } else if (customerFile.url) {
          fileUrl = customerFile.url;
        } else {
          fileUrl = null;
        }
      } else if (customerFile === null) {
        fileUrl = null;
      }

      const input: CustomerInput = {
        _id: id,
        firstName: props.firstName || null,
        lastName: props.lastName || null,
        phoneNumber: props.phoneNumber || null,
        gender: props.gender || null,
        nationality: props.nationality || null,
        province: props.province || null,
        district: props.district || null,
        village: props.village || null,
      };

      if (typeof fileUrl !== "undefined") {
        input.fileUrl = fileUrl;
      }
      if (props.contact) {
        const contact = props.contact;
        input.contact = {
          firstName: contact.firstName || null,
          lastName: contact.lastName || null,
          phoneNumber: contact.phoneNumber || null,
          province: contact.province || null,
          district: contact.district || null,
          village: contact.village || null,
        };
        input.deleteContact = false;
      } else if (props.contact === null) {
        input.deleteContact = true;
      }

      const { data } = await mutation({
        variables: { input },
      });

      if (data?.updateCustomer?.customer) {
        set(() => ({
          customerList: customerList.map((item) =>
            item._id === id ? data.updateCustomer.customer : item

          ),
        }));
      }
    } catch (error: any) {
      throw error;
    } finally {
      set({ loading: false });
    }
  },

  deleteCustomerAPI: async ({ id, mutation }: { id: string; mutation: any }) => {
    try {
      set({ loading: true });

      const { customerList, count, isActive } = get();

      const { data } = await mutation({
        variables: {
          input: {
            _id: id,
          },
        },
      });

      set(() => ({
        customerList: customerList.filter((item) => item._id !== id),
        count: count - 1,
      }));
    } catch (error: any) {
      throw error;
    } finally {
      set({ loading: false });
    }
  },

  restoreCustomerAPI: async ({ id, mutation }: { id: string; mutation: any }) => {
    try {
      set({ loading: true });

      const { customerList, count, isActive } = get();

      const { data } = await mutation({
        variables: {
          input: {
            _id: id,
          },
        },
      });

      if (isActive === IEntityStatus.inactive) {
        set(() => ({
          customerList: customerList.filter((item) => item._id !== id),
          count: count - 1,
        }));
      } else if (isActive === IEntityStatus.all) {
        set(() => ({
          customerList: customerList.map((item) =>
            item._id === id ? { ...item, isActive: IEntityStatus.active } : item
          ),
        }));
      }
    } catch (error: any) {
      throw error;
    } finally {
      set({ loading: false });
    }
  },
}));