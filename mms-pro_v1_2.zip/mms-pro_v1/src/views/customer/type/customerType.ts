import { getDictionary } from "@/utils/getDictionary";
import type { AttachedFile } from "@core/components/custom-inputs";

export type CustomerListProps = {
  dictionary: Awaited<ReturnType<typeof getDictionary>>;
  lang: string;
  loadCustomerCall?: any; // Optional: created internally in List component
};

export type ListNetworkProps = {
  query: any;
  dictionary: Awaited<ReturnType<typeof getDictionary>>;
  onSuccess?: Function;
  page?: number;
  limit?: number;
  pageIndex?: number;
  pageSize?: number;
  isActive?: string;
  keyword?: string;
  sortField?: string;
  sortDirection?: string;
};

export type CreateNetworkProps = {
  dictionary?: Awaited<ReturnType<typeof getDictionary>>;
  lang?: string;
  mutation?: any;
  onClose?: () => void;
  onSuccess?: () => void;

  firstName?: string;
  lastName?: string;
  phoneNumber?: string;
  gender?: string;
  nationality?: string;
  province?: string;
  district?: string;
  village?: string;
  fileUrl?: string;
  customerFile?: AttachedFile | null;
  contact?: {
    firstName?: string;
    lastName?: string;
    phoneNumber?: string;
    province?: string;
    district?: string;
    village?: string;
  };
};



export interface CustomerType {
  _id: string;
  uniqueId?: number;
  uid?: string;
  isActive?: string;
  createdAt?: string;
  updatedAt?: string;
  createdBy?: string;
  updatedBy?: string;
  buId?: string;

  // Customer fields
  firstName?: string;
  lastName?: string;
  phoneNumber?: string;
  gender?: string;
  nationality?: string;
  province?: string;
  district?: string;
  village?: string;
  fileUrl?: string;

  // Contact relation (populated by backend)
  contact?: {
    _id?: string;
    firstName?: string;
    lastName?: string;
    phoneNumber?: string;
    province?: string;
    district?: string;
    village?: string;
  };
}


export interface CustomerInput {
  _id?: string;
  firstName?: string | null;
  lastName?: string | null;
  phoneNumber?: string | null;
  gender?: string | null;
  nationality?: string | null;
  province?: string | null;
  district?: string | null;
  village?: string | null;
  fileUrl?: string | null;

  contact?: {
    firstName?: string | null;
    lastName?: string | null;
    phoneNumber?: string | null;
    province?: string | null;
    district?: string | null;
    village?: string | null;
  };
  deleteContact?: boolean;


  page?: number;
  limit?: number;
  isActive?: string;
  keyword?: string;
  sortField?: string;
  sortDirection?: string;
}
