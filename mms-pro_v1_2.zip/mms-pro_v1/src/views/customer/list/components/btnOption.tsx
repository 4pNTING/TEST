"use client";
import React from "react";
import { IconButton, Tooltip } from "@mui/material";
import { CustomerListProps, CustomerType } from "../../type/customerType";
import { useStore, useCustomerMutations } from "../../store/customerStore";
import { msgConfirm, msgSuccess, msgError } from "@/utils/sweetalert";
import { IEntityStatus } from "@/utils/base";

interface ButtonOptionProps {
  props: CustomerListProps;
  currentToView: CustomerType;
  loadCustomerCall?: any;
}

export function ButtonOption({
  props,
  currentToView,
  loadCustomerCall,
}: ButtonOptionProps) {
  const { lang, dictionary: dic } = props;

  const {
    deleteCustomerAPI,
    restoreCustomerAPI,
    setSelectedItem,
    setToggleUpdateComponent,
  } = useStore();
  const { deleteCustomerMutation, restoreCustomerMutation } =
    useCustomerMutations();

  const isActive = currentToView?.isActive === IEntityStatus.active;

  const handleEdit = () => {
    setSelectedItem(currentToView);
    setToggleUpdateComponent(true);
  };

  const handleDeleteClick = async () => {
    const confirmed = await msgConfirm({
      title: dic?.confirmDeleteTitle || "ຢືນຢັນການລຶບ",
      text:
        (dic?.delete || "ປິດໃຊ້ງານ") +
        " " +
        currentToView.firstName +
        " " +
        currentToView.lastName,
      btnConfirmText: dic?.confirm || "ລຶບ",
      btnCancelText: dic?.cancel || "ຍົກເລີກ",
      btnConfirmColor: "#1d5089ff",
    });

    if (!confirmed) return;

    try {
      await deleteCustomerAPI({
        id: currentToView._id || "",
        mutation: deleteCustomerMutation,
      });

      await msgSuccess({
        title: dic?.success || "ສຳເລັດ",
        text: (dic?.deleted || "ລຶບ") + "ລູກຄ້າສຳເລັດແລ້ວ",
        btnOKText: dic?.ok || "ຕົກລົງ",
        btnOKColor: "#1d5089ff",
      });
    } catch (error: any) {
      await msgError({
        title: dic?.error || "ຜິດພາດ",
        text: error.message || "ບໍ່ສາມາດປິດໃຊ້ງານລູກຄ້າໄດ້",
        btnOKText: dic?.ok || "ຕົກລົງ",
        btnOKColor: "#d33",
      });
    }
  };

  const handleRestoreClick = async () => {
    const confirmed = await msgConfirm({
      title: dic?.confirmRestoreTitle || "ຢືນຢັນການກູ້ຄືນ",
      text:
        (dic?.restore || "ກູ້ຄືນ") +
        " " +
        currentToView.firstName +
        " " +
        currentToView.lastName,
      btnCancelText: dic?.cancel || "ຍົກເລີກ",
      btnConfirmText: dic?.restore || "ກູ້ຄືນ",
      btnConfirmColor: "#1d5089ff",
    });

    if (!confirmed) return;

    try {
      await restoreCustomerAPI({
        id: currentToView._id || "",
        mutation: restoreCustomerMutation,
      });

      await msgSuccess({
        title: dic?.success || "ສຳເລັດ",
        text: (dic?.restore || "ເປີດໃຊ້ງານ") + "ລູກຄ້າສຳເລັດແລ້ວ",
        btnOKText: dic?.ok || "ຕົກລົງ",
        btnOKColor: "#1d5089ff",
      });
    } catch (error: any) {
      await msgError({
        title: dic?.error || "ຜິດພາດ",
        text: error.message || "ບໍ່ສາມາດເປີດໃຊ້ງານລູກຄ້າໄດ້",
        btnOKText: dic?.ok || "ຕົກລົງ",
        btnOKColor: "#d33",
      });
    }
  };

  return (
    <>
      <div className="flex gap-2 items-center justify-center">
        {isActive ? (
          <>
            <Tooltip title={dic?.edit}>
              <IconButton
                onClick={handleEdit}
                size="small"
                className="text-gray-600 hover:bg-gray-50"
              >
                <i className="tabler-edit text-[18px] text-yellow-500"></i>
              </IconButton>
            </Tooltip>

            <Tooltip title={dic?.delete}>
              <IconButton
                onClick={handleDeleteClick}
                size="small"
                className="text-gray-600 hover:bg-gray-50"
              >
                <i className="tabler-trash text-[18px] text-red-500"></i>
              </IconButton>
            </Tooltip>
          </>
        ) : (
          <>
            <Tooltip title={dic?.restore}>
              <IconButton
                onClick={handleRestoreClick}
                size="small"
                className="text-gray-600 hover:bg-gray-50"
              >
                <i className="tabler-refresh text-[18px] text-green-500"></i>
              </IconButton>
            </Tooltip>
          </>
        )}
      </div>
    </>
  );
}
