import { CustomerListProps, CustomerType } from "../type/customerType";
import HeaderComponent from "./components/header.compoenet";
import TableComponent from "./components/table.component";
import { useSession } from "next-auth/react";
import { useStore } from "../store/customerStore";
import CreateComponent from "./components/formCreate.component";
import UpdateComponent from "./components/formUpdate.component";
import { useEffect, useState, useRef } from "react";
import { toast } from "react-toastify";
import { LOAD_CUSTOMER } from "@/gql/queries";
import { useLazyQuery } from "@apollo/client";
import LazyLoading from "@/utils/lazyLoading";

export const List = ({ props }: { props: CustomerListProps }) => {
  const { lang, dictionary: dic } = props;
  const { data } = useSession();
  const user = data?.user;

  const {
    removeListenerState,
    toggleCreateComponent,
    setToggleCreateComponent,
    toggleUpdateComponent,
    setToggleUpdateComponent,
    selectedItem,
    setSelectedItem,
    loadCustomerAPI,
    customerList,
  } = useStore();

  const [render, setRender] = useState(false);
  const [globalFilter, setGlobalFilter] = useState("");
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);

  const [loadCustomerCall] = useLazyQuery(LOAD_CUSTOMER, {
    fetchPolicy: "network-only",
  });

  // Ref to track if initial data has been loaded
  const hasFetchedRef = useRef(false);

  async function init() {
    try {
      // Skip fetch if data already exists in store
      if (customerList && customerList.length > 0 && hasFetchedRef.current) {
        setRender(true);
        return;
      }

      await loadCustomerAPI({
        props: {
          query: loadCustomerCall,
          dictionary: dic,
        },
      });
      hasFetchedRef.current = true;
    } catch (error) {
      console.error("Failed to load customers:", error);
      toast.error("Failed to load customers");
    }
  }
  useEffect(() => {
    init().then(() => {
      setRender(true);
    });
  }, [user]);

  useEffect(() => {
    setToggleCreateComponent(false);
    setToggleUpdateComponent(false);
    return () => {
      setToggleCreateComponent(false);
      setToggleUpdateComponent(false);
      // Cleanup debounce timer on unmount
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, [setToggleCreateComponent, setToggleUpdateComponent]);

  const handleClose = () => {
    setSelectedItem(null);
    setToggleCreateComponent(false);
    setToggleUpdateComponent(false);
    
    // Check if we have data in state, if not reload
    if (!customerList || customerList.length === 0) {
      init();
    }
  };

  const handleFormSuccess = async () => {
    // Reload data after successful form submission to get updated file URLs
  
    handleClose();
  };

  const handleGlobalFilterChange = (value: string) => {
    setGlobalFilter(value);
    
    // Clear previous timer
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    
    // Set new timer with 500ms debounce
    debounceTimerRef.current = setTimeout(async () => {
      try {
        const { searchCustomerAPI } = useStore.getState();
        
        await searchCustomerAPI({
          props: {
            query: loadCustomerCall,
            dictionary: dic,
          },
          keyword: value,
        });
      } catch (error: any) {
        toast.error(error.message);
      }
    }, 500);
  };

  return (
    <>
      {render === true ? (
        <div className="grid grid-cols-1 gap-[15px]">
          {toggleCreateComponent === true ? (
            <CreateComponent
              props={props}
              onClose={handleClose}
              onSuccess={handleFormSuccess}
            />
          ) : toggleUpdateComponent === true ? (
            <UpdateComponent
              props={props}
              selectedItem={selectedItem}
              onClose={handleClose}
              onSuccess={handleFormSuccess}
            />
          ) : (
            <>
              <HeaderComponent
                props={props}
                globalFilter={globalFilter}
                setGlobalFilter={setGlobalFilter}
                onGlobalFilterChange={handleGlobalFilterChange}
                loadCustomerCall={loadCustomerCall}
              />
              <TableComponent
                props={props}
                globalFilter={globalFilter}
                onGlobalFilterChange={handleGlobalFilterChange}
                loadCustomerCall={loadCustomerCall}
              />
            </>
          )}
        </div>
      ) : (
        <LazyLoading />
      )}
    </>
  );
};
