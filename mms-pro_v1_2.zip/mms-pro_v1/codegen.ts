import { CodegenConfig } from '@graphql-codegen/cli';

const config: CodegenConfig = {
  schema: ['http://192.168.100.30:7064/api-gateway'],
  // Generate types สำหรับ Zone, RoomAreaCategory และ RoomArea
  documents: [
    'src/gql/queries/zone.ts', 
    'src/gql/queries/roomAreaCategory.ts',
    'src/gql/queries/roomArea.ts',
    'src/gql/queries/shopCategory.ts'
  ],
  generates: {
    './src/gql/models/': {
      preset: 'client',
      plugins: [],
      presetConfig: {
        gqlTagName: 'gql',
      },
    },
  },
  ignoreNoDocuments: true,
};

export default config;
